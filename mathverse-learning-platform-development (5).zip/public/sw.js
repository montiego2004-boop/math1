/* MATHVERSE service worker — honest, modest offline support.
   - Precaches only the app shell (resolved from the registration scope,
     so it works on sub-paths like GitHub Pages: /mathverse/).
   - Network-first for page navigations with cache fallback (visited pages
     stay available offline).
   - Cache-first for hashed static assets (/_next/static) and PWA files.
   - Cross-origin requests are never cached. */
const CACHE = "mv-v1";
const SHELL = () => new URL(".", self.registration.scope).href;

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((c) =>
        Promise.allSettled([c.add(SHELL()), c.add(new URL("manifest.webmanifest", self.registration.scope).href)])
      )
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy));
          return res;
        })
        .catch(() =>
          caches.match(req).then((hit) => hit || caches.match(SHELL()))
        )
    );
    return;
  }

  if (
    url.pathname.startsWith("/_next/static") ||
    url.pathname.includes("/icons/") ||
    url.pathname.endsWith("/icon.svg") ||
    url.pathname.endsWith("/manifest.webmanifest") ||
    url.pathname.endsWith("/sw.js")
  ) {
    event.respondWith(
      caches.match(req).then(
        (hit) =>
          hit ||
          fetch(req).then((res) => {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
            return res;
          })
      )
    );
  }
});
