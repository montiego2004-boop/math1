/* Rendering regression suite — replicates the Inline tokenizer from
   src/components/academy-browser.tsx and feeds everything through KaTeX.
   Run: node scripts/render-test.mjs */

import fs from "node:fs";
import katex from "katex";

/* ---- same tokenizer as the component (keep in sync!) ---- */
function tokenize(s) {
  const parts = [];
  let i = 0;
  while (i < s.length) {
    const open = s.indexOf("{{", i);
    if (open === -1) {
      parts.push({ kind: "text", v: s.slice(i) });
      break;
    }
    if (open > i) parts.push({ kind: "text", v: s.slice(i, open) });
    let j = open + 2;
    let depth = 0;
    let end = -1;
    while (j < s.length) {
      const ch = s[j];
      if (ch === "\\") {
        j += 2;
        continue;
      }
      if (ch === "{") depth++;
      else if (ch === "}") {
        if (depth === 0 && s[j + 1] === "}") {
          end = j;
          break;
        }
        if (depth > 0) depth--;
      }
      j++;
    }
    if (end === -1) {
      parts.push({ kind: "text", v: s.slice(open) });
      break;
    }
    parts.push({ kind: "math", v: s.slice(open + 2, end) });
    i = end + 2;
  }
  return parts;
}

const dataFiles = [
  "src/data/lessons-math.ts",
  "src/data/lessons-math-a.ts",
  "src/data/lessons-math-b.ts",
  "src/data/lessons-math-c.ts",
  "src/data/lessons-math-d.ts",
  "src/data/lessons-math-a2.ts",
  "src/data/lessons-math-b2.ts",
  "src/data/lessons-math-c2.ts",
  "src/data/lessons-math-d2.ts",
  "src/data/lessons-physics.ts",
  "src/data/exercises.ts",
  "src/data/formulas.ts",
];

let mathSegs = 0,
  texBlocks = 0,
  errors = [],
  unbalanced = 0,
  mdBoldUnhandled = 0,
  reconstructionFailures = 0;

for (const file of dataFiles) {
  const src = fs.readFileSync(file, "utf8");
  const strings = src.match(/"((?:[^"\\]|\\.)*)"/gs) ?? [];
  for (const raw of strings) {
    let decoded;
    try {
      decoded = JSON.parse(raw);
    } catch {
      continue;
    }
    // 1) tokenize (Inline pipeline)
    const parts = tokenize(decoded);
    // 2) reconstruction check (losslessness)
    const rebuilt = parts
      .map((p) => (p.kind === "math" ? "{{" + p.v + "}}" : p.v))
      .join("");
    if (rebuilt !== decoded) reconstructionFailures++;
    // math segments → KaTeX
    for (const p of parts) {
      if (p.kind === "math") {
        mathSegs++;
        try {
          katex.renderToString(p.v, { throwOnError: true, strict: "ignore" });
        } catch (e) {
          errors.push({ file, tex: p.v.slice(0, 100), err: e.message.slice(0, 90) });
        }
      } else if (/\*\*[^*]+\*\*/.test(p.v)) {
        mdBoldUnhandled++; // these are INTENTIONALLY bold-parsed in RichText, but log count for visibility
      }
    }
    // 3) unbalanced boundaries
    const opens = (decoded.match(/\{\{/g) || []).length;
    const closes = (decoded.match(/\}\}/g) || []).length;
    if (opens !== closes && decoded.includes("{{")) {
      // depth-aware balance: only a problem if tokenizer degraded
      const fallbackToText = parts.filter((p) => p.kind === "text" && p.v.includes("{{"));
      if (fallbackToText.length) unbalanced++;
    }
  }
}

// 4) representative required rendering cases
const CASES = [
  "\\frac{x^2 - 4}{x - 2}",
  "f'(x) = \\lim_{h \\to 0} \\frac{f(x+h)-f(x)}{h}",
  "\\int_0^1 e^{-x^2}\\,dx",
  "\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}",
  "\\sum_{n=1}^{\\infty} \\frac{1}{n^2} = \\frac{\\pi^2}{6}",
  "f(x) = \\begin{cases} x^2 & x \\ge 0 \\\\ -x & x < 0 \\end{cases}",
  "\\begin{aligned} x + y &= 5 \\\\ 2x - y &= 1 \\end{aligned}",
  "\\oint_C \\vec F \\cdot d\\vec r = \\iint_D (Q_x - P_y)\\,dA",
  "\\mathbb{N} \\subset \\mathbb{Z} \\subset \\mathbb{Q} \\subset \\mathbb{R}",
  "z = a + bi, \\quad |z| = \\sqrt{a^2 + b^2}, \\quad e^{i\\pi} + 1 = 0",
];
for (const c of CASES) {
  try {
    katex.renderToString(c, { throwOnError: true, displayMode: true });
  } catch (e) {
    errors.push({ file: "TEST-CASE", tex: c.slice(0, 80), err: e.message.slice(0, 80) });
  }
}

console.log("math segments rendered:", mathSegs);
console.log("reconstruction failures:", reconstructionFailures);
console.log("unbalanced degradations:", unbalanced);
console.log("markdown **bold** segments handled by RichText:", mdBoldUnhandled);
if (errors.length === 0) {
  console.log("PASS: all math segments render cleanly with KaTeX.");
  process.exit(0);
} else {
  console.log("FAIL:", errors.length, "errors");
  for (const e of errors.slice(0, 20)) console.log(" •", e.file, "|", e.err, "|", JSON.stringify(e.tex));
  process.exit(1);
}
