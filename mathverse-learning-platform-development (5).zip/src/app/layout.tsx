import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Vazirmatn } from "next/font/google";
import "katex/dist/katex.min.css";
import "./globals.css";
import AppShell from "@/components/app-shell";

const vazirmatn = Vazirmatn({
  subsets: ["latin", "latin-ext"],
  variable: "--font-vazirmatn",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "مث‌ورس | MATHVERSE — پلتفرم آزاد آموزش ریاضیات و فیزیک",
    template: "%s | مث‌ورس",
  },
  description:
    "پلتفرم آموزشی رایگان و تعاملی ریاضیات و فیزیک: آکادمی، آزمایشگاه، ماشین‌حساب علمی، حل‌گر مسائل، دانشنامه فرمول و کتابخانه علمی.",
  manifest: "/manifest.webmanifest",
  applicationName: "MATHVERSE",
};

export const viewport: Viewport = {
  themeColor: "#060f1e",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl" data-theme="dark" className={vazirmatn.variable} suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `try{var t=localStorage.getItem('mv-theme');if(t)document.documentElement.dataset.theme=t;}catch(e){}`,
          }}
        />
      </head>
      <body>
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
