"use client";

import { useRef, useState } from "react";
import dynamic from "next/dynamic";
import Plot2D, { type Plot2DScene } from "@/components/plot2d";
import { ModeToggle, GuidePanel, SceneSaver, type Mode, type Guide } from "@/components/studio-ui";

const ConicsModule = dynamic(() => import("@/components/studio2d/conics"), { ssr: false, loading: () => <div className="card grid h-64 place-items-center text-muted">بارگذاری…</div> });
const SeriesFourierModule = dynamic(() => import("@/components/studio2d/series-fourier"), { ssr: false, loading: () => <div className="card grid h-64 place-items-center text-muted">بارگذاری…</div> });
const VectorOdeModule = dynamic(() => import("@/components/studio2d/vector-ode"), { ssr: false, loading: () => <div className="card grid h-64 place-items-center text-muted">بارگذاری…</div> });
const MatrixTransformModule = dynamic(() => import("@/components/studio2d/matrix-transform"), { ssr: false, loading: () => <div className="card grid h-64 place-items-center text-muted">بارگذاری…</div> });
const ComplexPlaneModule = dynamic(() => import("@/components/studio2d/complex-plane"), { ssr: false, loading: () => <div className="card grid h-64 place-items-center text-muted">بارگذاری…</div> });
const LimitsModule = dynamic(() => import("@/components/studio2d/limits-piecewise"), { ssr: false, loading: () => <div className="card grid h-64 place-items-center text-muted">بارگذاری…</div> });

const MODULES: { id: string; fa: string; guide: Guide }[] = [
  {
    id: "plot",
    fa: "رسم توابع",
    guide: {
      intro: "موتور اصلی رسم: توابع دکارتی، پارامتری و قطبی را هم‌زمان بکشید.",
      steps: ["تعریف تابع با متغیر x یا t", "روشن کردن f′ برای مشتق عددی", "انتخاب «خط مماس» و کلیک روی نمودار", "تعیین کران‌ها برای سایهٔ انتگرال"],
      formulas: ["f'(x) \\approx \\frac{f(x+h)-f(x-h)}{2h}", "\\int_a^b f \\approx \\text{سیمپسون}"],
      tryIt: ["x^2/4 را با مماس در x=2", "sin(x)*exp(-x/5)", "قطبی: 1+cos(t)"],
    },
  },
  {
    id: "conics",
    fa: "مقاطع مخروطی",
    guide: {
      intro: "دایره، بیضی، سهمی و هذلولی همه از برش یک مخروط به دست می‌آیند و با یک عدد — لختی e — از هم متمایز می‌شوند.",
      steps: ["نوع مقطع را انتخاب کنید", "کانون‌ها (صورتی) و هادی (زرد) را پیدا کنید", "در حالت «بر مبنای e» لختی را از ۰ به بالای ۱ ببرید"],
      formulas: ["e<1:\\ \text{بیضی},\\quad e=1:\\ \text{سهمی},\\quad e>1:\\ \text{هذلولی}", "r=\\frac{l}{1-e\\cos\\theta}"],
      tryIt: ["سیکلوئید چرخِ غلتان", "رز با n/m = 5/2"],
    },
  },
  {
    id: "series",
    fa: "سری‌ها و فوریه",
    guide: {
      intro: "چند جمله‌ی نخست یک سری توان می‌تواند یک تابع پِیچیده را تقریب بزند — مثل ساختن موج با سینوس‌های ساده.",
      steps: ["N را افزایش دهید و مواظب خطای صورتی باشید", "برای 1/(1−x) بیرون از |x|<1 واگرایی را ببینید", "در فوریه، نزدیک جهش‌ها پدیدهٔ گیبس را پیدا کنید"],
      formulas: ["f(x) = \\sum c_k \\varphi_k(x)", "\\text{گیبس: فراجهش } \\approx 9\\%"],
    },
  },
  {
    id: "vector",
    fa: "میدان‌های برداری و ODE",
    guide: {
      intro: "میدان برداری F=(P,Q) در هر نقطه یک پیکان است؛ خط جریان، مسیری است که همیشه مماس بر میدان است.",
      steps: ["P و Q را بنویسید", "کلیک کنید تا خط جریان آن نقطه رسم شود", "div>0 یعنی چشمه و curl≠0 یعنی چرخش محلی"],
      formulas: ["\\nabla\\cdot\\vec F = \\partial_x P + \\partial_y Q", "\\text{در میدان شیب: } y' = f(x,y)"],
      tryIt: ["(y, −x) چرخه", "(x, y) چشمه", "(x²−y², 2xy)"],
    },
  },
  {
    id: "matrix",
    fa: "تبدیل‌های ماتریسی",
    guide: {
      intro: "ماتریس ۲×۲ کل صفحه را به‌صورت خطی تغییر شکل می‌دهد: شبکه را ببینید که چگونه می‌چرخد و می‌کشد.",
      steps: ["انیمیشن I→A را اجرا کنید", "مربع صورتی (تصویر مربع واحد) مساحت |det A| دارد", "پیکان‌های زرد جهت‌های ویژه‌اند: روی آن‌ها A فقط مقیاس می‌دهد"],
      formulas: ["A\\vec v = \\lambda \\vec v", "\\det A = \\text{ضریب تغییر مساحت}"],
      tryIt: ["چرخش ۹۰°", "برش [[1,1],[0,1]]", "ماتریس منفرد [[1,1],[1,1]]"],
    },
  },
  {
    id: "complex",
    fa: "صفحهٔ مختلط",
    guide: {
      intro: "تابع مختلط را نمی‌توان با نمودار معمولی کشید؛ رنگ‌بندی دامنه فاز و اندازهٔ خروجی را با رنگ و روشنایی می‌نشانَد.",
      steps: ["f(z)=z²−1: دور هر صفر رنگ‌ها یک کامِ چرخش می‌زنند", "1/z: در قطب رنگ‌ها برعکس می‌چرخند", "exp(z): نواری و متناوب"],
      formulas: ["w=f(z)", "\\text{Hue}=\\arg w,\\ \\text{Brightness}=|w|"],
    },
  },
  {
    id: "limits",
    fa: "حد و پیوستگی",
    guide: {
      intro: "تعریف ε–δِ حد: برای هر باند ε دور L باید پنجرهٔ δ دور c پیدا شود که نمودار را درون باند نگه دارد.",
      steps: ["ε را کوچک کنید", "δ را آن‌قدر کم کنید که تیک سبز بگیرید", "روی نوسانی sin(1/x) هرگز موفق نمی‌شوید — چون حد ندارد"],
      formulas: ["0<|x-c|<\\delta \\Rightarrow |f(x)-L|<\\varepsilon"],
      tryIt: ["حفره در (x²−1)/(x−1)", "جهش در صفر"],
    },
  },
];

export default function Graph2DStudio() {
  const [mod, setMod] = useState("plot");
  const [mode, setMode] = useState<Mode>("explore");
  const sceneRef = useRef<unknown>(null);
  const [loadScene, setLoadScene] = useState<Plot2DScene | undefined>(undefined);
  const [remountKey, setRemountKey] = useState(0);
  const guide = MODULES.find((m) => m.id === mod)?.guide;

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {MODULES.map((m) => (
          <button key={m.id} onClick={() => setMod(m.id)} className={`btn !text-xs ${mod === m.id ? "!border-accent !bg-accentsoft !text-accent" : ""}`}>
            {m.fa}
          </button>
        ))}
        <div className="mr-auto">
          <ModeToggle mode={mode} onChange={setMode} />
        </div>
      </div>

      <GuidePanel guide={guide} mode={mode} />

      <div className="mt-3">
        {mod === "plot" && (
          <Plot2D
            key={remountKey}
            initialScene={loadScene}
            onSceneChange={(s) => { sceneRef.current = s; }}
          />
        )}
        {mod === "conics" && <ConicsModule />}
        {mod === "series" && <SeriesFourierModule />}
        {mod === "vector" && <VectorOdeModule />}
        {mod === "matrix" && <MatrixTransformModule />}
        {mod === "complex" && <ComplexPlaneModule />}
        {mod === "limits" && <LimitsModule />}
      </div>

      {mod === "plot" && (
        <div className="mt-4">
          <SceneSaver
            storageKey="graph2d"
            serialize={() => sceneRef.current}
            apply={(data) => {
              setLoadScene(data as Plot2DScene);
              setRemountKey((k) => k + 1);
            }}
          />
        </div>
      )}
    </div>
  );
}
