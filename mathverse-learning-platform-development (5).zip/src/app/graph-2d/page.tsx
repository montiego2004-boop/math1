import type { Metadata } from "next";
import dynamic from "next/dynamic";

export const metadata: Metadata = { title: "ریاضیات دوبعدی تعاملی" };

const Graph2DStudio = dynamic(() => import("./studio"), {
  loading: () => <div className="card grid h-96 place-items-center text-muted">در حال بارگذاری استودیوی دوبعدی…</div>,
});

export default function Graph2DPage() {
  return (
    <div className="fade-up">
      <h1 className="section-title mb-2">استودیوی ریاضیات دوبعدی</h1>
      <p className="mb-6 text-sm leading-7 text-muted">
        رسم تابع دکارتی/پارامتری/قطبی، مقاطع مخروطی، سری توان و فوریه، میدان‌های برداری و میدان شیب، تبدیل‌های
        ماتریسی، صفحهٔ مختلط و تجسم حد — همهٔ ماژول‌ها تنها در صورت انتخاب بارگذاری می‌شوند.
      </p>
      <Graph2DStudio />
    </div>
  );
}
