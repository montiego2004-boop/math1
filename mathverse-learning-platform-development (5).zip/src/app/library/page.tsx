"use client";

import { useMemo, useState } from "react";
import { ExternalLink, Heart, LibraryBig, Scale, Search, ShieldCheck } from "lucide-react";
import { LIBRARY, RESOURCE_SUBJECTS, RESOURCE_TYPES } from "@/data/library";
import { useBookmarks } from "@/lib/store";

export default function LibraryPage() {
  const [q, setQ] = useState("");
  const [subject, setSubject] = useState("all");
  const [type, setType] = useState("همه");
  const [onlyFav, setOnlyFav] = useState(false);
  const { bookmarks, toggleBookmark } = useBookmarks();

  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return LIBRARY.filter((r) => {
      if (subject !== "all" && r.subject !== subject) return false;
      if (type !== "همه" && r.type !== type) return false;
      if (onlyFav && !bookmarks.includes(`lib/${r.id}`)) return false;
      if (!needle) return true;
      return `${r.title} ${r.author} ${r.note} ${r.license}`.toLowerCase().includes(needle);
    });
  }, [q, subject, type, onlyFav, bookmarks]);

  return (
    <div className="fade-up">
      <h1 className="section-title mb-2 flex items-center gap-2">
        <LibraryBig className="size-7 text-accent" /> کتابخانه علمی دیجیتال
      </h1>

      <div className="card mb-5 flex items-start gap-3 border-accent/30 !bg-accentsoft/30 p-4 text-xs leading-7">
        <ShieldCheck className="mt-1 size-5 shrink-0 text-accent" />
        <div>
          <strong>سیاست حقوقی مث‌ورس:</strong> ما فقط منابع دارای مجوز دسترسی‌باز یا مالکیت عمومی را فهرست
          می‌کنیم و هیچ فایل محلی از آثار دیگران میزبانی نمی‌کنیم. هر منبع به سایت رسمی ناشر پیوند دارد و
          مجوزش ذکر شده است؛ پیش از بازنشر هر اثری، مجوز همان صفحه را بررسی کنید.
        </div>
      </div>

      <div className="mb-5 flex flex-col gap-3 lg:flex-row">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted" />
          <input className="input !pr-9" placeholder="جست‌وجو در عنوان، نویسنده یا مجوز…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="flex flex-wrap gap-2">
          <select className="input !w-auto !text-xs" value={subject} onChange={(e) => setSubject(e.target.value)}>
            {RESOURCE_SUBJECTS.map((s) => <option key={s.id} value={s.id}>{s.fa}</option>)}
          </select>
          <select className="input !w-auto !text-xs" value={type} onChange={(e) => setType(e.target.value)}>
            {RESOURCE_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
          <button className={`btn !text-xs ${onlyFav ? "!border-accent !text-accent" : ""}`} onClick={() => setOnlyFav((v) => !v)}>
            <Heart className={`size-3.5 ${onlyFav ? "fill-accent" : ""}`} /> نشان‌شده‌ها
          </button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {list.map((r) => {
          const fav = bookmarks.includes(`lib/${r.id}`);
          return (
            <article key={r.id} className="card card-hover flex flex-col p-5">
              <div className="mb-2 flex items-start justify-between gap-2">
                <div>
                  <h3 className="font-bold leading-6" dir="auto">{r.title}</h3>
                  <p className="mt-0.5 text-xs text-muted" dir="auto">{r.author}</p>
                </div>
                <button onClick={() => toggleBookmark(`lib/${r.id}`)} aria-label="نشانه‌گذاری" className="shrink-0">
                  <Heart className={`size-5 transition-colors ${fav ? "fill-accent text-accent" : "text-muted"}`} />
                </button>
              </div>
              <p className="mb-3 flex-1 text-xs leading-6 text-muted">{r.note}</p>
              <div className="mb-3 flex flex-wrap gap-1.5">
                {[r.type, r.level, r.lang].map((t) => <span key={t} className="chip !text-[10px]">{t}</span>)}
                <span className="chip !border-accent/40 !text-[10px] !text-accent">
                  <Scale className="size-3" /> {r.license}
                </span>
              </div>
              <a href={r.url} target="_blank" rel="noopener noreferrer" className="btn w-full justify-center !text-xs">
                <ExternalLink className="size-3.5" /> مشاهده در منبع اصلی
              </a>
            </article>
          );
        })}
      </div>
      {list.length === 0 && (
        <div className="card grid h-32 place-items-center text-sm text-muted">موردی یافت نشد.</div>
      )}
    </div>
  );
}
