"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { BarChart3, Dices, FunctionSquare, LineChart } from "lucide-react";
import { TeX } from "@/components/katex";
import { useProgress } from "@/lib/store";

/* ------------------------- numeric helpers ------------------------- */

function parseDataset(s: string): number[] {
  return s
    .replace(/[،؛]/g, ",")
    .split(/[\s,]+/)
    .map((x) => x.trim())
    .filter(Boolean)
    .map(Number)
    .filter((x) => isFinite(x));
}

function describe(xs: number[]) {
  const n = xs.length;
  const sorted = [...xs].sort((a, b) => a - b);
  const mean = xs.reduce((a, b) => a + b, 0) / n;
  const q = (p: number) => {
    const i = (n - 1) * p;
    const lo = Math.floor(i), hi = Math.ceil(i);
    return sorted[lo] + (sorted[hi] - sorted[lo]) * (i - lo);
  };
  const varPop = xs.reduce((a, b) => a + (b - mean) ** 2, 0) / n;
  const varSam = n > 1 ? (n / (n - 1)) * varPop : 0;
  const freq = new Map<number, number>();
  xs.forEach((x) => freq.set(x, (freq.get(x) ?? 0) + 1));
  const maxF = Math.max(...freq.values());
  const modes = [...freq.entries()].filter(([, f]) => f === maxF).map(([v]) => v);
  return {
    n, mean, median: q(0.5), q1: q(0.25), q3: q(0.75), iqr: q(0.75) - q(0.25),
    min: sorted[0], max: sorted[n - 1], range: sorted[n - 1] - sorted[0],
    varPop, varSam, sdPop: Math.sqrt(varPop), sdSam: Math.sqrt(varSam),
    modes: maxF > 1 ? modes.slice(0, 5) : [],
  };
}

/* erf via Abramowitz–Stegun 7.1.26 (max |ε| ≈ 1.5e-7) */
function erf(x: number) {
  const s = Math.sign(x);
  const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741, a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
  const t = 1 / (1 + p * Math.abs(x));
  const y = 1 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
  return s * y;
}
const normPdf = (x: number, mu: number, sd: number) => Math.exp(-((x - mu) ** 2) / (2 * sd * sd)) / (sd * Math.sqrt(2 * Math.PI));
const normCdf = (x: number, mu: number, sd: number) => 0.5 * (1 + erf((x - mu) / (sd * Math.sqrt(2))));
const comb = (n: number, k: number) => {
  if (k < 0 || k > n) return 0;
  let r = 1;
  for (let i = 0; i < k; i++) r = (r * (n - i)) / (i + 1);
  return r;
};
const binomPmf = (n: number, p: number, k: number) => comb(n, k) * p ** k * (1 - p) ** (n - k);
const poissonPmf = (lam: number, k: number) => {
  let s = Math.exp(-lam);
  for (let i = 1; i <= k; i++) s *= lam / i;
  return s;
};

const fmt = (x: number, d = 4) => {
  const r = Math.round(x * 10 ** d) / 10 ** d;
  return String(r);
};

/* --------------------------- chart canvas --------------------------- */

function Bars({ labels, values, color = "#2dd4bf", height = 200 }: { labels: string[]; values: number[]; color?: string; height?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const W = c.clientWidth, H = height;
    const dpr = Math.min(devicePixelRatio, 2);
    c.width = W * dpr; c.height = H * dpr;
    const ctx = c.getContext("2d")!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    const max = Math.max(...values, 1e-12);
    const bw = (W - 40) / values.length;
    values.forEach((v, i) => {
      const h = (v / max) * (H - 44);
      ctx.fillStyle = color;
      ctx.fillRect(32 + i * bw + 2, H - 26 - h, bw - 4, h);
      ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--muted").trim() || "#8ea6c8";
      ctx.font = "9px monospace";
      ctx.textAlign = "center";
      ctx.fillText(labels[i], 32 + i * bw + bw / 2, H - 12);
      ctx.fillText(fmt(v, 3), 32 + i * bw + bw / 2, Math.max(10, H - 30 - h));
    });
    ctx.strokeStyle = "#8ea6c8";
    ctx.beginPath(); ctx.moveTo(28, H - 26); ctx.lineTo(W - 6, H - 26); ctx.stroke();
  }, [labels, values, color, height]);
  return <canvas ref={ref} className="w-full" style={{ height }} />;
}

/* ------------------------------ page ------------------------------ */

type Tab = "describe" | "dist" | "regress" | "sim";

export default function StatsPage() {
  const [tab, setTab] = useState<Tab>("describe");
  const { recordToolUse } = useProgress();
  useEffect(() => recordToolUse("stats"), [recordToolUse]);

  return (
    <div className="fade-up">
      <h1 className="section-title mb-2 flex items-center gap-2">
        <BarChart3 className="size-7 text-accent" /> آزمایشگاه آمار و احتمال
      </h1>
      <p className="mb-5 text-sm leading-7 text-muted">
        داده بدهید و نتیجه بگیرید: آمار توصیفی، توزیع‌های احتمال با فرمول‌های دقیق، رگرسیون کمترین مربعات و
        شبیه‌سازی مونت‌کارلو. همه‌ی محاسبات محلی و بدون سرور انجام می‌شود.
      </p>
      <div className="mb-5 flex flex-wrap gap-2">
        {([["describe", "تحلیل داده", BarChart3], ["dist", "توزیع‌های احتمال", FunctionSquare], ["regress", "رگرسیون خطی", LineChart], ["sim", "شبیه‌سازی تصادفی", Dices]] as const).map(([id, fa, I]) => (
          <button key={id} onClick={() => setTab(id)} className={`btn !text-xs ${tab === id ? "!border-accent !bg-accentsoft !text-accent" : ""}`}>
            <I className="size-3.5" /> {fa}
          </button>
        ))}
      </div>
      {tab === "describe" && <Describe />}
      {tab === "dist" && <Distributions />}
      {tab === "regress" && <Regression />}
      {tab === "sim" && <Simulation />}
    </div>
  );
}

/* ----------------------------- datasets ----------------------------- */

function Describe() {
  const [raw, setRaw] = useState("12, 15, 12, 18, 20, 15, 22, 17, 15, 19, 21, 15");
  const xs = useMemo(() => parseDataset(raw), [raw]);
  const st = xs.length ? describe(xs) : null;

  const hist = useMemo(() => {
    if (!xs.length) return null;
    const s = describe(xs);
    const bins = Math.max(4, Math.min(14, Math.round(Math.sqrt(xs.length))));
    const w = (s.range || 1) / bins;
    const counts = new Array(bins).fill(0);
    xs.forEach((x) => counts[Math.min(bins - 1, Math.floor((x - s.min) / w))]++);
    return {
      labels: counts.map((_, i) => fmt(s.min + (i + 0.5) * w, 1)),
      values: counts.map((c) => c / xs.length),
    };
  }, [xs]);

  return (
    <div className="grid gap-5 lg:grid-cols-[340px_1fr]">
      <div className="card h-fit p-5">
        <label className="mb-2 block text-sm font-bold">داده‌های عددی (با ویرگول یا فاصله)</label>
        <textarea className="input min-h-36 font-mono text-xs" dir="ltr" value={raw} onChange={(e) => setRaw(e.target.value)} />
        <div className="mt-2 text-xs text-muted">{xs.length} داده معتبر شناسایی شد.</div>
      </div>
      {st ? (
        <div className="space-y-5">
          <div className="card overflow-x-auto p-4">
            <table className="w-full min-w-[480px] text-center text-sm">
              <thead>
                <tr className="border-b border-line text-xs text-muted">
                  {["n", "میانگین", "میانه", "نما (mode)", "واریانس نمونه s²", "انحراف معیار s", "کمینه", "بیشینه", "دامنه", "چارک ۱", "چارک ۳", "IQR"].map((h) => (
                    <th key={h} className="p-2 font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr className="font-mono" dir="ltr">
                  <td className="p-2">{st.n}</td>
                  <td className="p-2 text-accent">{fmt(st.mean)}</td>
                  <td className="p-2">{fmt(st.median)}</td>
                  <td className="p-2">{st.modes.join(", ") || "—"}</td>
                  <td className="p-2">{fmt(st.varSam)}</td>
                  <td className="p-2">{fmt(st.sdSam)}</td>
                  <td className="p-2">{st.min}</td>
                  <td className="p-2">{st.max}</td>
                  <td className="p-2">{fmt(st.range)}</td>
                  <td className="p-2">{fmt(st.q1)}</td>
                  <td className="p-2">{fmt(st.q3)}</td>
                  <td className="p-2">{fmt(st.iqr)}</td>
                </tr>
              </tbody>
            </table>
          </div>
          {hist && (
            <div className="card p-4">
              <h3 className="mb-2 text-sm font-bold">هیستوگرام فراوانی نسبی</h3>
              <Bars labels={hist.labels} values={hist.values} />
            </div>
          )}
          <div className="card p-4 text-xs leading-7 text-muted">
            <strong className="text-fg">نکته آماری:</strong> واریانس نمونه با تقسیم بر{" "}
            <TeX>{"n-1"}</TeX> (تصحیح بسل) برآورد ناریبی از واریانس جامعه است. واریانس جمعیت (تقسیم بر{" "}
            <TeX>{"n"}</TeX>) هم‌اکنون: <span dir="ltr" className="font-mono">{fmt(st.varPop)}</span>
          </div>
        </div>
      ) : (
        <div className="card grid h-40 place-items-center text-sm text-muted">داده‌ی معتبری وارد کنید.</div>
      )}
    </div>
  );
}

/* --------------------------- distributions --------------------------- */

function Distributions() {
  const [dist, setDist] = useState<"binomial" | "normal" | "poisson">("binomial");
  const [n, setN] = useState(10);
  const [p, setP] = useState(0.5);
  const [mu, setMu] = useState(0);
  const [sd, setSd] = useState(1);
  const [lam, setLam] = useState(3);
  const [kq, setKq] = useState(4);

  const chart = useMemo(() => {
    if (dist === "binomial") {
      const labels = Array.from({ length: n + 1 }, (_, i) => String(i));
      const values = labels.map((_, i) => binomPmf(n, p, i));
      return { labels, values };
    }
    if (dist === "poisson") {
      const K = Math.max(15, Math.ceil(lam * 3));
      const labels = Array.from({ length: K + 1 }, (_, i) => String(i));
      const values = labels.map((_, i) => poissonPmf(lam, i));
      return { labels, values };
    }
    const M = 40;
    const labels = Array.from({ length: M + 1 }, (_, i) => fmt(mu - 4 * sd + (8 * sd * i) / M, 1));
    const values = labels.map((_, i) => normPdf(mu - 4 * sd + (8 * sd * i) / M, mu, sd));
    return { labels, values };
  }, [dist, n, p, lam, mu, sd]);

  const prob = useMemo(() => {
    if (dist === "binomial") {
      const eq = binomPmf(n, p, kq);
      const le = Array.from({ length: kq + 1 }, (_, i) => binomPmf(n, p, i)).reduce((a, b) => a + b, 0);
      return { eq, le };
    }
    if (dist === "poisson") {
      const eq = poissonPmf(lam, kq);
      let le = 0;
      for (let i = 0; i <= kq; i++) le += poissonPmf(lam, i);
      return { eq, le };
    }
    return null;
  }, [dist, n, p, lam, kq]);

  return (
    <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
      <div className="card h-fit space-y-4 p-5">
        <div className="flex gap-2">
          {([["binomial", "دوجمله‌ای"], ["normal", "نرمال"], ["poisson", "پواسون"]] as const).map(([id, fa]) => (
            <button key={id} onClick={() => setDist(id)} className={`btn flex-1 !text-xs ${dist === id ? "!border-accent !text-accent" : ""}`}>{fa}</button>
          ))}
        </div>
        {dist === "binomial" && (
          <>
            <TeX block>{"P(X=k)=\\binom{n}{k}p^k(1-p)^{n-k}"}</TeX>
            <label className="block text-xs text-muted">n = {n}
              <input type="range" min={2} max={30} value={n} onChange={(e) => setN(Number(e.target.value))} className="w-full" /></label>
            <label className="block text-xs text-muted">p = {p}
              <input type="range" min={0.05} max={0.95} step={0.05} value={p} onChange={(e) => setP(Number(e.target.value))} className="w-full" /></label>
            <label className="block text-xs text-muted">k برای P(X=k) و P(X≤k): {kq}
              <input type="range" min={0} max={n} value={kq} onChange={(e) => setKq(Number(e.target.value))} className="w-full" /></label>
            <p className="text-xs text-muted">امید ریاضی: <span dir="ltr" className="font-mono">np = {fmt(n * p)}</span> — واریانس: <span dir="ltr" className="font-mono">{fmt(n * p * (1 - p))}</span></p>
          </>
        )}
        {dist === "poisson" && (
          <>
            <TeX block>{"P(X=k)=\\frac{\\lambda^k e^{-\\lambda}}{k!}"}</TeX>
            <label className="block text-xs text-muted">λ = {lam}
              <input type="range" min={0.5} max={15} step={0.5} value={lam} onChange={(e) => setLam(Number(e.target.value))} className="w-full" /></label>
            <label className="block text-xs text-muted">k: {kq}
              <input type="range" min={0} max={20} value={kq} onChange={(e) => setKq(Number(e.target.value))} className="w-full" /></label>
            <p className="text-xs text-muted">امید و واریانس هر دو برابر λ هستند.</p>
          </>
        )}
        {dist === "normal" && (
          <>
            <TeX block>{"f(x)=\\frac{1}{\\sigma\\sqrt{2\\pi}} e^{-\\frac{(x-\\mu)^2}{2\\sigma^2}}"}</TeX>
            <label className="block text-xs text-muted">μ = {mu}
              <input type="range" min={-5} max={5} step={0.5} value={mu} onChange={(e) => setMu(Number(e.target.value))} className="w-full" /></label>
            <label className="block text-xs text-muted">σ = {sd}
              <input type="range" min={0.5} max={3} step={0.25} value={sd} onChange={(e) => setSd(Number(e.target.value))} className="w-full" /></label>
            <div className="rounded-xl bg-surface2 p-3 text-xs leading-6" dir="ltr">
              <div>P(μ−σ ≤ X ≤ μ+σ) ≈ {fmt(normCdf(mu + sd, mu, sd) - normCdf(mu - sd, mu, sd))}</div>
              <div>P(μ−2σ ≤ X ≤ μ+2σ) ≈ {fmt(normCdf(mu + 2 * sd, mu, sd) - normCdf(mu - 2 * sd, mu, sd))}</div>
              <div>P(X ≤ μ) = {fmt(normCdf(mu, mu, sd))}</div>
            </div>
            <p className="text-[10px] text-muted">محاسبه‌ی Φ از تقریب Abramowitz–Stegun با خطای &lt; ۱٫۵×۱۰⁻⁷.</p>
          </>
        )}
      </div>
      <div className="space-y-4">
        <div className="card p-4">
          <h3 className="mb-2 text-sm font-bold">{dist === "normal" ? "چگالی احتمال (PDF)" : "تابع جرم احتمال (PMF)"}</h3>
          <Bars labels={chart.labels} values={chart.values} color={dist === "normal" ? "#60a5fa" : "#2dd4bf"} />
        </div>
        {prob && (
          <div className="card grid grid-cols-2 gap-3 p-4 text-center" dir="ltr">
            <div className="rounded-xl bg-accentsoft/40 p-4">
              <div className="text-xs text-muted">P(X = {kq})</div>
              <div className="mt-1 font-mono text-xl font-bold text-accent">{fmt(prob.eq, 6)}</div>
            </div>
            <div className="rounded-xl bg-surface2 p-4">
              <div className="text-xs text-muted">P(X ≤ {kq})</div>
              <div className="mt-1 font-mono text-xl font-bold">{fmt(prob.le, 6)}</div>
            </div>
          </div>
        )}
        {dist === "normal" && (
          <div className="card p-4 text-xs leading-7 text-muted">
            قاعدهٔ تجربی ۶۸–۹۵–۹۹٫۷ برای توزیع نرمال برقرار است؛ این مقادیر از Φ محاسبه می‌شوند نه حفظی.
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------------------- regression ---------------------------- */

function Regression() {
  const [raw, setRaw] = useState("1, 2.1\n2, 3.9\n3, 6.2\n4, 7.8\n5, 10.1\n6, 12.2");
  const pts = useMemo(() => {
    return raw.split(/\n+/).map((l) => parseDataset(l.replace(",", " "))).filter((a) => a.length >= 2).map((a) => [a[0], a[1]] as const);
  }, [raw]);

  const reg = useMemo(() => {
    const n = pts.length;
    if (n < 2) return null;
    const mx = pts.reduce((a, [x]) => a + x, 0) / n;
    const my = pts.reduce((a, [, y]) => a + y, 0) / n;
    const sxx = pts.reduce((a, [x]) => a + (x - mx) ** 2, 0);
    const syy = pts.reduce((a, [, y]) => a + (y - my) ** 2, 0);
    const sxy = pts.reduce((a, [x, y]) => a + (x - mx) * (y - my), 0);
    if (sxx === 0) return null;
    const b = sxy / sxx;
    const a0 = my - b * mx;
    const r = syy === 0 ? 0 : sxy / Math.sqrt(sxx * syy);
    const sse = pts.reduce((acc, [x, y]) => acc + (y - (a0 + b * x)) ** 2, 0);
    return { a0, b, r, r2: r * r, sse, n };
  }, [pts]);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = canvasRef.current;
    if (!c || !reg || !pts.length) return;
    const W = c.clientWidth, H = 260;
    const dpr = Math.min(devicePixelRatio, 2);
    c.width = W * dpr; c.height = H * dpr;
    const ctx = c.getContext("2d")!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    const xs = pts.map(([x]) => x), ys = pts.map(([, y]) => y);
    const x0 = Math.min(...xs), x1 = Math.max(...xs);
    const y0 = Math.min(...ys), y1 = Math.max(...ys);
    const padX = (x1 - x0) * 0.1 || 1, padY = (y1 - y0) * 0.15 || 1;
    const px = (x: number) => 30 + ((x - (x0 - padX)) / (x1 - x0 + 2 * padX)) * (W - 50);
    const py = (y: number) => H - 25 - ((y - (y0 - padY)) / (y1 - y0 + 2 * padY)) * (H - 50);
    ctx.strokeStyle = "#2dd4bf";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(px(x0 - padX), py(reg.a0 + reg.b * (x0 - padX)));
    ctx.lineTo(px(x1 + padX), py(reg.a0 + reg.b * (x1 + padX)));
    ctx.stroke();
    ctx.fillStyle = "#f472b6";
    pts.forEach(([x, y]) => {
      ctx.beginPath(); ctx.arc(px(x), py(y), 4.5, 0, Math.PI * 2); ctx.fill();
      // residual
      ctx.strokeStyle = "#f472b655";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(px(x), py(y)); ctx.lineTo(px(x), py(reg.a0 + reg.b * x)); ctx.stroke();
    });
  }, [reg, pts]);

  return (
    <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
      <div className="card h-fit p-5">
        <label className="mb-2 block text-sm font-bold">جفت‌های (x , y) — هر خط یک نقطه</label>
        <textarea className="input min-h-40 font-mono text-xs" dir="ltr" value={raw} onChange={(e) => setRaw(e.target.value)} />
        <p className="mt-2 text-xs text-muted">{pts.length} نقطه معتبر.</p>
        <TeX block>{"b = \\frac{\\sum (x_i-\\bar x)(y_i-\\bar y)}{\\sum (x_i-\\bar x)^2}, \\qquad a = \\bar y - b\\bar x"}</TeX>
      </div>
      <div className="space-y-4">
        {reg ? (
          <>
            <div className="card grid grid-cols-2 gap-3 p-4 text-center sm:grid-cols-4" dir="ltr">
              {[
                ["شیب b", fmt(reg.b)],
                ["عرض از مبدأ a", fmt(reg.a0)],
                ["همبستگی r", fmt(reg.r)],
                ["تعیین R²", fmt(reg.r2)],
              ].map(([l, v]) => (
                <div key={l} className="rounded-xl bg-surface2 p-3">
                  <div className="text-[11px] text-muted">{l}</div>
                  <div className="mt-1 font-mono text-lg font-bold text-accent">{v}</div>
                </div>
              ))}
            </div>
            <div className="card p-4">
              <h3 className="mb-1 text-sm font-bold">نمودار پراکندگی + خط کمترین مربعات</h3>
              <canvas ref={canvasRef} className="w-full" style={{ height: 260 }} />
              <p className="mt-1 text-[11px] text-muted">خطوط صورتی «باقیمانده»‌ها هستند؛ روش کمترین مربعات، مجموع مربعات همین‌ها را کمینه می‌کند (SSE = <span dir="ltr" className="font-mono">{fmt(reg.sse)}</span>).</p>
            </div>
            <div className="card p-4 text-sm">
              معادله خط: <TeX block>{`\\hat y = ${fmt(reg.a0)} ${reg.b >= 0 ? "+" : "-"} ${fmt(Math.abs(reg.b))}\\,x`}</TeX>
            </div>
          </>
        ) : (
          <div className="card grid h-32 place-items-center text-sm text-muted">حداقل دو نقطه با x غیریکسان لازم است.</div>
        )}
      </div>
    </div>
  );
}

/* ---------------------------- simulation ---------------------------- */

function Simulation() {
  const [sim, setSim] = useState<"coin" | "clt">("coin");
  const [p, setP] = useState(0.5);
  const [dice, setDice] = useState(5);
  const [result, setResult] = useState<{ labels: string[]; values: number[]; note: string } | null>(null);
  const running = useRef(false);
  const [progress, setProgress] = useState(0);

  const run = () => {
    if (running.current) return;
    running.current = true;
    setProgress(0);
    setResult(null);
    if (sim === "coin") {
      const N = 2000;
      const check = [10, 50, 100, 500, 2000];
      let heads = 0;
      const labels: string[] = [];
      const values: number[] = [];
      let i = 0;
      const stepN = () => {
        for (let k = 0; k < 50 && i < N; k++, i++) if (Math.random() < p) heads++;
        if (check.includes(i)) {
          labels.push(String(i));
          values.push(heads / i);
        }
        setProgress(i / N);
        if (i < N) requestAnimationFrame(stepN);
        else {
          running.current = false;
          setResult({ labels, values, note: `نسبت شیرها به ${fmt(heads / N)} میل کرد — قانون اعداد بزرگ در عمل. مقدار نظری p = ${p}` });
        }
      };
      requestAnimationFrame(stepN);
    } else {
      const trials = 3000;
      const means: number[] = [];
      const chunk = 300;
      let i = 0;
      const stepN = () => {
        for (let k = 0; k < chunk && i < trials; k++, i++) {
          let s = 0;
          for (let d = 0; d < dice; d++) s += 1 + Math.floor(Math.random() * 6);
          means.push(s / dice);
        }
        setProgress(i / trials);
        if (i < trials) requestAnimationFrame(stepN);
        else {
          running.current = false;
          const bins = 20;
          const counts = new Array(bins).fill(0);
          means.forEach((m) => {
            const b = Math.min(bins - 1, Math.floor(((m - 1) / 5) * bins));
            counts[b]++;
          });
          setResult({
            labels: counts.map((_, i) => fmt(1 + ((i + 0.5) * 5) / bins, 1)),
            values: counts.map((c) => c / trials),
            note: `میانگین ${dice} تاس در ${trials} آزمایش: شکل زنگوله‌ای نرمال پدیدار شد — قضیه حد مرکزی. امید نظری = ۳٫۵، واریانس نظری میانگین = ${fmt(35 / 12 / dice)}.`,
          });
        }
      };
      requestAnimationFrame(stepN);
    }
  };

  return (
    <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
      <div className="card h-fit space-y-4 p-5">
        <div className="flex gap-2">
          <button onClick={() => { setSim("coin"); setResult(null); }} className={`btn flex-1 !text-xs ${sim === "coin" ? "!border-accent !text-accent" : ""}`}>همگرایی پرتاب سکه</button>
          <button onClick={() => { setSim("clt"); setResult(null); }} className={`btn flex-1 !text-xs ${sim === "clt" ? "!border-accent !text-accent" : ""}`}>قضیه حد مرکزی</button>
        </div>
        {sim === "coin" ? (
          <>
            <p className="text-xs leading-6 text-muted">سکه با احتمال شیر p را ۲۰۰۰ بار پرتاب می‌کنیم و نسبت شیرها را در نقاط ۱۰، ۵۰، …، ۲۰۰۰ ثبت می‌کنیم.</p>
            <label className="block text-xs text-muted">p = {p}
              <input type="range" min={0.1} max={0.9} step={0.05} value={p} onChange={(e) => { setP(Number(e.target.value)); setResult(null); }} className="w-full" /></label>
            <TeX block>{"\\hat p_n \\xrightarrow{n\\to\\infty} p \\quad (\\text{قانون اعداد بزرگ})"}</TeX>
          </>
        ) : (
          <>
            <p className="text-xs leading-6 text-muted">میانگین n تاس سالم را ۳۰۰۰ بار ثبت می‌کنیم. هرچه داده‌ی خام یکنواخت باشد، میانگین نمونه به نرمال میل می‌کند.</p>
            <label className="block text-xs text-muted">تعداد تاس‌ها در هر آزمایش: {dice}
              <input type="range" min={2} max={20} value={dice} onChange={(e) => { setDice(Number(e.target.value)); setResult(null); }} className="w-full" /></label>
            <TeX block>{"\\bar X_n \\;\\dot{\\sim}\\; \\mathcal N(\\mu, \\sigma^2/n) \\quad (\\text{CLT})"}</TeX>
          </>
        )}
        <button onClick={run} className="btn btn-primary w-full justify-center" disabled={running.current}>
          اجرای شبیه‌سازی {progress > 0 && progress < 1 ? `(${Math.round(progress * 100)}٪)` : ""}
        </button>
      </div>
      <div className="space-y-4">
        {result ? (
          <>
            <div className="card p-4">
              <Bars labels={result.labels} values={result.values} color={sim === "coin" ? "#fbbf24" : "#a78bfa"} height={230} />
            </div>
            <div className="card p-4 text-sm leading-7">{result.note}</div>
          </>
        ) : (
          <div className="card grid h-40 place-items-center text-sm text-muted">شبیه‌سازی را اجرا کنید.</div>
        )}
      </div>
    </div>
  );
}
