"use client";

import Link from "next/link";
import { Bookmark, Eraser, History, TrendingUp } from "lucide-react";
import { ALL_LESSONS } from "@/data/lessons";
import { useBookmarks, useNotes, useProgress } from "@/lib/store";

const TOOL_FA: Record<string, string> = {
  lab: "آزمایشگاه",
  calculator: "ماشین‌حساب",
  solver: "حل‌گر ریاضی",
  "physics-solver": "حل‌گر فیزیک",
  stats: "آمار و احتمال",
};

export default function ProgressPage() {
  const { progress } = useProgress();
  const { bookmarks } = useBookmarks();
  const { notes } = useNotes();

  const done = progress.completedLessons.length;
  const visited = progress.visitedLessons.length;
  const { answered, correct, byTopic } = progress.exerciseStats;
  const acc = answered ? Math.round((correct / answered) * 100) : 0;

  const lessons = (key: string) => {
    const [academy, id] = key.split("/");
    return ALL_LESSONS.find((l) => l.academy === academy && l.id === id);
  };

  return (
    <div className="fade-up">
      <h1 className="section-title mb-2 flex items-center gap-2">
        <TrendingUp className="size-7 text-accent" /> پیشرفت یادگیری
      </h1>
      <p className="mb-6 text-sm leading-7 text-muted">
        همه‌ی این داده‌ها فقط در مرورگر همین دستگاه ذخیره می‌شود (localStorage) — بدون حساب کاربری و بدون ارسال
        به سرور. با پاک کردن داده‌های مرورگر حذف می‌شوند.
      </p>

      <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { n: done, label: "درس تکمیل‌شده", sub: `از ${ALL_LESSONS.length} درس آماده` },
          { n: visited, label: "درس بازدیدشده", sub: "" },
          { n: answered, label: "تمرین پاسخ‌داده‌شده", sub: `${correct} درست` },
          { n: `${acc}٪`, label: "دقت تمرین‌ها", sub: "" },
        ].map((s) => (
          <div key={s.label} className="card p-4 text-center">
            <div className="text-3xl font-black text-accent">{s.n}</div>
            <div className="mt-1 text-xs font-medium">{s.label}</div>
            {s.sub && <div className="text-[10px] text-muted">{s.sub}</div>}
          </div>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <section className="card p-5">
          <h2 className="mb-4 text-sm font-bold">دقت بر اساس موضوع</h2>
          {Object.keys(byTopic).length === 0 && <p className="text-xs text-muted">هنوز تمرینی انجام نداده‌اید؛ از مرکز تمرین شروع کنید.</p>}
          <div className="space-y-3">
            {Object.entries(byTopic).map(([t, s]) => (
              <div key={t}>
                <div className="mb-1 flex justify-between text-xs">
                  <span>{t}</span>
                  <span className="text-muted" dir="ltr">{s.correct}/{s.answered}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-surface2">
                  <div
                    className="h-full rounded-full bg-gradient-to-l from-accent to-accent2 transition-all duration-700"
                    style={{ width: `${(s.correct / Math.max(1, s.answered)) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="card p-5">
          <h2 className="mb-4 flex items-center gap-2 text-sm font-bold">
            <History className="size-4 text-accent" /> درس‌های اخیر
          </h2>
          {progress.visitedLessons.length === 0 && <p className="text-xs text-muted">هنوز درسی باز نکرده‌اید.</p>}
          <ul className="space-y-1.5">
            {progress.visitedLessons.slice(-6).reverse().map((key) => {
              const l = lessons(key);
              if (!l) return null;
              const isDone = progress.completedLessons.includes(key);
              return (
                <li key={key}>
                  <Link href={`/academy/${l.academy}/${l.id}`} className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm hover:bg-surface2">
                    <span className={`size-2 shrink-0 rounded-full ${isDone ? "bg-accent" : "bg-line"}`} />
                    <span className="flex-1">{l.title}</span>
                    <span className="text-[10px] text-muted">{l.subject}</span>
                  </Link>
                </li>
              );
            })}
          </ul>

          <h2 className="mb-3 mt-6 flex items-center gap-2 text-sm font-bold">
            <Bookmark className="size-4 text-accent" /> نشانه‌گذاری‌ها ({bookmarks.length})
          </h2>
          {bookmarks.length === 0 && <p className="text-xs text-muted">درس یا منبعی را نشانه‌گذاری کنید.</p>}
          <div className="flex flex-wrap gap-2">
            {bookmarks.map((b) => {
              const l = b.startsWith("lib/") ? null : lessons(b);
              return l ? (
                <Link key={b} href={`/academy/${l.academy}/${l.id}`} className="chip hover:!border-accent hover:!text-accent">{l.title}</Link>
              ) : (
                <Link key={b} href="/library" className="chip hover:!border-accent hover:!text-accent">{b}</Link>
              );
            })}
          </div>

          <h2 className="mb-3 mt-6 text-sm font-bold">استفاده از ابزارها</h2>
          {Object.keys(progress.toolUsage).length === 0 && <p className="text-xs text-muted">—</p>}
          <div className="flex flex-wrap gap-2">
            {Object.entries(progress.toolUsage).map(([k, v]) => (
              <span key={k} className="chip">{TOOL_FA[k] ?? k}: {v} بار</span>
            ))}
          </div>

          <h2 className="mb-2 mt-6 text-sm font-bold">یادداشت‌ها</h2>
          <p className="text-xs text-muted">{Object.values(notes).filter((n) => n.trim()).length} یادداشت ذخیره‌شده.</p>

          <button
            className="btn mt-6 !border-danger/50 !text-xs !text-danger"
            onClick={() => {
              if (confirm("همه‌ی پیشرفت، نشانه‌ها و یادداشت‌ها از این دستگاه حذف شود؟")) {
                ["mv-progress-v1", "mv-bookmarks-v1", "mv-notes-v1", "mv-calc-history-v1"].forEach((k) => localStorage.removeItem(k));
                location.reload();
              }
            }}
          >
            <Eraser className="size-3.5" /> حذف کامل داده‌های محلی
          </button>
        </section>
      </div>
    </div>
  );
}
