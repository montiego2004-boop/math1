"use client";

import { useRef, useState } from "react";
import dynamic from "next/dynamic";
import Surface3D, { type Surface3DScene } from "@/components/surface3d";
import { ModeToggle, GuidePanel, SceneSaver, type Mode, type Guide } from "@/components/studio-ui";

const QuadricsModule = dynamic(() => import("@/components/studio3d/quadrics"), { ssr: false, loading: () => <div className="card grid h-96 place-items-center text-muted">بارگذاری سه‌بعدی…</div> });
const ParametricModule = dynamic(() => import("@/components/studio3d/parametric"), { ssr: false, loading: () => <div className="card grid h-96 place-items-center text-muted">بارگذاری سه‌بعدی…</div> });
const MultivarModule = dynamic(() => import("@/components/studio3d/multivar"), { ssr: false, loading: () => <div className="card grid h-96 place-items-center text-muted">بارگذاری سه‌بعدی…</div> });
const Vector3DModule = dynamic(() => import("@/components/studio3d/vector3d"), { ssr: false, loading: () => <div className="card grid h-96 place-items-center text-muted">بارگذاری سه‌بعدی…</div> });

const MODULES: { id: string; fa: string; guide: Guide }[] = [
  {
    id: "surface",
    fa: "سطوح z = f(x,y)",
    guide: {
      intro: "هر تابع دو متغیره یک سطح است. ارتفاع هر نقطه مقدار تابع است و رنگ بر حسب ارتفاع تغییر می‌کند.",
      steps: ["زین ناهمسانگرد x²−y² را بچرخانید", "موج را با برد بزرگ‌تر ببینید", "حالت شبکه را برای دیدن مش بزنید"],
      tryIt: ["x^2 + y^2", "sin(x)*cos(y)", "sqrt(max(0, 16-x^2-y^2)) نیم‌کره"],
    },
  },
  {
    id: "quadrics",
    fa: "کوادریک‌ها",
    guide: {
      intro: "سطوح درجهٔ دو — کره، مخروط، استوانه، سهموی‌ها و هذلولی‌گون‌ها — خانوادهٔ کامل کوادریک‌ها را می‌سازند؛ علامت ضرایب A,B,C,K نوع را تعیین می‌کند.",
      steps: ["هشت خانواده را جست‌وجو کنید", "در فرم کلی C → 0 یعنی نقص به استوانه/پارابولوئید", "یک‌پاره و دوپاره را از نظر علامت‌ها قیاس کنید"],
      formulas: ["\\frac{x^2}{a^2}+\\frac{y^2}{b^2}+\\frac{z^2}{c^2}=1", "\\frac{x^2}{a^2}+\\frac{y^2}{b^2}-\\frac{z^2}{c^2}=1"],
    },
  },
  {
    id: "parametric",
    fa: "سطوح پارامتری و خم‌ها",
    guide: {
      intro: "سطوح پارامتری با دو پارامتر u,v نوشته می‌شوند؛ خم‌های فضایی با یک پارامتر t. قاب فرنه T,N,B هندسهٔ محلی خم را توصیف می‌کند.",
      steps: ["نوار موبیوس را ببینید — یک وجه دارد!", "روی خم مارپیچ، κ و τ ثابت می‌مانند", "سرعت نقطه را تغییر دهید و قاب TNB را دنبال کنید"],
      formulas: ["\\kappa = \\frac{|r'\\times r''|}{|r'|^3}", "\\tau = \\frac{(r'\\times r'')\\cdot r'''}{|r'\\times r''|^2}"],
    },
  },
  {
    id: "multivar",
    fa: "حساب چندمتغیره",
    guide: {
      intro: "خطوط هم‌تراز، برش‌های عمودی، صفحهٔ مماس و گرادیان چهار نگاه به یک سطح‌اند.",
      steps: ["نقطهٔ تماس را حرکت دهید; نزدیک ∇f≈0 نقطهٔ بحرانی است", "صفحهٔ برش x=x₀ با سطح، یک خم دوبعدی می‌سازد", "انتگرال دوگانه = حجم زیر سطح (این‌جا تقریب عددی)"],
      formulas: ["\\nabla f = (f_x, f_y)", "z = f_0 + f_x\\Delta x + f_y \\Delta y", "\\iint_D f\\,dA"],
    },
  },
  {
    id: "field3d",
    fa: "میدان برداری سه‌بعدی",
    guide: {
      intro: "در هر نقطهٔ فضا یک پیکان؛ واگرایی «میزان تولید جریان» و پیچش (curl) «چگونگی چرخیدن» میدان است.",
      steps: ["چشمه (x,y,z) را ببینید: div>0", "چرخهٔ (−y,x,0): div=0 و curl≠0", "خط جریان صورتی از پروب زرد عبور می‌کند"],
      formulas: ["\\nabla\\cdot\\vec F", "\\nabla\\times\\vec F", "\\oiint_S \\vec F\\cdot d\\vec A = \\iiint_V \\nabla\\cdot\\vec F\\,dV"],
    },
  },
];

export default function Graph3DStudio() {
  const [mod, setMod] = useState("surface");
  const [mode, setMode] = useState<Mode>("explore");
  const sceneRef = useRef<unknown>(null);
  const [loadScene, setLoadScene] = useState<Surface3DScene | undefined>(undefined);
  const [remountKey, setRemountKey] = useState(0);
  const guide = MODULES.find((m) => m.id === mod)?.guide;

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {MODULES.map((m) => (
          <button key={m.id} onClick={() => setMod(m.id)} className={`btn !text-xs ${mod === m.id ? "!border-accent !bg-accentsoft !text-accent" : ""}`}>
            {m.fa}
          </button>
        ))}
        <div className="mr-auto">
          <ModeToggle mode={mode} onChange={setMode} />
        </div>
      </div>

      <GuidePanel guide={guide} mode={mode} />

      <div className="mt-3">
        {mod === "surface" && <Surface3D key={remountKey} initialScene={loadScene} onSceneChange={(s) => { sceneRef.current = s; }} />}
        {mod === "quadrics" && <QuadricsModule />}
        {mod === "parametric" && <ParametricModule />}
        {mod === "multivar" && <MultivarModule />}
        {mod === "field3d" && <Vector3DModule />}
      </div>

      {mod === "surface" && (
        <div className="mt-4">
          <SceneSaver
            storageKey="graph3d"
            serialize={() => sceneRef.current}
            apply={(data) => {
              setLoadScene(data as Surface3DScene);
              setRemountKey((k) => k + 1);
            }}
          />
        </div>
      )}
    </div>
  );
}
