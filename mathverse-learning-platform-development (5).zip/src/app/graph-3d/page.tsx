import type { Metadata } from "next";
import dynamic from "next/dynamic";

export const metadata: Metadata = { title: "ریاضیات سه‌بعدی تعاملی" };

const Graph3DStudio = dynamic(() => import("./studio"), {
  loading: () => <div className="card grid h-96 place-items-center text-muted">در حال بارگذاری استودیوی سه‌بعدی (Three.js)…</div>,
});

export default function Graph3DPage() {
  return (
    <div className="fade-up">
      <h1 className="section-title mb-2">استودیوی ریاضیات سه‌بعدی</h1>
      <p className="mb-6 text-sm leading-7 text-muted">
        سطوح z = f(x,y)، کوادریک‌ها، سطوح پارامتری و خم‌های فضایی با قاب فرنه، حساب چندمتغیره (هم‌تراز، مماس، گرادیان،
        انتگرال دوگانه) و میدان‌های برداری سه‌بعدی — همهٔ ماژول‌ها بر‌اساس-تقاضا با Three.js بارگذاری می‌شوند.
      </p>
      <Graph3DStudio />
    </div>
  );
}
