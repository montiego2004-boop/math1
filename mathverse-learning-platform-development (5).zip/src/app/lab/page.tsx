"use client";

import { useEffect, useState } from "react";
import { FlaskConical } from "lucide-react";
import { EXPERIMENTS } from "@/components/lab-experiments";
import { EXPERIMENTS_2 } from "@/components/lab-experiments-2";
import { useProgress } from "@/lib/store";
import { ModeToggle, GuidePanel, type Mode, type Guide } from "@/components/studio-ui";

const ALL_EXPERIMENTS = [...EXPERIMENTS, ...EXPERIMENTS_2];

const GUIDES: Record<string, Guide> = {
  projectile: {
    intro: "مسیر پرتابه ترکیبِ حرکت یکنواخت افقی و شتاب‌دار عمودی است.",
    steps: ["بدون مقاومت برد را با R = v₀²sin2θ/g مقایسه کنید", "مقاومت را روشن کنید — مسیر فیروزه‌ای از خط‌چین آبی جدا می‌شود", "زاویهٔ بهینهٔ واقعی کمتر از ۴۵° می‌شود"],
    tryIt: ["θ=45 بدون مقاومت", "θ=35 با مقاومت 0.02"],
  },
  freefall: { intro: "مقاومت هوا سرعت را به v_t = mg/b محدود می‌کند.", steps: ["نمودار صورتی به خط چین v_t میل می‌کند", "جرم بیشتر = vf بالاتر", "b=0 نمودار = خط راست v=gt"] },
  pendulum: { intro: "آونگ فقط در زاویهٔ کوچک «هماهنگ ساده» است.", steps: ["T اندازه‌گیری‌شده با T خطی را مقایسه کنید", "θ₀=۸۰° را با θ₀=۱۰° قیاس کنید", "میرایی γ انرژی را می‌کاهد"] },
  spring: { intro: "انرژی بین K و U رفت‌و‌برگشت می‌کند؛ جمعشان در عدم میرایی ثابت است.", steps: ["c=0 نوسان ماندگار", "c بزرگ = میرایی فراشد", "k↑ → تناوب ↓"] },
  collision: { intro: "در برخورد کشسان هم p و هم K پایسته‌اند.", steps: ["m₁=m₂ انتقال کامل سرعت", "m₁≫m₂ گلولهٔ سبک دو برابر سرعت برمی‌گردد"] },
  wave: { intro: "گره‌ها جاهایی‌اند که دو موج مخالف همیشه خنثی می‌شوند.", steps: ["n را عوض کنید — λ=2L/n", "موج پیش‌رونده را با ایستاده قیاس کنید"] },
  efield: { intro: "میدان، کمیت برداری است و برهم‌نهیِ کولن است.", steps: ["دو بار هم‌نام → خط‌هایی که هم را نمی‌برید", "بار ناهمنام = دوقطبی الکتریکی", "چگالی خط ∝ شدت"] },
  incline: { intro: "شرط سکون فقط به tanθ و μs بستگی دارد، نه جرم!", steps: ["μs=0.4 را با چند θ آزمایش و آستانه tanθ=μs را بررسی کنید", "جرم را تغییر دهید — هیچ تغییری در شرط نمی‌بینید", "همچنین: N کمتر از mg است"] },
  "double-pendulum": { intro: "آونگ دوگانه ساده‌ترین سیستم نمایش‌دهندهٔ آشوب است.", steps: ["شرایط اولیه را ۱ درجه عوض کنید و بعداً مقایسه کنید", "انرژی ثابت می‌ماند ولی مسیر هرگز تکرار نمی‌شود"] },
  resonance: { intro: "دامنهٔ پاسخ در ω≈ω₀ به اوج می‌رسد و میرایی آن را مهار می‌کند.", steps: ["ω_d را از خیلی کم به بالای ω₀ ببرید", "β=0.1 با β=1 قیاس کنید", "پل تاکوما: رزونانس مخرب!"] },
  interference: { intro: "نوارهای هذلولی‌وار سازنده/مخرب نتیجه‌ی اختلاف راه رفت موج‌اند.", steps: ["λ را عوض کنید", "d↑ → نوارها ریزتر", "Δφ=π جای سازنده و مخرب را عوض می‌کند"] },
  lorentz: { intro: "نیروی عمود بر سرعت، مسیر دایره‌ای می‌سازد و سرعت را تغییر نمی‌دهد.", steps: ["q منفی → چرخش معکوس", "B↑ → r کوچک‌تر", "T= ربعts به v بستگی ندارد"] },
  induction: { intro: "ε بین Φ و زمان است نه خود شار — علامت منفی، لنز است.", steps: ["حرکت تندتر → ε بزرگ‌تر", "N↑ → ε متناسب بزرگ‌تر", "نمودارها سینوس و کسینوس‌اند"] },
  lens: { intro: "عدسی نازک: دو پرتو اصلی کافی‌اند تا تصویر را پیدا کنید.", steps: ["do>2f تصویر کوچک وارونه", "do<f تصویر مجازی مستقیم (ذره‌بین)", "مقعر همیشه مجازی کوچک"] },
  carnot: { intro: "مساحت چرخه = کار خالص؛ بازده به نسبت دماها محدود است.", steps: ["TC/TH ↓ → η↑", "QH فقط از لن‌۳ است (۱→۲)", "مقایسهٔ η محاسبه‌شده با نظری"] },
  relativity: { intro: "فقط یک ثابت: سرعت نور. اثرات: گسسته نیستند—فیزیک کلاسیک β≪۱ تقریب آن است.", steps: ["β=0.99 → γ≈7", "میون 0.995c کلاسیکی فقط ~۶۶۰ متر می‌آید ولی با γ≈10 به سطح می‌رسد"] },
  quantum: { intro: "در چاه نامتناهی فقط برخی ψها «می‌گنجند» — انرژی گسسته می‌شود.", steps: ["n↑ → گره‌های بیشتر، E با n² بالا می‌رود", "شبیه‌سازی‌گیری: نقاط زرد به |ψ|² میل می‌کنند", "L↑ → ترازها فشرده‌تر"] },
};

export default function LabPage() {
  const [active, setActive] = useState(EXPERIMENTS[0].id);
  const [mode, setMode] = useState<Mode>("explore");
  const exp = ALL_EXPERIMENTS.find((e) => e.id === active)!;
  const { recordToolUse } = useProgress();
  useEffect(() => recordToolUse("lab"), [recordToolUse]);

  return (
    <div className="fade-up">
      <h1 className="section-title mb-2 flex items-center gap-2">
        <FlaskConical className="size-7 text-accent" /> آزمایشگاه ریاضی و فیزیک
      </h1>
      <p className="mb-4 text-sm leading-7 text-muted">
        {ALL_EXPERIMENTS.length} آزمایش تعاملی با معادلات حاکم، انتگرال‌گیر عددی RK4 و برچسب شفافِ تحلیلی/تقریبی.
        پارامترها را تغییر دهید و نتیجه را بی‌درنگ ببینید — مدل ساده‌شده هرگز به‌عنوان تصویر کامل واقعیت معرفی
        نمی‌شود (جعبهٔ «فرض‌ها و محدودیت‌ها» زیر هر آزمایش).
      </p>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <ModeToggle mode={mode} onChange={setMode} />
      </div>
      <div className="mb-5 flex max-h-32 flex-wrap gap-2 overflow-y-auto">
        {ALL_EXPERIMENTS.map((e) => (
          <button key={e.id} onClick={() => setActive(e.id)}
            className={`btn !text-[11px] ${active === e.id ? "!border-accent !bg-accentsoft !text-accent" : ""}`}>
            {e.fa}
          </button>
        ))}
      </div>
      <GuidePanel guide={GUIDES[active]} mode={mode} />
      <h2 className="mb-3 mt-4 text-lg font-bold">{exp.fa} <span className="text-xs font-normal text-muted" dir="ltr">({exp.en})</span></h2>
      <exp.C />
    </div>
  );
}
