"use client";

import { useEffect, useMemo, useState } from "react";
import { CheckCircle2, ChevronLeft, Dumbbell, RefreshCcw, XCircle } from "lucide-react";
import { DIFF_FA, EXERCISES, GENERATORS, type GeneratedQuestion } from "@/data/exercises";
import { useProgress } from "@/lib/store";
import { TeX } from "@/components/katex";
import { Inline } from "@/components/academy-browser";

const fmt = (x: number) => String(Math.round(x * 1e4) / 1e4);

export default function ExercisesPage() {
  const topics = useMemo(() => [...new Set(EXERCISES.map((e) => e.topic))], []);
  const [topic, setTopic] = useState<string>("همه");
  const [diff, setDiff] = useState<number>(0);
  const pool = useMemo(
    () => EXERCISES.filter((e) => (topic === "همه" || e.topic === topic) && (diff === 0 || e.difficulty === diff)),
    [topic, diff]
  );

  const [idx, setIdx] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const { recordExercise, progress } = useProgress();

  useEffect(() => {
    setIdx(0);
    setPicked(null);
  }, [topic, diff]);

  const ex = pool[idx % Math.max(pool.length, 1)];

  // generated practice
  const [genId, setGenId] = useState(GENERATORS[0].id);
  const gen = GENERATORS.find((g) => g.id === genId)!;
  const [gq, setGq] = useState<GeneratedQuestion>(() => gen.make());
  const [gInput, setGInput] = useState("");
  const [gState, setGState] = useState<"idle" | "ok" | "no" | "shown">("idle");

  useEffect(() => {
    setGq(gen.make());
    setGInput("");
    setGState("idle");
  }, [genId, gen]);

  const checkGenerated = () => {
    const v = Number(gInput);
    if (!isFinite(v)) return;
    const ok = Math.abs(v - gq.answer) <= gq.tolerance;
    setGState(ok ? "ok" : "no");
    recordExercise(gen.topic, ok);
  };

  return (
    <div className="fade-up">
      <h1 className="section-title mb-2 flex items-center gap-2">
        <Dumbbell className="size-7 text-accent" /> مرکز تمرین و تمرین‌سازی
      </h1>
      <p className="mb-5 text-sm leading-7 text-muted">
        پرسش‌های چندگزینه‌ای با پاسخ تشریحی + مولد تمرین تصادفی که جواب را محاسبه می‌کند (پس همیشه سازگار و
        صحیح است). آمار شما محلی و در صفحه «پیشرفت یادگیری» ذخیره می‌شود.
      </p>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* MCQ */}
        <section className="card p-5">
          <div className="mb-4 flex flex-wrap items-center gap-2">
            <h2 className="ml-auto text-sm font-bold">چندگزینه‌ای ({pool.length} سؤال)</h2>
            <select className="input !w-auto !py-1 !text-xs" value={topic} onChange={(e) => setTopic(e.target.value)}>
              <option>همه</option>
              {topics.map((t) => <option key={t}>{t}</option>)}
            </select>
            <select className="input !w-auto !py-1 !text-xs" value={diff} onChange={(e) => setDiff(Number(e.target.value))}>
              <option value={0}>همه سطوح</option>
              <option value={1}>آسان</option>
              <option value={2}>متوسط</option>
              <option value={3}>سخت</option>
            </select>
          </div>

          {ex ? (
            <div>
              <div className="mb-3 flex items-center gap-2 text-xs">
                <span className="chip !text-accent">{ex.topic}</span>
                <span className="chip">{DIFF_FA[ex.difficulty]}</span>
                <span className="chip" dir="ltr">{idx % pool.length + 1} / {pool.length}</span>
              </div>
              <p className="mb-1 text-sm leading-7 font-medium">{ex.question}</p>
              {ex.questionTex && <TeX block>{ex.questionTex}</TeX>}
              <div className="mt-4 space-y-2">
                {ex.choices.map((c, i) => {
                  const state = picked == null ? "idle" : i === ex.answer ? "right" : i === picked ? "wrong" : "dim";
                  return (
                    <button
                      key={i}
                      disabled={picked != null}
                      onClick={() => {
                        setPicked(i);
                        recordExercise(ex.topic, i === ex.answer);
                      }}
                      className={`flex w-full items-center gap-3 rounded-xl border p-3 text-right text-sm transition-all ${
                        state === "right"
                          ? "border-accent bg-accentsoft font-bold text-accent"
                          : state === "wrong"
                            ? "border-danger bg-danger/10 text-danger"
                            : state === "dim"
                              ? "border-line opacity-50"
                              : "border-line hover:border-accent"
                      }`}
                    >
                      <span className="chip !px-2">{["الف", "ب", "ج", "د"][i]}</span>
                      <span className="flex-1"><Inline s={c} /></span>
                      {state === "right" && <CheckCircle2 className="size-4" />}
                      {state === "wrong" && <XCircle className="size-4" />}
                    </button>
                  );
                })}
              </div>
              {picked != null && (
                <div className="mt-4 rounded-xl border border-line bg-surface2 p-4 text-sm leading-7">
                  <strong className={picked === ex.answer ? "text-accent" : "text-danger"}>
                    {picked === ex.answer ? "درست است ✓" : "نادرست — پاسخ درست مشخص شد."}
                  </strong>
                  <p className="mt-1">{ex.explanation}</p>
                  {ex.explanationTex && <TeX block>{ex.explanationTex}</TeX>}
                  <button className="btn mt-3 !text-xs" onClick={() => { setIdx((i) => i + 1); setPicked(null); }}>
                    سؤال بعدی <ChevronLeft className="size-3.5" />
                  </button>
                </div>
              )}
            </div>
          ) : (
            <p className="py-10 text-center text-sm text-muted">سؤالی با این فیلترها نیست.</p>
          )}
        </section>

        {/* Generated */}
        <section className="card h-fit p-5">
          <div className="mb-4 flex flex-wrap items-center gap-2">
            <h2 className="ml-auto text-sm font-bold">تمرین تولیدی (محاسبه‌شده)</h2>
            <select className="input !w-auto !py-1 !text-xs" value={genId} onChange={(e) => setGenId(e.target.value)}>
              {GENERATORS.map((g) => <option key={g.id} value={g.id}>{g.label}</option>)}
            </select>
          </div>
          <div className="mb-2 flex items-center gap-2 text-xs">
            <span className="chip !text-accent">{gen.topic}</span>
            <span className="chip">{DIFF_FA[gen.difficulty]}</span>
          </div>
          <p className="text-sm leading-7 font-medium">{gq.question}</p>
          {gq.questionTex && <TeX block>{gq.questionTex}</TeX>}

          <div className="mt-4 flex items-center gap-2">
            <input
              className="input flex-1 font-mono"
              dir="ltr"
              placeholder="پاسخ عددی…"
              value={gInput}
              disabled={gState === "ok"}
              onChange={(e) => setGInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && checkGenerated()}
            />
            {gq.unit && <span className="chip font-mono" dir="ltr">{gq.unit}</span>}
            <button className="btn btn-primary !text-xs" onClick={checkGenerated} disabled={gState === "ok"}>بررسی</button>
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            <button className="btn !text-xs" onClick={() => setGState("shown")} disabled={gState === "ok"}>نمایش راه‌حل گام‌به‌گام</button>
            <button className="btn !text-xs" onClick={() => { setGq(gen.make()); setGInput(""); setGState("idle"); }}>
              <RefreshCcw className="size-3.5" /> سؤال جدید
            </button>
          </div>

          {gState !== "idle" && (
            <div className={`mt-4 rounded-xl border p-4 text-sm leading-7 ${gState === "ok" ? "border-accent bg-accentsoft/40" : gState === "no" ? "border-danger/40 bg-danger/5" : "border-line bg-surface2"}`}>
              {gState === "ok" && <strong className="text-accent">درست است! ✓ (پاسخ دقیق: {fmt(gq.answer)})</strong>}
              {gState === "no" && <strong className="text-danger">نادرست — دوباره تلاش کنید یا راه‌حل را ببینید.</strong>}
              {(gState === "shown" || gState === "ok") && (
                <ol className="mt-2 space-y-2">
                  {gq.steps.map((s, i) => (
                    <li key={i} className="flex items-baseline gap-2">
                      <span className="chip !px-1.5 !text-[10px]">{i + 1}</span>
                      <span className="flex-1">
                        {s.text}
                        {s.tex && <TeX block>{s.tex}</TeX>}
                      </span>
                    </li>
                  ))}
                  <li className="text-accent">پاسخ نهایی: <span dir="ltr" className="font-mono">{fmt(gq.answer)}</span> {gq.unit ?? ""}</li>
                </ol>
              )}
            </div>
          )}
        </section>
      </div>

      <div className="card mt-6 flex flex-wrap items-center gap-4 p-4 text-sm">
        <span className="text-muted">آمار جلسه‌ی شما (محلی):</span>
        <span className="chip">{progress.exerciseStats.answered} پاسخ</span>
        <span className="chip !text-accent">{progress.exerciseStats.correct} درست</span>
        <span className="chip">دقت: {progress.exerciseStats.answered ? Math.round((progress.exerciseStats.correct / progress.exerciseStats.answered) * 100) : 0}٪</span>
      </div>
    </div>
  );
}
