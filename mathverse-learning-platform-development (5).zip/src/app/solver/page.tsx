"use client";

import { useEffect, useState } from "react";
import { create, all } from "mathjs";
import nerdamer from "nerdamer";
import { BadgeCheck, GaugeCircle, Sigma } from "lucide-react";
import { TeX } from "@/components/katex";
import { useProgress } from "@/lib/store";

const math = create(all);

type Mode = "equation" | "algebra" | "derivative" | "integral" | "limit" | "matrix" | "quadratic";

const MODES: { id: Mode; fa: string }[] = [
  { id: "quadratic", fa: "معادله درجهٔ دو (گام‌به‌گام)" },
  { id: "equation", fa: "معادله و دستگاه" },
  { id: "algebra", fa: "ساده‌سازی · بسط · تجزیه" },
  { id: "derivative", fa: "مشتق" },
  { id: "integral", fa: "انتگرال" },
  { id: "limit", fa: "حد (تقریب عددی)" },
  { id: "matrix", fa: "ماتریس" },
];

interface Out {
  kind: "exact" | "numeric";
  lines: { text: string; tex?: string }[];
}

export default function SolverPage() {
  const [mode, setMode] = useState<Mode>("quadratic");
  const [out, setOut] = useState<Out | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const { recordToolUse } = useProgress();
  useEffect(() => recordToolUse("solver"), [recordToolUse]);

  // inputs
  const [expr, setExpr] = useState("x^2 - 5x + 6 = 0");
  const [variable, setVariable] = useState("x");
  const [point, setPoint] = useState("2");
  const [lower, setLower] = useState("");
  const [upper, setUpper] = useState("");
  const [algExpr, setAlgExpr] = useState("(x+1)^3");
  const [algOp, setAlgOp] = useState<"simplify" | "expand" | "factor">("expand");
  const [qa, setQa] = useState("1");
  const [qb, setQb] = useState("-5");
  const [qc, setQc] = useState("6");
  const [matA, setMatA] = useState("[[3,1],[2,4]]");
  const [matOp, setMatOp] = useState<"det" | "inv" | "transpose">("det");

  const run = () => {
    setErr(null);
    setOut(null);
    try {
      switch (mode) {
        case "quadratic": {
          const a = Number(qa), b = Number(qb), c = Number(qc);
          if (![a, b, c].every(isFinite)) throw new Error("ضرایب باید عدد باشند.");
          if (a === 0) throw new Error("a نمی‌تواند صفر باشد (آن‌گاه معادله درجهٔ یک است).");
          const D = b * b - 4 * a * c;
          const lines: Out["lines"] = [
            { text: "فرم استاندارد و ضرایب:", tex: `ax^2+bx+c=0 \\Rightarrow a=${a},\\; b=${b},\\; c=${c}` },
            { text: "محاسبه‌ی دیسکریمینان:", tex: `\\Delta = b^2-4ac = (${b})^2 - 4(${a})(${c}) = ${D}` },
          ];
          if (D > 0) {
            const s = Math.sqrt(D);
            const x1 = (-b + s) / (2 * a), x2 = (-b - s) / (2 * a);
            lines.push(
              { text: "Δ > 0 پس دو ریشهٔ حقیقی متمایز:", tex: `x = \\frac{-(${b}) \\pm \\sqrt{${D}}}{2(${a})} = \\frac{${-b} \\pm ${fmtN(s)}}{${2 * a}}` },
              { text: "ریشه‌ها:", tex: `x_1 = ${fmtN(x1)}, \\qquad x_2 = ${fmtN(x2)}` }
            );
          } else if (D === 0) {
            const x = -b / (2 * a);
            lines.push({ text: "Δ = 0 پس یک ریشهٔ مضاعف:", tex: `x = \\frac{-b}{2a} = ${fmtN(x)}` });
          } else {
            const re = -b / (2 * a), im = Math.sqrt(-D) / (2 * a);
            lines.push({
              text: "Δ < 0 پس دو ریشهٔ مختلط مزدوج:",
              tex: `x = ${fmtN(re)} \\pm ${fmtN(Math.abs(im))}\\,i`,
            });
          }
          lines.push({ text: "آزمون ویت:", tex: `x_1 + x_2 = ${fmtN(-b / a)} = -\\frac{b}{a}, \\qquad x_1 x_2 = ${fmtN(c / a)} = \\frac{c}{a}` });
          setOut({ kind: "exact", lines });
          break;
        }
        case "equation": {
          const eqs = expr.split(/\n|;/).map((s) => s.trim()).filter(Boolean);
          const vars = variable.split(",").map((s) => s.trim()).filter(Boolean);
          const lines: Out["lines"] = [{ text: "پاسخ موتور جبری nerdamer (نمادین دقیق):" }];
          const texOf = (s: string) => {
            try {
              return (nerdamer(s) as any).toTeX();
            } catch {
              return s;
            }
          };
          if (eqs.length === 1 && vars.length === 1) {
            const res: any = nerdamer.solve(eqs[0], vars[0]);
            const els: string[] = res?.elements ? res.elements.map(String) : [String(res)];
            if (!els.length) lines.push({ text: "حلی یافت نشد (یا موتور از حل نمادین ناتوان است)." });
            for (const v of els) {
              let dec = "";
              try {
                dec = " ≈ " + String(math.format(math.evaluate(v), { precision: 10 }));
              } catch {}
              lines.push({ text: `ریشه:`, tex: `${vars[0]} = ${texOf(v)} \\;\\; (${dec.trim()} )` });
            }
          } else {
            const res = nerdamer.solveSystem(eqs, vars);
            lines.push({ text: "پاسخ دستگاه:", tex: String(res).replace(/=>/g, " = ") });
          }
          setOut({ kind: "exact", lines });
          break;
        }
        case "algebra": {
          const ent: any = nerdamer(algExpr);
          const res: string = String(
            algOp === "simplify" ? ent.simplify() : algOp === "expand" ? ent.expand() : ent.factor()
          );
          setOut({
            kind: "exact",
            lines: [
              { text: `عملیات: ${algOp === "simplify" ? "ساده‌سازی" : algOp === "expand" ? "بسط" : "تجزیه"}` },
              { text: "ورودی:", tex: (nerdamer(algExpr) as any).toTeX() },
              { text: "نتیجه:", tex: (nerdamer(res) as any).toTeX() },
            ],
          });
          break;
        }
        case "derivative": {
          const fStr = expr.replace(/=.*/, "");
          const d: any = (nerdamer as any).diff(fStr, variable);
          const lines: Out["lines"] = [
            { text: "مشتق نمادین:", tex: `\\frac{d}{d${variable}}\\left(${(nerdamer(fStr) as any).toTeX()}\\right) = ${d.toTeX()}` },
          ];
          if (point.trim()) {
            const v = d.sub(variable, point).evaluate();
            let num: string | null = null;
            try {
              num = math.format(math.evaluate(v.toString()), { precision: 10 });
            } catch {}
            lines.push({ text: `مقدار در ${variable} = ${point}:`, tex: `${v.toTeX()}${num ? ` = ${num}` : ""}` });
          }
          setOut({ kind: "exact", lines });
          break;
        }
        case "integral": {
          const integrand = expr.replace(/=.*/, "");
          const F: any = (nerdamer as any).integrate(integrand, variable);
          const fTex = F.toTeX();
          if (lower.trim() && upper.trim()) {
            try {
              const Fb = F.sub(variable, upper).evaluate();
              const Fa = F.sub(variable, lower).evaluate();
              const diff: any = nerdamer(`(${Fb.toString()}) - (${Fa.toString()})`);
              let num = "";
              try {
                num = String(math.format(math.evaluate(diff.toString()), { precision: 10 }));
              } catch {}
              setOut({
                kind: "exact",
                lines: [
                  { text: "پادمشتق (در حالت نامعین +C):", tex: `F(${variable}) = ${fTex}` },
                  { text: "قضیهٔ اساسی حسابان:", tex: `\\int_{${lower}}^{${upper}} f\\,d${variable} = F(${upper}) - F(${lower}) = ${diff.toTeX()} ${num ? `\\approx ${num}` : ""}` },
                ],
              });
            } catch {
              throw new Error("numerical-fallback");
            }
          } else {
            setOut({
              kind: "exact",
              lines: [
                { text: "انتگرال نامعین (نمادین):", tex: `\\int \\left(${(nerdamer(integrand) as any).toTeX()}\\right) d${variable} = ${fTex} + C` },
                { text: "برای انتگرال معین، کران‌های بالا و پایین را وارد کنید." },
              ],
            });
          }
          break;
        }
        case "limit": {
          const fn = math.compile(expr.replace(/=.*/, ""));
          const a = Number(point);
          const rows: string[] = [];
          const hs = [0.1, 0.01, 1e-4, 1e-6];
          for (const h of hs) {
            const lg = safeEval(fn, variable, a - h);
            const rg = safeEval(fn, variable, a + h);
            rows.push(`h=${h}: \\; f(a-h)\\approx${lg}, \\quad f(a+h)\\approx${rg}`);
          }
          setOut({
            kind: "numeric",
            lines: [
              { text: "تقریب عددی حد — این روش شهود می‌دهد اما اثبات نیست:" },
              ...rows.map((r) => ({ text: "", tex: r })),
            ],
          });
          break;
        }
        case "matrix": {
          const A = math.evaluate(matA);
          const toTex = (M: any) => {
            const arr = M.toArray ? M.toArray() : M;
            return `\\begin{pmatrix}${arr.map((r: any[]) => r.join(" & ")).join(" \\\\ ")}\\end{pmatrix}`;
          };
          const lines: Out["lines"] = [{ text: "ماتریس ورودی:", tex: `A = ${toTex(A)}` }];
          if (matOp === "det") lines.push({ text: "دترمینان:", tex: `\\det A = ${math.format(math.det(A), { precision: 10 })}` });
          else if (matOp === "inv") lines.push({ text: "معکوس:", tex: `A^{-1} = ${toTex(math.inv(A))}` });
          else lines.push({ text: "ترانهاده:", tex: `A^{\\mathsf{T}} = ${toTex(math.transpose(A))}` });
          setOut({ kind: "exact", lines });
          break;
        }
      }
    } catch (e) {
      if (e instanceof Error && e.message === "numerical-fallback") {
        // Honest numeric Simpson fallback for definite integrals
        try {
          const f = math.compile(expr.replace(/=.*/, ""));
          const a = Number(lower), b = Number(upper);
          const n = 2000;
          const h = (b - a) / n;
          let s = numEval(f, variable, a) + numEval(f, variable, b);
          for (let i = 1; i < n; i++) s += numEval(f, variable, a + i * h) * (i % 2 ? 4 : 2);
          const val = (s * h) / 3;
          setOut({
            kind: "numeric",
            lines: [
              { text: "موتور نمادین نتوانست انتگرال را ببندد؛ روش سیمپسون (n=2000):" },
              { text: "مقدار تقریبی:", tex: `\\int_{${lower}}^{${upper}} f\\,d${variable} \\approx ${fmtN(val)}` },
            ],
          });
        } catch {
          setErr("محاسبه ممکن نشد. ورودی را بررسی کنید.");
        }
      } else {
        setErr("موتور جبری قادر به پردازش این ورودی نبود: " + (e instanceof Error ? e.message.slice(0, 120) : ""));
      }
    }
  };

  return (
    <div className="fade-up">
      <h1 className="section-title mb-2">حل‌گر مسائل ریاضی</h1>
      <p className="mb-5 text-sm leading-7 text-muted">
        نمادین با موتور nerdamer و عددی با math.js. پاسخ‌ها با برچسب مشخص می‌شوند:{" "}
        <span className="chip !text-accent"><BadgeCheck className="size-3" /> نمادین دقیق</span>{" "}
        <span className="chip !text-warn"><GaugeCircle className="size-3" /> تقریب عددی</span>
      </p>

      <div className="mb-5 flex flex-wrap gap-2">
        {MODES.map((m) => (
          <button key={m.id} onClick={() => { setMode(m.id); setOut(null); setErr(null); }}
            className={`btn !text-xs ${mode === m.id ? "!border-accent !bg-accentsoft !text-accent" : ""}`}>
            {m.fa}
          </button>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-[360px_1fr]">
        <div className="card h-fit space-y-3 p-5">
          {(mode === "equation" || mode === "derivative" || mode === "integral" || mode === "limit") && (
            <>
              <label className="block text-xs font-bold text-muted">
                {mode === "equation" ? "معادله (برای دستگاه، هر خط یک معادله)" : "عبارت / تابع f(x)"}
              </label>
              <textarea className="input font-mono" dir="ltr" rows={mode === "equation" ? 3 : 2} value={expr} onChange={(e) => setExpr(e.target.value)} />
              <label className="block text-xs font-bold text-muted">متغیر (برای دستگاه: x,y)</label>
              <input className="input font-mono" dir="ltr" value={variable} onChange={(e) => setVariable(e.target.value)} />
            </>
          )}
          {mode === "derivative" && (
            <>
              <label className="block text-xs font-bold text-muted">محاسبه در نقطه (اختیاری)</label>
              <input className="input font-mono" dir="ltr" value={point} onChange={(e) => setPoint(e.target.value)} />
            </>
          )}
          {mode === "integral" && (
            <>
              <label className="block text-xs font-bold text-muted">کران پایین (اختیاری)</label>
              <input className="input font-mono" dir="ltr" value={lower} onChange={(e) => setLower(e.target.value)} placeholder="خالی = نامعین" />
              <label className="block text-xs font-bold text-muted">کران بالا</label>
              <input className="input font-mono" dir="ltr" value={upper} onChange={(e) => setUpper(e.target.value)} />
            </>
          )}
          {mode === "limit" && (
            <>
              <label className="block text-xs font-bold text-muted">در نقطه‌ی x →</label>
              <input className="input font-mono" dir="ltr" value={point} onChange={(e) => setPoint(e.target.value)} />
            </>
          )}
          {mode === "algebra" && (
            <>
              <label className="block text-xs font-bold text-muted">عبارت جبری</label>
              <input className="input font-mono" dir="ltr" value={algExpr} onChange={(e) => setAlgExpr(e.target.value)} />
              <div className="flex gap-2">
                {(["simplify", "expand", "factor"] as const).map((o) => (
                  <button key={o} onClick={() => setAlgOp(o)} className={`btn !text-xs ${algOp === o ? "!border-accent !text-accent" : ""}`}>
                    {o === "simplify" ? "ساده‌سازی" : o === "expand" ? "بسط" : "تجزیه"}
                  </button>
                ))}
              </div>
            </>
          )}
          {mode === "quadratic" && (
            <div className="grid grid-cols-3 gap-2" dir="ltr">
              {([["a", qa, setQa], ["b", qb, setQb], ["c", qc, setQc]] as const).map(([l, v, set]) => (
                <div key={l}>
                  <label className="mb-1 block text-center font-mono text-xs text-muted">{l}</label>
                  <input className="input text-center font-mono" value={v} onChange={(e) => set(e.target.value)} />
                </div>
              ))}
            </div>
          )}
          {mode === "matrix" && (
            <>
              <label className="block text-xs font-bold text-muted">ماتریس (قالب JSON: [[3,1],[2,4]])</label>
              <input className="input font-mono" dir="ltr" value={matA} onChange={(e) => setMatA(e.target.value)} />
              <div className="flex gap-2">
                {(["det", "inv", "transpose"] as const).map((o) => (
                  <button key={o} onClick={() => setMatOp(o)} className={`btn !text-xs ${matOp === o ? "!border-accent !text-accent" : ""}`}>
                    {o === "det" ? "دترمینان" : o === "inv" ? "معکوس" : "ترانهاده"}
                  </button>
                ))}
              </div>
            </>
          )}
          <button onClick={run} className="btn btn-primary w-full justify-center">
            <Sigma className="size-4" /> محاسبه کن
          </button>
        </div>

        <div className="card min-h-64 p-6">
          {!out && !err && (
            <p className="text-sm text-muted">
              نتیجه این‌جا نمایش داده می‌شود. گام‌هایی که واقعاً محاسبه می‌شوند نمایش داده می‌شوند — اگر موتور
              نمادین پاسخ ندهد، به‌صراحت اعلام و در صورت امکان جایگزین عددی ارائه می‌شود.
            </p>
          )}
          {err && <p className="rounded-xl border border-danger/40 bg-danger/10 p-4 text-sm leading-7 text-danger">{err}</p>}
          {out && (
            <div>
              <span className={`chip mb-4 ${out.kind === "exact" ? "!text-accent" : "!text-warn"}`}>
                {out.kind === "exact" ? <BadgeCheck className="size-3" /> : <GaugeCircle className="size-3" />}
                {out.kind === "exact" ? " پاسخ نمادین دقیق" : " تقریب عددی"}
              </span>
              <ol className="space-y-3">
                {out.lines.map((l, i) => (
                  <li key={i} className="flex items-baseline gap-3">
                    {l.text && <span className="chip !px-1.5 !text-[10px]">{i + 1}</span>}
                    <div className="flex-1">
                      {l.text && <p className="text-sm leading-7">{l.text}</p>}
                      {l.tex && <TeX block>{l.tex}</TeX>}
                    </div>
                  </li>
                ))}
              </ol>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function fmtN(x: number) {
  const r = Math.round(x * 1e8) / 1e8;
  return Number.isInteger(r) ? String(r) : r.toFixed(6).replace(/0+$/, "").replace(/\.$/, "");
}

function safeEval(fn: any, variable: string, x: number) {
  try {
    const v = fn.evaluate({ [variable]: x });
    return typeof v === "number" ? fmtN(v) : "—";
  } catch {
    return "—";
  }
}

function numEval(fn: any, variable: string, x: number): number {
  const v = fn.evaluate({ [variable]: x });
  if (typeof v !== "number") throw new Error("non-numeric");
  return v;
}
