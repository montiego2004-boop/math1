"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { create, all } from "mathjs";
import { Delete, History, Trash2 } from "lucide-react";
import { useCalcHistory, useProgress } from "@/lib/store";

const KEY_ROWS: string[][] = [
  ["AC", "DEL", "(", ")", "÷"],
  ["sin(", "cos(", "tan(", "^", "×"],
  ["7", "8", "9", "√(", "−"],
  ["4", "5", "6", "ln(", "+"],
  ["1", "2", "3", "log(", "!"],
  ["0", ".", "π", "e", "%"],
];

export default function CalculatorPage() {
  const math = useMemo(() => create(all), []);
  const [deg, setDeg] = useState(true);
  const [expr, setExpr] = useState("");
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const ansRef = useRef<number>(0);
  const { history, push, clear } = useCalcHistory();
  const { recordToolUse } = useProgress();
  useEffect(() => recordToolUse("calculator"), [recordToolUse]);

  // Apply angle mode by overriding trig functions in our isolated math instance
  useEffect(() => {
    const k = deg ? Math.PI / 180 : 1;
    math.import(
      {
        sin: (x: number) => Math.sin(x * k),
        cos: (x: number) => Math.cos(x * k),
        tan: (x: number) => Math.tan(x * k),
        arcsin: (x: number) => Math.asin(x) / k,
        arccos: (x: number) => Math.acos(x) / k,
        arctan: (x: number) => Math.atan(x) / k,
      },
      { override: true }
    );
  }, [deg, math]);

  const normalize = (s: string) =>
    s
      .replace(/×/g, "*")
      .replace(/÷/g, "/")
      .replace(/−/g, "-")
      .replace(/π/g, " pi ")
      .replace(/√\(/g, "sqrt(")
      .replace(/(^|[\s(+\-*/^])\%/g, "$1/100*")
      .replace(/(\d|\)|e)\%/g, "$1/100")
      .replace(/ln\(/g, "log(")
      .replace(/log\(/g, "log10PLACEHOLDER(") // keep ln → log base e handled below
      .replace(/log10PLACEHOLDER\(/g, "<<LN>>(")
      .replace(/log\(/g, "log10(")
      .replace(/<<LN>>\(/g, "log(");

  const evaluate = () => {
    if (!expr.trim()) return;
    try {
      const res = math.evaluate(normalize(expr), { ans: ansRef.current });
      const text =
        typeof res === "number"
          ? math.format(res, { precision: 12 })
          : math.format(res, { precision: 8 });
      setResult(text);
      setError(null);
      if (typeof res === "number") ansRef.current = res;
      push(expr, text);
    } catch (e) {
      setResult(null);
      setError("عبارات نامعتبر: " + (e instanceof Error ? e.message.replace(/\(.*/,"").slice(0, 80) : "خطا"));
    }
  };

  const press = (k: string) => {
    setError(null);
    if (k === "AC") {
      setExpr("");
      setResult(null);
    } else if (k === "DEL") {
      setExpr((e) => e.slice(0, -1));
    } else {
      setExpr((e) => e + k);
    }
  };

  useEffect(() => {
    const onKey = (ev: KeyboardEvent) => {
      const k = ev.key;
      if (/^[0-9.]$/.test(k)) press(k);
      else if (k === "+") press("+");
      else if (k === "-") press("−");
      else if (k === "*") press("×");
      else if (k === "/") { ev.preventDefault(); press("÷"); }
      else if (k === "(" || k === ")" || k === "^") press(k);
      else if (k === "Enter") evaluate();
      else if (k === "Backspace") press("DEL");
      else if (k === "Escape") press("AC");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expr, deg]);

  return (
    <div className="fade-up">
      <h1 className="section-title mb-2">ماشین‌حساب علمی</h1>
      <p className="mb-6 text-sm leading-7 text-muted">
        مبتنی بر موتور math.js — پشتیبانی از مثلثات، لگاریتم، توان، فاکتوریل، اعداد مختلط (i)،
        ماتریس‌ها و نمادگذاری علمی. حالت زاویه: درجه (DEG) یا رادیان (RAD).
      </p>

      <div className="grid gap-6 lg:grid-cols-[1fr_300px]">
        <div className="card p-5">
          {/* Display */}
          <div className="mb-3 rounded-xl border border-line bg-surface2 p-4 text-left" dir="ltr">
            <input
              className="w-full bg-transparent font-mono text-xl outline-none"
              value={expr}
              onChange={(e) => { setExpr(e.target.value); setError(null); }}
              placeholder="0"
              aria-label="عبارت ریاضی"
            />
            <div className="mt-1 min-h-7 text-left font-mono text-2xl font-bold text-accent">
              {error ? <span className="text-sm text-danger">{error}</span> : result ?? ""}
            </div>
          </div>

          <div className="mb-3 flex items-center justify-between">
            <button className={`btn !text-xs ${deg ? "" : "!border-accent !text-accent"}`} onClick={() => setDeg((d) => !d)}>
              {deg ? "DEG درجه" : "RAD رادیان"}
            </button>
            <div className="flex gap-2">
              <button className="btn !text-xs" onClick={() => press("ans")}>
                <span className="text-muted">ans =</span> {math.format(ansRef.current, { precision: 8 })}
              </button>
            </div>
          </div>

          {/* Keypad */}
          <div className="grid grid-cols-5 gap-2" dir="ltr">
            {KEY_ROWS.flat().map((k) => (
              <button
                key={k}
                onClick={() => press(k)}
                className={`rounded-xl border py-3 font-mono text-base transition-all hover:-translate-y-0.5 ${
                  k === "AC"
                    ? "border-danger/40 bg-danger/10 text-danger"
                    : k === "DEL"
                      ? "border-warn/40 bg-warn/10 text-warn"
                      : "border-line bg-surface2 hover:border-accent"
                }`}
              >
                {k === "DEL" ? "⌫" : k}
              </button>
            ))}
            <button onClick={() => press("ans")} className="rounded-xl border border-line bg-surface2 py-3 font-mono hover:border-accent">
              ans
            </button>
            <button onClick={() => press("i")} title="عدد موهومی" className="rounded-xl border border-line bg-surface2 py-3 font-mono hover:border-accent">
              i
            </button>
            <button onClick={() => press("mod(")} className="rounded-xl border border-line bg-surface2 py-3 font-mono text-sm hover:border-accent">
              mod
            </button>
            <button onClick={() => press(",")} className="rounded-xl border border-line bg-surface2 py-3 font-mono hover:border-accent">
              ,
            </button>
            <button
              onClick={evaluate}
              className="rounded-xl border border-accent bg-accent py-3 font-mono text-lg text-white transition-all hover:brightness-110"
            >
              =
            </button>
          </div>

          <p className="mt-3 text-[11px] leading-5 text-muted">
            کلیدهای صفحه‌کلید نیز کار می‌کنند. مثال‌های قابل امتحان: <code dir="ltr">sqrt(2)</code> ،{" "}
            <code dir="ltr">sin(30)</code> ، <code dir="ltr">det([3,1;2,4])</code> ،{" "}
            <code dir="ltr">(2+3i)*(1-i)</code> ، <code dir="ltr">5!</code>
          </p>
        </div>

        {/* History */}
        <aside className="card h-fit p-5">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-sm font-bold">
              <History className="size-4 text-accent" /> تاریخچه
            </h2>
            <button onClick={clear} className="btn !px-2 !py-1 !text-[11px]">
              <Trash2 className="size-3.5" /> پاک‌سازی
            </button>
          </div>
          {history.length === 0 && <p className="text-xs text-muted">هنوز محاسبه‌ای انجام نشده است.</p>}
          <ul className="max-h-[420px] space-y-2 overflow-y-auto text-sm">
            {history.map((h, i) => (
              <li key={i} className="rounded-lg bg-surface2 p-2.5" dir="ltr">
                <button
                  className="block w-full text-left font-mono text-xs text-muted hover:text-accent"
                  onClick={() => setExpr(h.expr)}
                >
                  {h.expr}
                </button>
                <div className="mt-0.5 text-left font-mono text-sm font-bold text-accent">= {h.result}</div>
              </li>
            ))}
          </ul>
        </aside>
      </div>
    </div>
  );
}
