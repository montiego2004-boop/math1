import type { Metadata } from "next";
import { BookOpenCheck, Cpu, HeartHandshake, Info, ShieldCheck } from "lucide-react";

export const metadata: Metadata = { title: "درباره مث‌ورس" };

const DEPS = [
  { name: "Next.js", version: "16.4.2", license: "MIT", purpose: "چارچوب وب‌اپلیکیشن (App Router)" },
  { name: "React", version: "19.2.6", license: "MIT", purpose: "رابط کاربری مؤلفه‌محور" },
  { name: "mathjs", version: "15.2.0", license: "Apache-2.0", purpose: "محاسبات عددی، تجزیه عبارت، ماتریس و اعداد مختلط" },
  { name: "nerdamer", version: "2.0.1", license: "MIT", purpose: "جبر نمادین: ساده‌سازی، مشتق، انتگرال و حل معادله" },
  { name: "KaTeX", version: "0.19.1", license: "MIT", purpose: "رندر سریع و دقیق فرمول‌های ریاضی" },
  { name: "Three.js", version: "0.187.0", license: "MIT", purpose: "رندر سه‌بعدی سطوح (فقط در صفحه مربوط بارگذاری می‌شود)" },
  { name: "lucide-react", version: "1.73.0", license: "ISC", purpose: "آیکون‌های رابط کاربری" },
  { name: "Tailwind CSS", version: "4.1.17", license: "MIT", purpose: "سیستم طراحی و چیدمان" },
  { name: "Drizzle ORM", version: "0.45.2", license: "Apache-2.0", purpose: "زیرساخت دیتابیس قالب (در نسخه فعلی استفاده نمی‌شود؛ داده‌ها محلی‌اند)" },
];

export default function AboutPage() {
  return (
    <div className="fade-up">
      <h1 className="section-title mb-2 flex items-center gap-2">
        <Info className="size-7 text-accent" /> درباره مث‌ورس
      </h1>
      <p className="mb-6 max-w-3xl leading-8 text-muted">
        مث‌ورس (MATHVERSE) یک پروژه‌ی آموزشی آزاد و کاملاً رایگان است با یک هدف: دسترسی همه‌گیر به آموزش
        باکیفیت ریاضیات و فیزیک — بدون ثبت‌نام، بدون اشتراک، بدون تبلیغ. درس بخوانید، ببینید، آزمایش کنید و
        تمرین کنید.
      </p>

      <div className="grid gap-5 lg:grid-cols-2">
        <section className="card p-6">
          <h2 className="mb-3 flex items-center gap-2 font-bold"><HeartHandshake className="size-5 text-accent" /> اصول پروژه</h2>
          <ul className="space-y-2 text-sm leading-7 text-muted">
            <li>۱. آموزش واقعی، نه صفحه‌نمایش تزئینی: هر ابزار واقعاً محاسبه می‌کند.</li>
            <li>۲. صداقت علمی: پاسخ‌های «نمادین دقیق» از «تقریب عددی» با برچسب جدا می‌شوند؛ هیچ گام حل جعلی ساخته نمی‌شود.</li>
            <li>۳. حریم خصوصی: پیشرفت، نشانه‌ها و یادداشت‌ها فقط در مرورگر شما ذخیره می‌شوند.</li>
            <li>۴. احترام به حق نشر: کتابخانه فقط منابع آزاد قانونی را به منبع اصلی پیوند می‌دهد.</li>
            <li>۵. شفافیت محدودیت‌ها: درس‌های ناتمام با برچسب «به‌زودی» مشخص‌اند.</li>
          </ul>
        </section>

        <section className="card p-6">
          <h2 className="mb-3 flex items-center gap-2 font-bold"><ShieldCheck className="size-5 text-accent" /> دقت علمی و حدود ابزارها</h2>
          <ul className="space-y-2 text-sm leading-7 text-muted">
            <li>• حل‌گر نمادین به توانایی nerdamer محدود است؛ انتگرال‌های بسته نشدنی با سیمپسون عددی و با برچسب «تقریب» ارائه می‌شوند.</li>
            <li>• حد در حل‌گر فعلاً با نزدیک‌شدن عددی تخمین زده می‌شود و به‌عنوان روش اکتشافی مشخص است.</li>
            <li>• شبیه‌سازی‌های آزمایشگاه با انتگرال‌گیر RK4 انجام می‌شوند و فرض‌ها/محدودیت‌ها زیر هر آزمایش درج شده است.</li>
            <li>• داده‌های حل‌گر فیزیک در یکای SI پردازش و واحدهای رایج تبدیل می‌شوند.</li>
          </ul>
        </section>
      </div>

      <section className="card mt-5 p-6">
        <h2 className="mb-3 flex items-center gap-2 font-bold"><Cpu className="size-5 text-accent" /> دفترچه وابستگی‌ها (Dependency Register)</h2>
        <p className="mb-3 text-xs text-muted">همه‌ی کتابخانه‌ها آزاد/متن‌باز و با مجوز سازگار با توزیع رایگان آموزشی‌اند.</p>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead>
              <tr className="border-b border-line text-right text-xs text-muted">
                <th className="p-2 font-medium">کتابخانه</th>
                <th className="p-2 font-medium">نسخه</th>
                <th className="p-2 font-medium">مجوز</th>
                <th className="p-2 font-medium">کاربرد در مث‌ورس</th>
              </tr>
            </thead>
            <tbody>
              {DEPS.map((d) => (
                <tr key={d.name} className="border-b border-line/50 last:border-0">
                  <td className="p-2 font-mono text-xs" dir="ltr">{d.name}</td>
                  <td className="p-2 font-mono text-xs" dir="ltr">{d.version}</td>
                  <td className="p-2"><span className="chip !text-[10px]">{d.license}</span></td>
                  <td className="p-2 text-xs text-muted">{d.purpose}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="card mt-5 p-6">
        <h2 className="mb-3 flex items-center gap-2 font-bold"><BookOpenCheck className="size-5 text-accent" /> نقشهٔ راه توسعه</h2>
        <p className="text-sm leading-7 text-muted">
          ساختار آکادمی برای ده‌ها درس دیگر در سطوح A تا D و شش شاخهٔ فیزیک آماده است؛ درس‌ها به‌تدریج کامل و
          صفحه‌بندی محتوا گسترش می‌یابد. گام‌های بعدی برنامه‌ریزی‌شده: موتور هندسهٔ سازنده (JSXGraph)، درس‌های
          حسابان چندمتغیره و معادلات دیفرانسیل، ابزارهای نمادین پیشرفته‌تر، و گسترش کتابخانه با منابع فارسی
          دارای مجوز باز.
        </p>
        <p className="mt-3 text-xs text-muted">
          امکان آفلاین: صفحه‌ها و ابزارهایی که یک‌بار باز کرده‌اید توسط Service Worker کش می‌شوند و آفلاین در
          دسترس‌اند؛ پیوندهای کتابخانه به سایت‌های بیرونی طبیعتاً نیازمند اینترنت‌اند.
        </p>
      </section>
    </div>
  );
}
