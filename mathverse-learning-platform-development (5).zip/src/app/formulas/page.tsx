"use client";

import { useMemo, useState } from "react";
import { Search, FunctionSquare } from "lucide-react";
import { FORMULA_CATS, FORMULAS } from "@/data/formulas";
import { TeX } from "@/components/katex";

export default function FormulasPage() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");

  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return FORMULAS.filter((f) => {
      if (cat !== "all" && f.cat !== cat) return false;
      if (!needle) return true;
      return (
        f.fa.includes(needle) ||
        f.en.toLowerCase().includes(needle) ||
        f.tags.some((t) => t.toLowerCase().includes(needle)) ||
        f.tex.toLowerCase().includes(needle)
      );
    });
  }, [q, cat]);

  return (
    <div className="fade-up">
      <h1 className="section-title mb-2 flex items-center gap-2">
        <FunctionSquare className="size-7 text-accent" /> دانشنامه فرمول‌ها
      </h1>
      <p className="mb-5 text-sm leading-7 text-muted">
        {FORMULAS.length} فرمول ریاضی و فیزیک با تعریف، متغیرها، واحدها و مثال — قابل جست‌وجو به فارسی و
        انگلیسی.
      </p>

      <div className="mb-4 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted" />
          <input className="input !pr-9" placeholder="جست‌وجو: انتگرال، نیوتن، derivative…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
      </div>
      <div className="mb-6 flex flex-wrap gap-2">
        <button className={`btn !text-xs ${cat === "all" ? "!border-accent !text-accent" : ""}`} onClick={() => setCat("all")}>همه</button>
        {FORMULA_CATS.map((c) => (
          <button key={c.id} className={`btn !text-xs ${cat === c.id ? "!border-accent !text-accent" : ""}`} onClick={() => setCat(c.id)}>{c.fa}</button>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {list.map((f) => (
          <article key={f.id} className="card card-hover p-5">
            <div className="mb-2 flex flex-wrap items-center gap-2">
              <h3 className="font-bold">{f.fa}</h3>
              <span className="chip !text-[10px]" dir="ltr">{f.en}</span>
              <span className="chip !text-[10px]">{FORMULA_CATS.find((c) => c.id === f.cat)?.fa}</span>
            </div>
            <div className="mb-3 overflow-x-auto rounded-xl bg-surface2 p-3">
              <TeX block>{f.tex}</TeX>
            </div>
            {f.vars.length > 0 && (
              <table className="mb-2 w-full text-xs">
                <tbody>
                  {f.vars.map((v, i) => (
                    <tr key={i} className="border-b border-line/60 last:border-0">
                      <td className="py-1 font-mono" dir="ltr"><TeX>{v.sym}</TeX></td>
                      <td className="py-1 text-muted">{v.fa}{v.unit ? ` (${v.unit})` : ""}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            {f.example && <p className="text-xs leading-6"><strong className="text-accent">مثال:</strong> {f.example}</p>}
            {f.note && <p className="mt-1 text-xs leading-6 text-muted"><strong>نکته:</strong> {f.note}</p>}
          </article>
        ))}
      </div>
      {list.length === 0 && (
        <div className="card grid h-32 place-items-center text-sm text-muted">موردی مطابق جست‌وجو یافت نشد.</div>
      )}
    </div>
  );
}
