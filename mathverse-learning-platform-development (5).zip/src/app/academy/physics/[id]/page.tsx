import { notFound } from "next/navigation";
import LessonView from "@/components/lesson-view";
import { getLesson, PHYSICS_LESSONS } from "@/data/lessons";

export function generateStaticParams() {
  return PHYSICS_LESSONS.map((l) => ({ id: l.id }));
}

export default async function PhysicsLessonPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const lesson = getLesson("physics", id);
  if (!lesson) notFound();
  return <LessonView lesson={lesson} />;
}
