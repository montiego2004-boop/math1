import type { Metadata } from "next";
import AcademyBrowser from "@/components/academy-browser";
import { PHYSICS_AREAS } from "@/data/curriculum";

export const metadata: Metadata = { title: "آکادمی فیزیک" };

export default function PhysicsAcademyPage() {
  return (
    <div>
      <h1 className="section-title mb-2">آکادمی فیزیک</h1>
      <p className="mb-6 leading-8 text-muted">
        فیزیک از مکانیک کلاسیک تا کوانتوم، همیشه با پیوند مستقیم شهود فیزیکی و مدل ریاضی. هر درس با
        یک آزمایش تعاملی یا حل‌گر فیزیکی همراه است.
      </p>
      <AcademyBrowser levels={PHYSICS_AREAS} academy="physics" academyFa="آکادمی فیزیک" />
    </div>
  );
}
