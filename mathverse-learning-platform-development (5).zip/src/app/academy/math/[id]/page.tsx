import { notFound } from "next/navigation";
import LessonView from "@/components/lesson-view";
import { getLesson, ALL_MATH_LESSONS } from "@/data/lessons";

export function generateStaticParams() {
  return ALL_MATH_LESSONS.map((l) => ({ id: l.id }));
}

export default async function MathLessonPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const lesson = getLesson("math", id);
  if (!lesson) notFound();
  return <LessonView lesson={lesson} />;
}
