import type { Metadata } from "next";
import AcademyBrowser from "@/components/academy-browser";
import { MATH_LEVELS } from "@/data/curriculum";

export const metadata: Metadata = { title: "آکادمی ریاضیات" };

export default function MathAcademyPage() {
  return (
    <div>
      <h1 className="section-title mb-2">آکادمی ریاضیات</h1>
      <p className="mb-6 leading-8 text-muted">
        مسیر کامل یادگیری ریاضیات در چهار سطح — از مبانی حساب تا موضوعات پژوهشی. درس‌ها به‌صورت
        پیشرونده طراحی شده‌اند: شهود ← آزمایش ← تعریف صوری ← اثبات ← حل مسئله.
      </p>
      <AcademyBrowser levels={MATH_LEVELS} academy="math" academyFa="آکادمی ریاضیات" />
    </div>
  );
}
