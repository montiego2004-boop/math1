"use client";

import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, BadgeCheck, Zap } from "lucide-react";
import { PHYSICS_TOPICS, solveTopic, type SolveResult } from "@/lib/eqsolve";
import { TeX } from "@/components/katex";
import { useProgress } from "@/lib/store";

const fmt = (x: number) =>
  Math.abs(x) >= 1e5 || (Math.abs(x) < 1e-3 && x !== 0)
    ? x.toExponential(4)
    : String(Math.round(x * 10000) / 10000);

export default function PhysicsSolverPage() {
  const [topicId, setTopicId] = useState(PHYSICS_TOPICS[0].id);
  const topic = useMemo(() => PHYSICS_TOPICS.find((t) => t.id === topicId)!, [topicId]);
  const [values, setValues] = useState<Record<string, string>>({});
  const [unitSel, setUnitSel] = useState<Record<string, string>>({});
  const [target, setTarget] = useState("");
  const [res, setRes] = useState<SolveResult | null>(null);
  const { recordToolUse } = useProgress();
  useEffect(() => recordToolUse("physics-solver"), [recordToolUse]);

  useEffect(() => {
    setValues({});
    setUnitSel({});
    setTarget(topic.vars[0]?.key ?? "");
    setRes(null);
  }, [topicId, topic]);

  const run = () => {
    const inputs: Record<string, number> = {};
    for (const v of topic.vars) {
      const raw = values[v.key];
      if (raw === undefined || raw.trim() === "" || v.key === target) continue;
      const num = Number(raw);
      if (!isFinite(num)) continue;
      const unitName = unitSel[v.key] ?? v.siUnit;
      const factor = v.units[unitName] ?? 1;
      inputs[v.key] = num * factor;
    }
    setRes(solveTopic(topic, inputs, target));
  };

  const targetDef = topic.vars.find((v) => v.key === target);
  const targetUnit = targetDef ? unitSel[target] ?? targetDef.siUnit : "";
  const targetFactor = targetDef ? targetDef.units[targetUnit] ?? 1 : 1;

  return (
    <div className="fade-up">
      <h1 className="section-title mb-2">حل‌گر مسائل فیزیک</h1>
      <p className="mb-5 text-sm leading-7 text-muted">
        مقادیر شناخته‌شده را با واحد وارد کنید و مجهول را انتخاب کنید. حل‌گر معادلات مرتبط را زنجیره‌ای
        اعمال می‌کند، مقادیر جایگذاری‌شده را نشان می‌دهد و اگر اطلاعات کافی نباشد، به‌جای حدس زدن هشدار می‌دهد.
      </p>

      <div className="mb-5 flex flex-wrap gap-2">
        {PHYSICS_TOPICS.map((t) => (
          <button key={t.id} onClick={() => setTopicId(t.id)}
            className={`btn !text-xs ${topicId === t.id ? "!border-accent !bg-accentsoft !text-accent" : ""}`}>
            {t.fa}
          </button>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-[400px_1fr]">
        <div className="card h-fit space-y-4 p-5">
          <p className="text-xs leading-6 text-muted">{topic.desc}</p>
          {topic.constants.length > 0 && (
            <div className="rounded-xl bg-accentsoft/40 p-3 text-xs leading-6">
              <strong>ثابت‌ها:</strong>{" "}
              {topic.constants.map((c) => `${c.fa} = ${c.value.toExponential(4)} ${c.unit}`).join("، ")}
            </div>
          )}
          {topic.vars.map((v) => (
            <div key={v.key} className="flex items-center gap-2">
              <div className="w-24 shrink-0">
                <div className="font-mono text-sm" dir="ltr">{v.key}</div>
                <div className="text-[10px] text-muted">{v.fa}</div>
              </div>
              <input
                className="input flex-1 !py-1.5 font-mono"
                dir="ltr"
                type="number"
                step="any"
                placeholder={v.key === target ? "مجهول" : "—"}
                disabled={v.key === target}
                value={v.key === target ? "" : values[v.key] ?? ""}
                onChange={(e) => setValues((s) => ({ ...s, [v.key]: e.target.value }))}
              />
              <select
                className="input !w-24 !py-1.5 font-mono text-xs"
                dir="ltr"
                value={unitSel[v.key] ?? v.siUnit}
                onChange={(e) => setUnitSel((s) => ({ ...s, [v.key]: e.target.value }))}
              >
                {Object.keys(v.units).map((u) => (
                  <option key={u} value={u}>{u}</option>
                ))}
              </select>
            </div>
          ))}
          <div className="flex items-center gap-2 border-t border-line pt-3">
            <label className="text-xs font-bold text-muted">مجهول:</label>
            <select className="input flex-1 !py-1.5" value={target} onChange={(e) => setTarget(e.target.value)}>
              {topic.vars.map((v) => (
                <option key={v.key} value={v.key}>{v.fa} ({v.key})</option>
              ))}
            </select>
          </div>
          <button onClick={run} className="btn btn-primary w-full justify-center">
            <Zap className="size-4" /> حل مسئله
          </button>
        </div>

        <div className="card min-h-64 p-6">
          {!res && (
            <div className="space-y-3">
              <p className="text-sm text-muted">معادلات این موضوع:</p>
              {topic.equations.map((eq) => (
                <TeX key={eq.id} block>{eq.tex}</TeX>
              ))}
            </div>
          )}
          {res && !res.ok && (
            <div className="rounded-xl border border-warn/40 bg-warn/10 p-4">
              <p className="mb-2 flex items-center gap-2 font-bold text-warn">
                <AlertTriangle className="size-4" /> اطلاعات کافی نیست
              </p>
              <p className="text-sm leading-7">
                با داده‌های فعلی نمی‌توان «{targetDef?.fa}» را تعیین کرد.{" "}
                {res.missing && res.missing.length > 0 && (
                  <>
                    حداقل یکی از این متغیرها لازم است:{" "}
                    {res.missing
                      .map((k) => topic.vars.find((v) => v.key === k)?.fa ?? k)
                      .join("، ")}
                  </>
                )}
              </p>
            </div>
          )}
          {res && res.ok && (
            <div>
              <div className="mb-4 rounded-xl border border-accent/40 bg-accentsoft/30 p-4">
                <p className="mb-1 flex items-center gap-2 text-sm font-bold text-accent">
                  <BadgeCheck className="size-4" /> پاسخ
                </p>
                <p className="text-2xl font-extrabold" dir="ltr">
                  {(targetDef?.fa ?? target)} = {fmt((res.valueSI ?? 0) / targetFactor)}{" "}
                  <span className="text-base font-normal text-muted">{targetUnit}</span>
                </p>
                {targetFactor !== 1 && (
                  <p className="mt-1 text-xs text-muted" dir="ltr">
                    SI: {fmt(res.valueSI ?? 0)} {targetDef?.siUnit}
                  </p>
                )}
              </div>
              {res.steps.length > 0 && (
                <>
                  <h3 className="mb-2 text-sm font-bold">گام‌های حل (جایگذاری در یکای SI):</h3>
                  <ol className="space-y-3">
                    {res.steps.map((s, i) => (
                      <li key={i} className="flex items-baseline gap-3">
                        <span className="chip !px-1.5 !text-[10px]">{i + 1}</span>
                        <div className="flex-1">
                          <TeX block>{s.tex}</TeX>
                          {s.substitution && (
                            <p className="text-xs text-muted" dir="ltr">
                              ⟵ {s.substitution}
                            </p>
                          )}
                          <p className="text-xs font-bold text-accent" dir="ltr">
                            ⇒ {s.varKey} = {fmt(s.valueSI)}
                          </p>
                        </div>
                      </li>
                    ))}
                  </ol>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
