export const dynamic = "force-static";

/**
 * Lightweight health endpoint — intentionally independent of any database.
 * MATHVERSE stores all learner data locally in the browser; this endpoint
 * exists purely for deployment healthchecks (Vercel/Pages/containers).
 * Being static also allows `next build` with `output: "export"`.
 */
export async function GET() {
  return Response.json({ ok: true, service: "mathverse", db: "not-required" });
}
