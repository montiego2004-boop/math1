"use client";

import Link from "next/link";
import { ArrowLeft, BookMarked, GraduationCap, History } from "lucide-react";
import { SECTIONS } from "@/lib/sections";
import { ALL_LESSONS } from "@/data/lessons";
import { FORMULAS } from "@/data/formulas";
import { EXERCISES, GENERATORS } from "@/data/exercises";
import { LIBRARY } from "@/data/library";
import { useProgress } from "@/lib/store";

export default function HomePage() {
  const { progress } = useProgress();
  const recent = progress.visitedLessons
    .slice(-4)
    .reverse()
    .map((key) => {
      const [academy, id] = key.split("/");
      const lesson = ALL_LESSONS.find((l) => l.academy === academy && l.id === id);
      return lesson ? { key, lesson } : null;
    })
    .filter(Boolean) as { key: string; lesson: (typeof ALL_LESSONS)[number] }[];

  const stats = [
    { n: ALL_LESSONS.length, label: "درس کامل آماده" },
    { n: FORMULAS.length, label: "فرمول دانشنامه" },
    { n: EXERCISES.length + GENERATORS.length, label: "بانک تمرین" },
    { n: 7, label: "آزمایش تعاملی" },
    { n: LIBRARY.length, label: "منبع آزاد کتابخانه" },
  ];

  return (
    <div className="fade-up">
      {/* Hero */}
      <section className="card relative mb-8 overflow-hidden p-8 lg:p-12">
        <div className="pointer-events-none absolute -left-24 -top-24 size-72 rounded-full bg-accent/15 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 right-1/4 size-72 rounded-full bg-accent2/15 blur-3xl" />
        <div className="relative">
          <span className="chip mb-4 !border-accent/40 !text-accent">
            <GraduationCap className="size-3.5" /> آزاد • رایگان • بدون ثبت‌نام
          </span>
          <h1 className="mb-4 text-3xl font-black leading-snug lg:text-5xl lg:leading-[1.35]">
            جهانِ تعاملی{" "}
            <span className="bg-gradient-to-l from-accent to-accent2 bg-clip-text text-transparent">
              ریاضیات و فیزیک
            </span>
          </h1>
          <p className="mb-6 max-w-2xl leading-8 text-muted">
            مث‌ورس یک پلتفرم آموزشی باز است: درس بخوانید، فرمول را ببینید، پارامترها را تغییر دهید،
            مسئله حل کنید و تمرین کنید — همه در یک محیط یکپارچه‌ی فارسی. همه‌ی داده‌های یادگیری شما
            فقط روی همین دستگاه می‌ماند.
          </p>
          <div className="flex flex-wrap gap-3">
            <Link href="/academy/math" className="btn btn-primary">
              شروع یادگیری <ArrowLeft className="size-4" />
            </Link>
            <Link href="/lab" className="btn">ورود به آزمایشگاه</Link>
            <Link href="/graph-2d" className="btn">نمودارساز دوبعدی</Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="mb-8 grid grid-cols-2 gap-3 sm:grid-cols-5">
        {stats.map((s) => (
          <div key={s.label} className="card p-4 text-center">
            <div className="text-2xl font-extrabold text-accent">{s.n}</div>
            <div className="mt-1 text-xs text-muted">{s.label}</div>
          </div>
        ))}
      </section>

      {/* Continue learning */}
      {recent.length > 0 && (
        <section className="card mb-8 p-5">
          <h2 className="mb-3 flex items-center gap-2 text-sm font-bold">
            <History className="size-4 text-accent" /> ادامه‌ی یادگیری
          </h2>
          <div className="flex flex-wrap gap-2">
            {recent.map(({ key, lesson }) => (
              <Link key={key} href={`/academy/${lesson.academy}/${lesson.id}`} className="btn !text-xs">
                <BookMarked className="size-3.5" /> {lesson.title}
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Sections grid */}
      <h2 className="section-title mb-4">بخش‌های مث‌ورس</h2>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {SECTIONS.filter((s) => s.href !== "/").map((s, i) => (
          <Link
            key={s.href}
            href={s.href}
            className="card card-hover group p-5"
            style={{ animationDelay: `${i * 40}ms` }}
          >
            <div className="mb-3 flex items-center gap-3">
              <span className="grid size-11 place-items-center rounded-xl bg-accentsoft text-accent transition-transform duration-300 group-hover:scale-110">
                <s.icon className="size-5" />
              </span>
              <div>
                <h3 className="font-bold">{s.fa}</h3>
                <p className="text-[10px] tracking-wider text-muted" dir="ltr">{s.en}</p>
              </div>
            </div>
            <p className="text-sm leading-7 text-muted">{s.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
