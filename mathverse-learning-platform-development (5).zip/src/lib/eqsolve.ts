/* ------------------------------------------------------------------ */
/* Physics equation-chain solver: constraint propagation over a set    */
/* of symbolic equations with pre-derived solve forms for each var.    */
/* Never fabricates an answer:_reports unknowns when info is missing.  */
/* ------------------------------------------------------------------ */

export interface VarDef {
  key: string;
  fa: string;
  siUnit: string;
  units: Record<string, number>; // unit name -> factor to SI
}

export interface Step {
  varKey: string;
  tex: string;
  substitution: string;
  valueSI: number;
}

export interface EquationDef {
  id: string;
  tex: string;
  vars: string[];
  solve: Record<string, (v: Record<string, number>) => number>;
}

export interface TopicDef {
  id: string;
  fa: string;
  desc: string;
  constants: { key: string; fa: string; value: number; unit: string }[];
  vars: VarDef[];
  equations: EquationDef[];
}

export interface SolveResult {
  ok: boolean;
  target?: string;
  valueSI?: number;
  steps: Step[];
  missing?: string[];
}

const fmt = (x: number) =>
  Math.abs(x) >= 1e6 || (Math.abs(x) < 1e-3 && x !== 0)
    ? x.toExponential(4)
    : String(Math.round(x * 10000) / 10000);

export function solveTopic(
  topic: TopicDef,
  inputs: Record<string, number>, // SI values of known variables
  target: string
): SolveResult {
  const known: Record<string, number> = {};
  for (const c of topic.constants) known[c.key] = c.value;
  for (const [k, v] of Object.entries(inputs)) known[k] = v;

  const steps: Step[] = [];
  if (target in known) {
    return { ok: true, target, valueSI: known[target], steps };
  }

  let changed = true;
  let guard = 0;
  while (changed && guard++ < 20) {
    changed = false;
    for (const eq of topic.equations) {
      const unknown = eq.vars.filter((k) => !(k in known));
      if (unknown.length === 1 && eq.solve[unknown[0]]) {
        const k = unknown[0];
        try {
          const val = eq.solve[k](known);
          if (typeof val !== "number" || !isFinite(val) || isNaN(val)) continue;
          const subs = eq.vars
            .filter((x) => x !== k)
            .map((x) => `${x} = ${fmt(known[x])}`)
            .join(", ");
          known[k] = val;
          steps.push({ varKey: k, tex: eq.tex, substitution: subs, valueSI: val });
          changed = true;
        } catch {
          /* skip — cannot solve with current values */
        }
      }
    }
  }

  if (target in known) {
    return { ok: true, target, valueSI: known[target], steps: steps.filter((s) => s.varKey !== undefined) };
  }
  // suggest what additional info could unlock the target
  const missing = new Set<string>();
  for (const eq of topic.equations) {
    if (eq.vars.includes(target)) {
      for (const k of eq.vars) if (k !== target && !(k in known)) missing.add(k);
    }
  }
  return { ok: false, target, steps, missing: [...missing] };
}

/* --------------------------- Unit helpers --------------------------- */

export const U = {
  length: { m: 1, km: 1000, cm: 0.01 },
  time: { s: 1, min: 60, h: 3600 },
  speed: { "m/s": 1, "km/h": 1 / 3.6 },
  accel: { "m/s²": 1 },
  mass: { kg: 1, g: 0.001, t: 1000 },
  force: { N: 1, kN: 1000 },
  energy: { J: 1, kJ: 1000, kcal: 4184 },
  power: { W: 1, kW: 1000 },
  angle: { rad: 1 },
  freq: { Hz: 1, kHz: 1000 },
  volt: { V: 1, kV: 1000 },
  amp: { A: 1, mA: 0.001 },
  ohm: { "Ω": 1, "kΩ": 1000 },
  pressure: { Pa: 1, kPa: 1000, atm: 101325 },
  volume: { "m³": 1, L: 0.001 },
  temp: { K: 1 },
  mol: { mol: 1 },
  momentum: { "kg·m/s": 1 },
};

/* ----------------------------- Topics ------------------------------ */

export const PHYSICS_TOPICS: TopicDef[] = [
  {
    id: "kinematics",
    fa: "حرکت با شتاب ثابت",
    desc: "معادلات سینماتیک یک‌بعدی: v = v₀+at و روابط مکان–زمان",
    constants: [],
    vars: [
      { key: "v0", fa: "سرعت اولیه", siUnit: "m/s", units: U.speed },
      { key: "v", fa: "سرعت نهایی", siUnit: "m/s", units: U.speed },
      { key: "a", fa: "شتاب", siUnit: "m/s²", units: U.accel },
      { key: "t", fa: "زمان", siUnit: "s", units: U.time },
      { key: "dx", fa: "جابه‌جایی", siUnit: "m", units: U.length },
    ],
    equations: [
      { id: "v", tex: "v = v_0 + at", vars: ["v0", "v", "a", "t"], solve: {
        v: (k) => k.v0 + k.a * k.t,
        v0: (k) => k.v - k.a * k.t,
        a: (k) => (k.v - k.v0) / k.t,
        t: (k) => (k.v - k.v0) / k.a,
      }},
      { id: "x", tex: "\\Delta x = v_0 t + \\tfrac{1}{2}at^2", vars: ["v0", "a", "t", "dx"], solve: {
        dx: (k) => k.v0 * k.t + 0.5 * k.a * k.t * k.t,
        v0: (k) => (k.dx - 0.5 * k.a * k.t * k.t) / k.t,
        a: (k) => (2 * (k.dx - k.v0 * k.t)) / (k.t * k.t),
      }},
      { id: "v2", tex: "v^2 = v_0^2 + 2a\\,\\Delta x", vars: ["v0", "v", "a", "dx"], solve: {
        v: (k) => Math.sqrt(Math.max(0, k.v0 * k.v0 + 2 * k.a * k.dx)),
        v0: (k) => Math.sqrt(Math.max(0, k.v * k.v - 2 * k.a * k.dx)),
        a: (k) => (k.v * k.v - k.v0 * k.v0) / (2 * k.dx),
        dx: (k) => (k.v * k.v - k.v0 * k.v0) / (2 * k.a),
      }},
    ],
  },
  {
    id: "freefall",
    fa: "سقوط آزاد",
    desc: "سینماتیک با a = −g (بدون مقاومت هوا)",
    constants: [{ key: "a", fa: "شتاب گرانش (به‌سمت پایین، علامت مطلع)", value: -9.81, unit: "m/s²" }],
    vars: [
      { key: "v0", fa: "سرعت اولیه", siUnit: "m/s", units: U.speed },
      { key: "v", fa: "سرعت", siUnit: "m/s", units: U.speed },
      { key: "t", fa: "زمان", siUnit: "s", units: U.time },
      { key: "dx", fa: "تغییر ارتفاع", siUnit: "m", units: U.length },
    ],
    equations: [
      { id: "v", tex: "v = v_0 - gt", vars: ["v0", "v", "a", "t"], solve: {
        v: (k) => k.v0 + k.a * k.t,
        v0: (k) => k.v - k.a * k.t,
        t: (k) => (k.v - k.v0) / k.a,
      }},
      { id: "x", tex: "\\Delta x = v_0 t + \\tfrac{1}{2}at^2", vars: ["v0", "a", "t", "dx"], solve: {
        dx: (k) => k.v0 * k.t + 0.5 * k.a * k.t * k.t,
        v0: (k) => (k.dx - 0.5 * k.a * k.t * k.t) / k.t,
      }},
      { id: "v2", tex: "v^2 = v_0^2 + 2a\\,\\Delta x", vars: ["v0", "v", "a", "dx"], solve: {
        v: (k) => Math.sqrt(Math.max(0, k.v0 * k.v0 + 2 * k.a * k.dx)),
        dx: (k) => (k.v * k.v - k.v0 * k.v0) / (2 * k.a),
      }},
    ],
  },
  {
    id: "newton",
    fa: "قانون دوم نیوتن",
    desc: "F = ma و رابطه‌ی وزن W = mg",
    constants: [{ key: "g", fa: "شتاب گرانش زمین", value: 9.81, unit: "m/s²" }],
    vars: [
      { key: "F", fa: "نیروی خالص", siUnit: "N", units: U.force },
      { key: "m", fa: "جرم", siUnit: "kg", units: U.mass },
      { key: "a", fa: "شتاب", siUnit: "m/s²", units: U.accel },
      { key: "W", fa: "وزن", siUnit: "N", units: U.force },
    ],
    equations: [
      { id: "f", tex: "F = ma", vars: ["F", "m", "a"], solve: {
        F: (k) => k.m * k.a, m: (k) => k.F / k.a, a: (k) => k.F / k.m,
      }},
      { id: "w", tex: "W = mg", vars: ["W", "m", "g"], solve: {
        W: (k) => k.m * k.g, m: (k) => k.W / k.g, g: (k) => k.W / k.m,
      }},
    ],
  },
  {
    id: "energy",
    fa: "کار و انرژی",
    desc: "انرژی جنبشی، پتانسیل گرانشی و کار نیروی ثابت",
    constants: [{ key: "g", fa: "شتاب گرانش زمین", value: 9.81, unit: "m/s²" }],
    vars: [
      { key: "K", fa: "انرژی جنبشی", siUnit: "J", units: U.energy },
      { key: "U", fa: "انرژی پتانسیل", siUnit: "J", units: U.energy },
      { key: "W", fa: "کار", siUnit: "J", units: U.energy },
      { key: "m", fa: "جرم", siUnit: "kg", units: U.mass },
      { key: "v", fa: "سرعت", siUnit: "m/s", units: U.speed },
      { key: "h", fa: "ارتفاع", siUnit: "m", units: U.length },
      { key: "F", fa: "نیرو", siUnit: "N", units: U.force },
      { key: "d", fa: "جابه‌جایی در جهت نیرو", siUnit: "m", units: U.length },
    ],
    equations: [
      { id: "k", tex: "K = \\tfrac{1}{2}mv^2", vars: ["K", "m", "v"], solve: {
        K: (k) => 0.5 * k.m * k.v * k.v,
        m: (k) => (2 * k.K) / (k.v * k.v),
        v: (k) => Math.sqrt((2 * k.K) / k.m),
      }},
      { id: "u", tex: "U = mgh", vars: ["U", "m", "g", "h"], solve: {
        U: (k) => k.m * k.g * k.h, m: (k) => k.U / (k.g * k.h), h: (k) => k.U / (k.m * k.g),
      }},
      { id: "w", tex: "W = Fd", vars: ["W", "F", "d"], solve: {
        W: (k) => k.F * k.d, F: (k) => k.W / k.d, d: (k) => k.W / k.F,
      }},
    ],
  },
  {
    id: "collision",
    fa: "تکانه و برخورد کشسان (یک‌بعدی)",
    desc: "پایستگی تکانه؛ سرعت‌های پس از برخورد کشسان",
    constants: [],
    vars: [
      { key: "m1", fa: "جرم گلوله ۱", siUnit: "kg", units: U.mass },
      { key: "m2", fa: "جرم گلوله ۲", siUnit: "kg", units: U.mass },
      { key: "v1", fa: "سرعت اولیه ۱", siUnit: "m/s", units: U.speed },
      { key: "v2", fa: "سرعت اولیه ۲", siUnit: "m/s", units: U.speed },
      { key: "v1p", fa: "سرعت نهایی ۱", siUnit: "m/s", units: U.speed },
      { key: "v2p", fa: "سرعت نهایی ۲", siUnit: "m/s", units: U.speed },
      { key: "p", fa: "تکانه", siUnit: "kg·m/s", units: U.momentum },
    ],
    equations: [
      { id: "p", tex: "p = m_1 v_1 + m_2 v_2", vars: ["p", "m1", "v1", "m2", "v2"], solve: {
        p: (k) => k.m1 * k.v1 + k.m2 * k.v2,
        v1: (k) => (k.p - k.m2 * k.v2) / k.m1,
        v2: (k) => (k.p - k.m1 * k.v1) / k.m2,
      }},
      { id: "e1", tex: "v_1' = \\frac{m_1-m_2}{m_1+m_2}v_1 + \\frac{2m_2}{m_1+m_2}v_2", vars: ["v1p", "m1", "m2", "v1", "v2"], solve: {
        v1p: (k) => ((k.m1 - k.m2) * k.v1 + 2 * k.m2 * k.v2) / (k.m1 + k.m2),
      }},
      { id: "e2", tex: "v_2' = \\frac{m_2-m_1}{m_1+m_2}v_2 + \\frac{2m_1}{m_1+m_2}v_1", vars: ["v2p", "m1", "m2", "v1", "v2"], solve: {
        v2p: (k) => ((k.m2 - k.m1) * k.v2 + 2 * k.m1 * k.v1) / (k.m1 + k.m2),
      }},
    ],
  },
  {
    id: "circular",
    fa: "حرکت دایره‌ای یکنواخت",
    desc: "شتاب جانب‌مرکز و دوره",
    constants: [],
    vars: [
      { key: "v", fa: "سرعت خطی", siUnit: "m/s", units: U.speed },
      { key: "r", fa: "شعاع", siUnit: "m", units: U.length },
      { key: "ac", fa: "شتاب جانب‌مرکز", siUnit: "m/s²", units: U.accel },
      { key: "T", fa: "دوره", siUnit: "s", units: U.time },
      { key: "Fc", fa: "نیروی جانب‌مرکز", siUnit: "N", units: U.force },
      { key: "m", fa: "جرم", siUnit: "kg", units: U.mass },
    ],
    equations: [
      { id: "ac", tex: "a_c = \\frac{v^2}{r}", vars: ["ac", "v", "r"], solve: {
        ac: (k) => (k.v * k.v) / k.r, v: (k) => Math.sqrt(k.ac * k.r), r: (k) => (k.v * k.v) / k.ac,
      }},
      { id: "vt", tex: "v = \\frac{2\\pi r}{T}", vars: ["v", "r", "T"], solve: {
        v: (k) => (2 * Math.PI * k.r) / k.T, r: (k) => (k.v * k.T) / (2 * Math.PI), T: (k) => (2 * Math.PI * k.r) / k.v,
      }},
      { id: "fc", tex: "F_c = ma_c", vars: ["Fc", "m", "ac"], solve: {
        Fc: (k) => k.m * k.ac, m: (k) => k.Fc / k.ac, ac: (k) => k.Fc / k.m,
      }},
    ],
  },
  {
    id: "gravity",
    fa: "گرانش جهانی",
    desc: "قانون گرانش نیوتن و g سطح سیاره",
    constants: [{ key: "G", fa: "ثابت جهانی گرانش", value: 6.674e-11, unit: "N·m²/kg²" }],
    vars: [
      { key: "F", fa: "نیروی گرانشی", siUnit: "N", units: U.force },
      { key: "m1", fa: "جرم ۱", siUnit: "kg", units: U.mass },
      { key: "m2", fa: "جرم ۲", siUnit: "kg", units: U.mass },
      { key: "r", fa: "فاصله‌ی مراکز", siUnit: "m", units: U.length },
    ],
    equations: [
      { id: "g", tex: "F = G\\frac{m_1 m_2}{r^2}", vars: ["F", "m1", "m2", "r", "G"], solve: {
        F: (k) => (k.G * k.m1 * k.m2) / (k.r * k.r),
        m1: (k) => (k.F * k.r * k.r) / (k.G * k.m2),
        r: (k) => Math.sqrt((k.G * k.m1 * k.m2) / k.F),
      }},
    ],
  },
  {
    id: "waves",
    fa: "امواج",
    desc: "رابطه‌ی سرعت، بسامد و طول موج",
    constants: [],
    vars: [
      { key: "v", fa: "سرعت موج", siUnit: "m/s", units: U.speed },
      { key: "f", fa: "بسامد", siUnit: "Hz", units: U.freq },
      { key: "lam", fa: "طول موج λ", siUnit: "m", units: U.length },
      { key: "T", fa: "دوره", siUnit: "s", units: U.time },
    ],
    equations: [
      { id: "wv", tex: "v = f\\lambda", vars: ["v", "f", "lam"], solve: {
        v: (k) => k.f * k.lam, f: (k) => k.v / k.lam, lam: (k) => k.v / k.f,
      }},
      { id: "tf", tex: "T = \\frac{1}{f}", vars: ["T", "f"], solve: {
        T: (k) => 1 / k.f, f: (k) => 1 / k.T,
      }},
    ],
  },
  {
    id: "circuits",
    fa: "مدارهای DC",
    desc: "قانون اهم و توان الکتریکی",
    constants: [],
    vars: [
      { key: "V", fa: "ولتاژ", siUnit: "V", units: U.volt },
      { key: "I", fa: "جریان", siUnit: "A", units: U.amp },
      { key: "R", fa: "مقاومت", siUnit: "Ω", units: U.ohm },
      { key: "P", fa: "توان", siUnit: "W", units: U.power },
      { key: "R1", fa: "مقاومت ۱", siUnit: "Ω", units: U.ohm },
      { key: "R2", fa: "مقاومت ۲", siUnit: "Ω", units: U.ohm },
      { key: "Rs", fa: "مقاومت معادل سری", siUnit: "Ω", units: U.ohm },
      { key: "Rp", fa: "مقاومت معادل موازی", siUnit: "Ω", units: U.ohm },
    ],
    equations: [
      { id: "ohm", tex: "V = IR", vars: ["V", "I", "R"], solve: {
        V: (k) => k.I * k.R, I: (k) => k.V / k.R, R: (k) => k.V / k.I,
      }},
      { id: "pw", tex: "P = VI", vars: ["P", "V", "I"], solve: {
        P: (k) => k.V * k.I, V: (k) => k.P / k.I, I: (k) => k.P / k.V,
      }},
      { id: "ser", tex: "R_s = R_1 + R_2", vars: ["Rs", "R1", "R2"], solve: {
        Rs: (k) => k.R1 + k.R2, R1: (k) => k.Rs - k.R2, R2: (k) => k.Rs - k.R1,
      }},
      { id: "par", tex: "\\frac{1}{R_p} = \\frac{1}{R_1} + \\frac{1}{R_2}", vars: ["Rp", "R1", "R2"], solve: {
        Rp: (k) => (k.R1 * k.R2) / (k.R1 + k.R2),
        R1: (k) => (k.Rp * k.R2) / (k.R2 - k.Rp),
        R2: (k) => (k.Rp * k.R1) / (k.R1 - k.Rp),
      }},
    ],
  },
  {
    id: "gas",
    fa: "گاز ایده‌آل",
    desc: "معادله‌ی حالت PV = nRT (دما حتماً به کلوین)",
    constants: [{ key: "R", fa: "ثابت گازها", value: 8.314, unit: "J/(mol·K)" }],
    vars: [
      { key: "P", fa: "فشار", siUnit: "Pa", units: U.pressure },
      { key: "V", fa: "حجم", siUnit: "m³", units: U.volume },
      { key: "n", fa: "مقدار ماده", siUnit: "mol", units: U.mol },
      { key: "T", fa: "دما", siUnit: "K", units: U.temp },
    ],
    equations: [
      { id: "gas", tex: "PV = nRT", vars: ["P", "V", "n", "T", "R"], solve: {
        P: (k) => (k.n * k.R * k.T) / k.V,
        V: (k) => (k.n * k.R * k.T) / k.P,
        n: (k) => (k.P * k.V) / (k.R * k.T),
        T: (k) => (k.P * k.V) / (k.n * k.R),
      }},
    ],
  },
  {
    id: "lens",
    fa: "عدسی نازک",
    desc: "معادله‌ی عدسی نازک و بزرگ‌نمایی",
    constants: [],
    vars: [
      { key: "f", fa: "فاصله کانونی", siUnit: "m", units: U.length },
      { key: "do", fa: "فاصله جسم", siUnit: "m", units: U.length },
      { key: "di", fa: "فاصله تصویر", siUnit: "m", units: U.length },
      { key: "m", fa: "بزرگ‌نمایی", siUnit: "(بدون واحد)", units: { "×": 1 } },
    ],
    equations: [
      { id: "lens", tex: "\\frac{1}{f} = \\frac{1}{d_o} + \\frac{1}{d_i}", vars: ["f", "do", "di"], solve: {
        f: (k) => (k.do * k.di) / (k.do + k.di),
        do: (k) => (k.f * k.di) / (k.di - k.f),
        di: (k) => (k.f * k.do) / (k.do - k.f),
      }},
      { id: "mag", tex: "m = -\\frac{d_i}{d_o}", vars: ["m", "di", "do"], solve: {
        m: (k) => -k.di / k.do, di: (k) => -k.m * k.do, do: (k) => -k.di / k.m,
      }},
    ],
  },
];
