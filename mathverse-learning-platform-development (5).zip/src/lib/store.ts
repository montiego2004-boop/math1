"use client";

import { useCallback, useEffect, useState } from "react";

/* ------------------------------------------------------------------ */
/* Local-first storage: progress, bookmarks, notes, history.           */
/* No accounts — everything stays on the user's device.                */
/* ------------------------------------------------------------------ */

const EVT = "mv-store-change";

function readJSON<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeJSON(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new CustomEvent(EVT, { detail: { key } }));
  } catch {
    /* storage full / unavailable — fail silently */
  }
}

export function useLocalStore<T>(key: string, fallback: T) {
  const [value, setValue] = useState<T>(fallback);
  useEffect(() => {
    setValue(readJSON(key, fallback));
    const onChange = (e: Event) => {
      const k = (e as CustomEvent).detail?.key;
      if (k === key) setValue(readJSON(key, fallback));
    };
    window.addEventListener(EVT, onChange);
    return () => window.removeEventListener(EVT, onChange);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  const set = useCallback((v: T | ((p: T) => T)) => {
    const cur = readJSON(key, fallback);
    const next = typeof v === "function" ? (v as (p: T) => T)(cur) : v;
    writeJSON(key, next);
    setValue(next);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  return [value, set] as const;
}

/* --------------------------- Progress ------------------------------ */

export interface ProgressData {
  completedLessons: string[];
  visitedLessons: string[];
  exerciseStats: {
    answered: number;
    correct: number;
    byTopic: Record<string, { answered: number; correct: number }>;
  };
  toolUsage: Record<string, number>;
}

export const emptyProgress: ProgressData = {
  completedLessons: [],
  visitedLessons: [],
  exerciseStats: { answered: 0, correct: 0, byTopic: {} },
  toolUsage: {},
};

export function useProgress() {
  const [progress, setProgress] = useLocalStore<ProgressData>("mv-progress-v1", emptyProgress);

  const visitLesson = useCallback(
    (id: string) => {
      setProgress((p) => ({
        ...p,
        visitedLessons: p.visitedLessons.includes(id)
          ? p.visitedLessons
          : [...p.visitedLessons, id],
      }));
    },
    [setProgress]
  );

  const toggleLessonComplete = useCallback(
    (id: string) => {
      setProgress((p) => ({
        ...p,
        completedLessons: p.completedLessons.includes(id)
          ? p.completedLessons.filter((x) => x !== id)
          : [...p.completedLessons, id],
      }));
    },
    [setProgress]
  );

  const recordExercise = useCallback(
    (topic: string, correct: boolean) => {
      setProgress((p) => {
        const t = p.exerciseStats.byTopic[topic] ?? { answered: 0, correct: 0 };
        return {
          ...p,
          exerciseStats: {
            answered: p.exerciseStats.answered + 1,
            correct: p.exerciseStats.correct + (correct ? 1 : 0),
            byTopic: {
              ...p.exerciseStats.byTopic,
              [topic]: { answered: t.answered + 1, correct: t.correct + (correct ? 1 : 0) },
            },
          },
        };
      });
    },
    [setProgress]
  );

  const recordToolUse = useCallback(
    (tool: string) => {
      setProgress((p) => ({
        ...p,
        toolUsage: { ...p.toolUsage, [tool]: (p.toolUsage[tool] ?? 0) + 1 },
      }));
    },
    [setProgress]
  );

  return { progress, visitLesson, toggleLessonComplete, recordExercise, recordToolUse };
}

/* --------------------------- Bookmarks ----------------------------- */

export function useBookmarks() {
  const [bookmarks, setBookmarks] = useLocalStore<string[]>("mv-bookmarks-v1", []);
  const toggle = useCallback(
    (id: string) => {
      setBookmarks((b) => (b.includes(id) ? b.filter((x) => x !== id) : [...b, id]));
    },
    [setBookmarks]
  );
  return { bookmarks, toggleBookmark: toggle };
}

/* ----------------------------- Notes ------------------------------- */

export function useNotes() {
  const [notes, setNotes] = useLocalStore<Record<string, string>>("mv-notes-v1", {});
  const setNote = useCallback(
    (id: string, text: string) => {
      setNotes((n) => ({ ...n, [id]: text }));
    },
    [setNotes]
  );
  return { notes, setNote };
}

export function useCalcHistory() {
  const [history, setHistory] = useLocalStore<{ expr: string; result: string }[]>(
    "mv-calc-history-v1",
    []
  );
  const push = useCallback(
    (expr: string, result: string) => {
      setHistory((h) => [{ expr, result }, ...h].slice(0, 50));
    },
    [setHistory]
  );
  const clear = useCallback(() => setHistory([]), [setHistory]);
  return { history, push, clear };
}
