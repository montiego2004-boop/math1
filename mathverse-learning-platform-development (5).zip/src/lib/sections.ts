import {
  LayoutDashboard,
  Sigma,
  Atom,
  FlaskConical,
  LineChart,
  Box,
  Calculator,
  BrainCircuit,
  Zap,
  BarChart3,
  LibraryBig,
  FunctionSquare,
  Dumbbell,
  TrendingUp,
  Info,
  type LucideIcon,
} from "lucide-react";

export interface Section {
  href: string;
  fa: string;
  en: string;
  desc: string;
  icon: LucideIcon;
}

export const SECTIONS: Section[] = [
  { href: "/", fa: "داشبورد", en: "Home Dashboard", desc: "نمای کلی و دسترسی سریع", icon: LayoutDashboard },
  { href: "/academy/math", fa: "آکادمی ریاضیات", en: "Mathematics Academy", desc: "از مبانی تا ریاضیات پیشرفته در چهار سطح", icon: Sigma },
  { href: "/academy/physics", fa: "آکادمی فیزیک", en: "Physics Academy", desc: "مکانیک تا فیزیک مدرن", icon: Atom },
  { href: "/lab", fa: "آزمایشگاه", en: "Laboratory", desc: "آزمایش‌های تعاملی ریاضی و فیزیک", icon: FlaskConical },
  { href: "/graph-2d", fa: "ریاضیات دوبعدی", en: "2D Mathematics", desc: "رسم توابع، مشتق، انتگرال و هندسه", icon: LineChart },
  { href: "/graph-3d", fa: "ریاضیات سه‌بعدی", en: "3D Mathematics", desc: "سطوح و منحنی‌های فضایی تعاملی", icon: Box },
  { href: "/calculator", fa: "ماشین‌حساب علمی", en: "Scientific Calculator", desc: "محاسبات علمی با درجه/رادیان و تاریخچه", icon: Calculator },
  { href: "/solver", fa: "حل‌گر مسائل ریاضی", en: "Math Problem Solver", desc: "جبر نمادین، مشتق، انتگرال، ماتریس", icon: BrainCircuit },
  { href: "/physics-solver", fa: "حل‌گر مسائل فیزیک", en: "Physics Problem Solver", desc: "معادلات فیزیکی با کنترل واحدها", icon: Zap },
  { href: "/stats", fa: "آمار و احتمال", en: "Statistics Lab", desc: "آمار توصیفی، توزیع‌ها، رگرسیون، شبیه‌سازی", icon: BarChart3 },
  { href: "/library", fa: "کتابخانه علمی", en: "Digital Library", desc: "منابع آموزشی آزاد و قانونی", icon: LibraryBig },
  { href: "/formulas", fa: "دانشنامه فرمول‌ها", en: "Formula Encyclopedia", desc: "جست‌وجوی فرمول‌های ریاضی و فیزیک", icon: FunctionSquare },
  { href: "/exercises", fa: "مرکز تمرین", en: "Practice Center", desc: "تمرین، پرسش چندگزینه‌ای و راهنمای گام‌به‌گام", icon: Dumbbell },
  { href: "/progress", fa: "پیشرفت یادگیری", en: "Learning Progress", desc: "آمار یادگیری محلی شما", icon: TrendingUp },
  { href: "/about", fa: "درباره مث‌ورس", en: "About", desc: "ماموریت، مجوزها و فناوری", icon: Info },
];
