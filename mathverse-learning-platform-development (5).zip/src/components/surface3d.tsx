"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { create, all } from "mathjs";
import { Plus, Trash2, Grid3x3, Palette, RotateCcw } from "lucide-react";

const math = create(all);

const PRESETS = [
  { label: "سهموی چرخشی", expr: "x^2 + y^2" },
  { label: "زینی", expr: "x^2 - y^2" },
  { label: "موج", expr: "3*sin(sqrt(x^2 + y^2))" },
  { label: "نیم‌کره", expr: "sqrt(max(0, 16 - x^2 - y^2))" },
  { label: "زینی میمونی", expr: "x^3 - 3*x*y^2" },
];

interface Surf {
  id: number;
  expr: string;
  color: string;
  visible: boolean;
}

let idc = 3;

function colorFor(z: number, zmin: number, zmax: number, base: THREE.Color) {
  const t = zmax > zmin ? (z - zmin) / (zmax - zmin) : 0.5;
  const c = base.clone();
  c.lerp(new THREE.Color("#ffffff"), t * 0.35);
  c.offsetHSL(0.06 * (t - 0.5), 0.08 * (t - 0.5), 0.12 * (t - 0.5));
  return c;
}

export interface Surface3DScene {
  surfs?: Surf[];
  range?: number;
  res?: number;
  wire?: boolean;
}

export default function Surface3D({
  initialScene,
  onSceneChange,
}: {
  initialScene?: Surface3DScene;
  onSceneChange?: (scene: { surfs: Surf[]; range: number; res: number; wire: boolean }) => void;
} = {}) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [surfs, setSurfs] = useState<Surf[]>(initialScene?.surfs ?? [{ id: 1, expr: "x^2 - y^2", color: "#2dd4bf", visible: true }]);
  const [range, setRange] = useState(initialScene?.range ?? 4);
  const [res, setRes] = useState(initialScene?.res ?? 64);
  const [wire, setWire] = useState(initialScene?.wire ?? false);
  const [status, setStatus] = useState("");

  const sceneRef = useRef<{
    scene?: THREE.Scene;
    camera?: THREE.PerspectiveCamera;
    renderer?: THREE.WebGLRenderer;
    group?: THREE.Group;
    raf?: number;
    sph: { th: number; ph: number; r: number };
  }>({ sph: { th: Math.PI / 4, ph: Math.PI / 3.4, r: 14 } });
  const surfsRef = useRef(surfs);
  const rngRef = useRef({ range, res, wire });
  surfsRef.current = surfs;
  rngRef.current = { range, res, wire };

  // scene publish (for local save/restore) — additive, optional
  useEffect(() => {
    onSceneChange?.({ surfs, range, res, wire });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [surfs, range, res, wire]);

  const rebuild = useCallback(() => {
    const S = sceneRef.current;
    if (!S.group) return;
    // clear old
    while (S.group.children.length) {
      const ch = S.group.children[0];
      S.group.remove(ch);
      const m = ch as THREE.Mesh;
      m.geometry?.dispose();
      const mat = m.material as THREE.Material | THREE.Material[];
      if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
      else mat?.dispose();
    }
    const { range: R, res: N, wire } = rngRef.current;
    let msg = "";
    for (const s of surfsRef.current) {
      if (!s.visible) continue;
      let fn: any;
      try {
        fn = math.compile(s.expr);
      } catch {
        msg = `خطای تجزیه: ${s.expr}`;
        continue;
      }
      const geo = new THREE.BufferGeometry();
      const verts: number[] = [];
      const cols: number[] = [];
      const idx: number[] = [];
      let zmin = Infinity, zmax = -Infinity;
      const zs: (number | null)[][] = [];
      for (let i = 0; i <= N; i++) {
        zs.push([]);
        for (let j = 0; j <= N; j++) {
          const x = -R + (2 * R * i) / N;
          const y = -R + (2 * R * j) / N;
          let z: number | null = null;
          try {
            const v = fn.evaluate({ x, y });
            if (typeof v === "number" && isFinite(v) && Math.abs(v) < 1e6) z = v;
          } catch {}
          zs[i][j] = z;
          if (z !== null) {
            zmin = Math.min(zmin, z);
            zmax = Math.max(zmax, z);
          }
        }
      }
      if (zmin === Infinity) {
        msg = `مقادیر معتبر در بازه یافت نشد: ${s.expr}`;
        continue;
      }
      const base = new THREE.Color(s.color);
      const vIdx: number[][] = [];
      for (let i = 0; i <= N; i++) {
        vIdx.push([]);
        for (let j = 0; j <= N; j++) {
          const x = -R + (2 * R * i) / N;
          const y = -R + (2 * R * j) / N;
          const z = zs[i][j] ?? 0;
          verts.push(x, z, y); // three y-up
          const c = colorFor(z, zmin, zmax, base);
          cols.push(c.r, c.g, c.b);
          vIdx[i][j] = verts.length / 3 - 1;
        }
      }
      for (let i = 0; i < N; i++) {
        for (let j = 0; j < N; j++) {
          if (zs[i][j] === null || zs[i + 1][j] === null || zs[i][j + 1] === null || zs[i + 1][j + 1] === null) continue;
          const a = vIdx[i][j], b = vIdx[i + 1][j], c = vIdx[i][j + 1], d = vIdx[i + 1][j + 1];
          idx.push(a, b, d, a, d, c);
        }
      }
      geo.setIndex(idx);
      geo.setAttribute("position", new THREE.Float32BufferAttribute(verts, 3));
      geo.setAttribute("color", new THREE.Float32BufferAttribute(cols, 3));
      geo.computeVertexNormals();
      const mat = new THREE.MeshStandardMaterial({
        vertexColors: true,
        side: THREE.DoubleSide,
        metalness: 0.15,
        roughness: 0.55,
        wireframe: wire,
        transparent: true,
        opacity: wire ? 0.9 : 0.97,
      });
      const mesh = new THREE.Mesh(geo, mat);
      S.group.add(mesh);
    }
    setStatus(msg);
  }, []);

  // init three once
  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    const S = sceneRef.current;
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(52, 1, 0.1, 300);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    mount.appendChild(renderer.domElement);
    const group = new THREE.Group();
    scene.add(group);

    const grid = new THREE.GridHelper(20, 20, 0x2dd4bf, 0x1c3355);
    (grid.material as THREE.Material).transparent = true;
    (grid.material as THREE.Material).opacity = 0.5;
    scene.add(grid);

    // axes: x red, y green, z blue
    const mkAxis = (dir: THREE.Vector3, color: number) => {
      const g = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0), dir]);
      return new THREE.Line(g, new THREE.LineBasicMaterial({ color }));
    };
    scene.add(mkAxis(new THREE.Vector3(10, 0, 0), 0xf87171));
    scene.add(mkAxis(new THREE.Vector3(0, 10, 0), 0x4ade80));
    scene.add(mkAxis(new THREE.Vector3(0, 0, 10), 0x60a5fa));

    scene.add(new THREE.AmbientLight(0xffffff, 0.65));
    const dl = new THREE.DirectionalLight(0xffffff, 1.1);
    dl.position.set(6, 10, 4);
    scene.add(dl);

    S.scene = scene;
    S.camera = camera;
    S.renderer = renderer;
    S.group = group;

    const resize = () => {
      const w = mount.clientWidth;
      const h = Math.max(380, Math.min(560, window.innerHeight * 0.6));
      renderer.setSize(w, h);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();
    window.addEventListener("resize", resize);

    // orbit controls (custom, lightweight)
    let dragging = false;
    let px = 0, py = 0;
    const el = renderer.domElement;
    const down = (e: PointerEvent) => { dragging = true; px = e.clientX; py = e.clientY; el.setPointerCapture(e.pointerId); };
    const up = () => { dragging = false; };
    const move = (e: PointerEvent) => {
      if (!dragging) return;
      S.sph.th -= (e.clientX - px) * 0.008;
      S.sph.ph = Math.min(Math.PI - 0.1, Math.max(0.1, S.sph.ph - (e.clientY - py) * 0.008));
      px = e.clientX; py = e.clientY;
    };
    const wheel = (e: WheelEvent) => {
      e.preventDefault();
      S.sph.r = Math.min(60, Math.max(4, S.sph.r * (e.deltaY > 0 ? 1.1 : 0.9)));
    };
    el.addEventListener("pointerdown", down);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointermove", move);
    el.addEventListener("wheel", wheel, { passive: false });

    const tick = () => {
      const { th, ph, r } = S.sph;
      camera.position.set(r * Math.sin(ph) * Math.cos(th), r * Math.cos(ph), r * Math.sin(ph) * Math.sin(th));
      camera.lookAt(0, 0, 0);
      renderer.render(scene, camera);
      S.raf = requestAnimationFrame(tick);
    };
    tick();
    rebuild();

    return () => {
      cancelAnimationFrame(S.raf!);
      window.removeEventListener("resize", resize);
      el.removeEventListener("pointerdown", down);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointermove", move);
      el.removeEventListener("wheel", wheel);
      renderer.dispose();
      mount.removeChild(el);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // rebuild when inputs change
  useEffect(() => {
    rebuild();
  }, [surfs, range, res, wire, rebuild]);

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_300px]">
      <div>
        <div ref={mountRef} className="card overflow-hidden" />
        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
          <button className="btn !text-xs" onClick={() => { sceneRef.current.sph = { th: Math.PI / 4, ph: Math.PI / 3.4, r: 14 }; }}>
            <RotateCcw className="size-3.5" /> بازنشانی دوربین
          </button>
          <label className="chip gap-2">
            <Grid3x3 className="size-3" /> برد x,y ∈ ±{range}
            <input type="range" min={2} max={12} value={range} onChange={(e) => setRange(Number(e.target.value))} />
          </label>
          <label className="chip gap-2">
            تفکیک: {res}
            <input type="range" min={24} max={120} step={4} value={res} onChange={(e) => setRes(Number(e.target.value))} />
          </label>
          <label className="chip cursor-pointer gap-1.5" onClick={() => setWire((w) => !w)}>
            <Palette className="size-3" /> {wire ? "حالت شبکه (سیم‌لوله)" : "حالت سطح"}
          </label>
        </div>
        {status && <p className="mt-2 text-xs text-warn">{status}</p>}
        <p className="mt-2 text-[11px] text-muted">کشیدن: چرخش • چرخ: بزرگ‌نمایی. محورها: x قرمز، y سبز، z آبی.</p>
      </div>

      <aside className="space-y-3">
        {surfs.map((s) => (
          <div key={s.id} className="card p-3">
            <label className="mb-1 block font-mono text-xs text-muted">z = f(x, y)</label>
            <div className="flex gap-1.5" dir="ltr">
              <input
                className="input flex-1 !px-2 !py-1 font-mono text-xs"
                value={s.expr}
                onChange={(e) => setSurfs((q) => q.map((o) => (o.id === s.id ? { ...o, expr: e.target.value } : o)))}
              />
              <input type="color" value={s.color} className="size-8 cursor-pointer rounded bg-transparent"
                onChange={(e) => setSurfs((q) => q.map((o) => (o.id === s.id ? { ...o, color: e.target.value } : o)))} />
              <button className="btn !px-2 hover:!border-danger hover:!text-danger"
                onClick={() => setSurfs((q) => q.filter((o) => o.id !== s.id))}>
                <Trash2 className="size-3.5" />
              </button>
            </div>
          </div>
        ))}
        <button className="btn w-full justify-center !text-xs" onClick={() => setSurfs((q) => [...q, { id: idc++, expr: "sin(x)*cos(y)", color: "#a78bfa", visible: true }])}>
          <Plus className="size-3.5" /> افزودن سطح
        </button>
        <div className="card p-3">
          <div className="mb-2 text-xs font-bold">پیش‌تنظیم‌ها:</div>
          <div className="flex flex-wrap gap-1.5">
            {PRESETS.map((p) => (
              <button key={p.label} className="chip hover:!border-accent hover:!text-accent"
                onClick={() => setSurfs((q) => [{ id: idc++, expr: p.expr, color: "#2dd4bf", visible: true }, ...q])}>
                {p.label}
              </button>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}
