"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Plus, Zap } from "lucide-react";
import { rk4, useLoop, useCanvas2D, Slider, Controls, Note, Panel, G } from "./lab-experiments";
import { TeX } from "@/components/katex";

/* ==================== 1. Incline: Newton + friction ==================== */

export function InclineExp() {
  const [deg, setDeg] = useState(28);
  const [m, setM] = useState(2);
  const [mus, setMus] = useState(0.4);
  const [muk, setMuk] = useState(0.3);
  const [running, setRunning] = useState(false);
  const { ref, draw } = useCanvas2D();
  const st = useRef({ s: 0, v: 0, t: 0 });
  const [ro, setRo] = useState({ s: 0, v: 0 });

  const th = (deg * Math.PI) / 180;
  const fDown = m * G * Math.sin(th);
  const N = m * G * Math.cos(th);
  const fStaticMax = mus * N;
  const slides = fDown > fStaticMax;
  const accel = slides ? (fDown - muk * N) / m : 0;

  const reset = useCallback(() => { st.current = { s: 0, v: 0, t: 0 }; }, []);
  useEffect(reset, [reset]);

  useLoop((dt) => {
    const s = st.current;
    if (slides && running) {
      s.v += accel * dt;
      s.s += s.v * dt;
      s.t += dt;
      if (s.s > 9) { s.t = 0; s.s = 0; s.v = 0; }
    }
    draw((ctx, W, H) => {
      const baseX = 30, baseY = H - 30;
      const Lpx = W - 90;
      const tipX = baseX + Lpx * Math.cos(th);
      const tipY = baseY - Lpx * Math.sin(th);
      // incline
      ctx.fillStyle = "#1c3355";
      ctx.beginPath();
      ctx.moveTo(baseX, baseY); ctx.lineTo(tipX, tipY); ctx.lineTo(tipX, baseY);
      ctx.closePath(); ctx.fill();
      // block on plane
      const px = baseX + (s.s / 9) * Lpx * 0.9 * Math.cos(th);
      const py = baseY - (s.s / 9) * Lpx * 0.9 * Math.sin(th);
      ctx.save();
      ctx.translate(px, py);
      ctx.rotate(-th);
      ctx.fillStyle = "#f472b6";
      ctx.fillRect(-18, -22, 36, 22);
      ctx.restore();
      // force arrows from block (unit vectors: up-plane & outward normal)
      const ux = Math.cos(th), uy = -Math.sin(th);
      const nx = Math.sin(th), ny = Math.cos(th);
      const fs = 0.05;
      const vec = (fx: number, fy: number, color: string, label: string) => {
        ctx.strokeStyle = color; ctx.lineWidth = 2.2;
        ctx.beginPath(); ctx.moveTo(px, py - 24); ctx.lineTo(px + fx, py - 24 + fy); ctx.stroke();
        ctx.fillStyle = color; ctx.font = "10px monospace";
        ctx.fillText(label, px + fx + 6, py - 28 + fy);
      };
      vec(0, m * G * fs, "#60a5fa", "mg");
      vec(N * fs * nx, -N * fs * ny, "#2dd4bf", "N");
      const fNow = slides ? muk * N : fDown;
      vec(-fNow * fs * ux, -fNow * fs * uy, "#fbbf24", "f");
    });
    setRo({ s: s.s, v: s.v });
  }, true);

  return (
    <Panel title="معادلات مدل" tex={["N = mg\\cos\\theta", "f_s \\le \\mu_s N, \\quad f_k = \\mu_k N", "a = g(\\sin\\theta - \\mu_k\\cos\\theta)"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <div className="grid grid-cols-3 gap-2 text-center text-xs" dir="ltr">
          <span className={`chip justify-center font-mono ${slides ? "!text-accent" : "!text-warn"}`}>{slides ? "سُر می‌خورد" : "ساکن (اصطکاک ایستایی کافی)"}</span>
          <span className="chip justify-center font-mono">a = {accel.toFixed(2)} m/s²</span>
          <span className="chip justify-center font-mono">s = {ro.s.toFixed(1)} m, v = {ro.v.toFixed(1)} m/s</span>
        </div>
      </div>
      <Controls running={running} onToggle={() => setRunning((r) => !r)} onReset={() => { reset(); }}>
        <Slider label="زاویهٔ شیب θ" value={deg} min={5} max={55} step={1} unit="°" onChange={setDeg} />
        <Slider label="جرم m" value={m} min={0.5} max={10} step={0.5} unit="kg" onChange={setM} />
        <Slider label="μs (ایستایی)" value={mus} min={0} max={1} step={0.05} onChange={setMus} />
        <Slider label="μk (جنبشی)" value={muk} min={0} max={1} step={0.05} onChange={setMuk} />
        <Note>قضاوت سکون/سر: اگر mg·sinθ ≤ μs·N جسم ساکن می‌ماند. جهت نیروی اصطکاک همیشه مخالفِ سر خوردن است. دیاگرام نیرو (آبی mg، فیروزه‌ای N، زرد f): دقت کنید شرط لغزش به جرم بستگی ندارد — فقط به tanθ و μs.</Note>
      </Controls>
    </Panel>
  );
}

/* ==================== 2. Double pendulum ==================== */

export function DoublePendulumExp() {
  const [L1, setL1] = useState(1.2);
  const [L2, setL2] = useState(1);
  const [d1, setD1] = useState(120);
  const [d2, setD2] = useState(90);
  const [running, setRunning] = useState(false);
  const { ref, draw } = useCanvas2D();
  const st = useRef({ s: [0, 0, 0, 0], t: 0 });
  const trail = useRef<[number, number][]>([]);
  const [ro, setRo] = useState({ E: 0, t: 0 });

  const reset = useCallback(() => {
    st.current = { s: [(d1 * Math.PI) / 180, 0, (d2 * Math.PI) / 180, 0], t: 0 };
    trail.current = [];
  }, [d1, d2]);
  useEffect(reset, [reset]);

  const deriv = useCallback((_t: number, s: number[]) => {
    const m1 = 1, m2 = 1;
    const [t1, w1, t2, w2] = s;
    const d = t1 - t2;
    const den = 2 * m1 + m2 - m2 * Math.cos(2 * t1 - 2 * t2);
    const dw1 = (-G * (2 * m1 + m2) * Math.sin(t1) - m2 * G * Math.sin(t1 - 2 * t2) - 2 * Math.sin(d) * m2 * (w2 * w2 * L2 + w1 * w1 * L1 * Math.cos(d))) / (L1 * den);
    const dw2 = (2 * Math.sin(d) * (w1 * w1 * L1 * (m1 + m2) + G * (m1 + m2) * Math.cos(t1) + w2 * w2 * L2 * m2 * Math.cos(d))) / (L2 * den);
    return [w1, dw1, w2, dw2];
  }, [L1, L2]);

  useLoop((dt) => {
    let s = st.current.s;
    let t = st.current.t;
    const n = 8, h = dt / n;
    for (let i = 0; i < n; i++) { s = rk4(s, deriv, t, h); t += h; }
    st.current = { s, t };
    const [t1, , t2] = s;
    draw((ctx, W, H) => {
      const cx = W / 2, cy = 40;
      const sc = Math.min(130, (H - 90) / (L1 + L2));
      const x1 = cx + Math.sin(t1) * L1 * sc, y1 = cy + Math.cos(t1) * L1 * sc;
      const x2 = x1 + Math.sin(t2) * L2 * sc, y2 = y1 + Math.cos(t2) * L2 * sc;
      const last = trail.current[trail.current.length - 1];
      if (!last || Math.hypot(last[0] - x2, last[1] - y2) > 2) trail.current.push([x2, y2]);
      if (trail.current.length > 600) trail.current.shift();
      ctx.strokeStyle = "rgba(244,114,182,0.4)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      trail.current.forEach(([tx, ty], i) => (i ? ctx.lineTo(tx, ty) : ctx.moveTo(tx, ty)));
      ctx.stroke();
      ctx.strokeStyle = "#8ea6c8";
      ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
      ctx.fillStyle = "#60a5fa";
      ctx.beginPath(); ctx.arc(x1, y1, 9, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#f472b6";
      ctx.beginPath(); ctx.arc(x2, y2, 9, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#2dd4bf";
      ctx.beginPath(); ctx.arc(cx, cy, 4, 0, Math.PI * 2); ctx.fill();
    });
    // energy (numerical)
    const [tt1, ww1, tt2, ww2] = s;
    const E =
      0.5 * (L1 * ww1) ** 2 +
      0.5 * ((L1 * ww1) ** 2 + (L2 * ww2) ** 2 + 2 * L1 * L2 * ww1 * ww2 * Math.cos(tt1 - tt2)) -
      G * (2 * L1 * Math.cos(tt1) + L2 * Math.cos(tt2));
    setRo({ E, t });
  }, running);

  return (
    <Panel title="معادلات (کوپل — برگرفته از لاگرانژین)" tex={["\\theta_i'' = f(\\theta_1, \\theta_2, \\dot\\theta_1, \\dot\\theta_2)", "E = T + V = \\text{ثابت}"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <div className="grid grid-cols-2 gap-2 text-center text-xs" dir="ltr">
          <span className="chip justify-center font-mono">t = {ro.t.toFixed(1)} s</span>
          <span className="chip justify-center font-mono !text-accent">E = {ro.E.toFixed(3)} J (پایسته)</span>
        </div>
      </div>
      <Controls running={running} onToggle={() => setRunning((r) => !r)} onReset={reset}>
        <Slider label="L₁" value={L1} min={0.5} max={2} step={0.1} unit="m" onChange={setL1} />
        <Slider label="L₂" value={L2} min={0.5} max={2} step={0.1} unit="m" onChange={setL2} />
        <Slider label="زاویهٔ اولیه θ₁" value={d1} min={30} max={175} step={5} unit="°" onChange={setD1} />
        <Slider label="زاویهٔ اولیه θ₂" value={d2} min={30} max={175} step={5} unit="°" onChange={setD2} />
        <Note>آونگ دوگانه سیستمی آشوبناک است: دو شرط اولیهٔ بسیار نزدیک به‌سرعت از هم فاصله می‌گیرند (آشوب قطعی، نه تصادف). انرژی با RK4 و گام کوچک تقریباً ثابت می‌ماند — انحراف کوچک آن (اگر دیده شود) خطای عددی گام زمانی است.</Note>
      </Controls>
    </Panel>
  );
}

/* ==================== 3. Resonance (driven damped oscillator) ==================== */

export function ResonanceExp() {
  const [m, setM] = useState(1);
  const [k, setK] = useState(40);
  const [beta, setBeta] = useState(0.6);
  const [F0, setF0] = useState(4);
  const [wd, setWd] = useState(5.5);
  const [running, setRunning] = useState(false);
  const { ref, draw } = useCanvas2D();
  const st = useRef({ x: 0, v: 0, t: 0 });
  const ampWindow = useRef({ max: 0 });
  const [ro, setRo] = useState({ x: 0, amp: 0 });

  const w0 = Math.sqrt(k / m);
  const ampTheory = F0 / m / Math.hypot(w0 * w0 - wd * wd, 2 * beta * wd);

  const deriv = useCallback((t: number, y: number[]) => [
    y[1],
    (F0 / m) * Math.cos(wd * t) - 2 * beta * y[1] - (k / m) * y[0],
  ], [m, k, beta, F0, wd]);

  const reset = useCallback(() => { st.current = { x: 0, v: 0, t: 0 }; ampWindow.current.max = 0; }, []);
  useEffect(reset, [reset]);

  useLoop((dt) => {
    let { x, v, t } = st.current;
    const n = 6, h = dt / n;
    for (let i = 0; i < n; i++) { [x, v] = rk4([x, v], deriv, t, h); t += h; }
    st.current = { x, v, t };
    if (t > 20) ampWindow.current.max = Math.max(ampWindow.current.max * (1 - dt * 0.08), Math.abs(x));
    draw((ctx, W, Hw) => {
      // amplitude curve bg
      const wmax = w0 * 2.2;
      ctx.strokeStyle = "rgba(96,165,250,0.7)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 0; i <= 200; i++) {
        const w = (wmax * i) / 200;
        const A = F0 / m / Math.max(1e-6, Math.hypot(w0 * w0 - w * w, 2 * beta * w));
        const px = 40 + (i / 200) * (W - 60);
        const py = Hw - 60 - (Math.min(A, 3) / 3) * (Hw - 140);
        i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
      }
      ctx.stroke();
      // current marker
      const mx = 40 + (wd / wmax) * (W - 60);
      const my = Hw - 60 - (Math.min(ampTheory, 3) / 3) * (Hw - 140);
      ctx.fillStyle = "#f472b6";
      ctx.beginPath(); ctx.arc(mx, my, 6, 0, Math.PI * 2); ctx.fill();
      // ω0 line
      ctx.strokeStyle = "#2dd4bf";
      ctx.setLineDash([4, 4]);
      const r0x = 40 + (w0 / wmax) * (W - 60);
      ctx.beginPath(); ctx.moveTo(r0x, 20); ctx.lineTo(r0x, Hw - 55); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = "#2dd4bf"; ctx.font = "10px monospace";
      ctx.fillText("ω₀", r0x - 8, 14);
      // block animation (top strip)
      const bx = W / 2 + x * 60;
      ctx.fillStyle = "#a78bfa";
      ctx.fillRect(bx - 16, 24, 32, 22);
    });
    setRo({ x, amp: ampWindow.current.max });
  }, running);

  return (
    <Panel title="معادلات مدل" tex={["\\ddot x + 2\\beta\\dot x + \\omega_0^2 x = \\frac{F_0}{m}\\cos(\\omega_d t)", "A(\\omega_d) = \\frac{F_0/m}{\\sqrt{(\\omega_0^2-\\omega_d^2)^2 + 4\\beta^2\\omega_d^2}}"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <div className="grid grid-cols-3 gap-2 text-center text-[11px]" dir="ltr">
          <span className="chip justify-center font-mono">ω₀ = {w0.toFixed(2)} rad/s</span>
          <span className="chip justify-center font-mono !text-[#f472b6]">A نظری = {ampTheory.toFixed(2)} متر</span>
          <span className="chip justify-center font-mono">A اندازه‌گیری = {ro.amp.toFixed(2)}</span>
        </div>
      </div>
      <Controls running={running} onToggle={() => setRunning((r) => !r)} onReset={reset}>
        <Slider label="جرم m" value={m} min={0.5} max={3} step={0.25} unit="kg" onChange={setM} />
        <Slider label="سختی k" value={k} min={10} max={100} step={2} unit="N/m" onChange={setK} />
        <Slider label="میرایی β" value={beta} min={0.1} max={2} step={0.05} unit="1/s" onChange={setBeta} />
        <Slider label="بسامد محرک ω_d" value={wd} min={1} max={14} step={0.1} unit="rad/s" onChange={setWd} />
        <Note>منحنی آبی: پاسخ دامنهٔ ماندگار نظری؛ نقطهٔ صورتی: بسامد جاری. در ω_d ≈ ω₀ رزونانس رخ می‌دهد — با β کم دامنه عملاً بزرگ می‌شود (واقعیت: پل تاکوما!). بلوک بالایی نوسان زندهٔ محاسبه‌شده با RK4 است.</Note>
      </Controls>
    </Panel>
  );
}

/* ==================== 4. Two-source wave interference ==================== */

export function InterferenceExp() {
  const [lam, setLam] = useState(0.8);
  const [d, setD] = useState(3);
  const [phase, setPhase] = useState(0);
  const [running, setRunning] = useState(true);
  const { ref, draw } = useCanvas2D();
  const t = useRef(0);

  useLoop((dt) => {
    t.current += dt * 2;
    const w = 2 * Math.PI; // ω = 1 Hz display
    const k = (2 * Math.PI) / lam;
    draw((ctx, W, H) => {
      const block = 7;
      for (let i = 0; i < W / block; i++) {
        for (let j = 0; j < H / block; j++) {
          const x = ((i / (W / block)) - 0.5) * 12;
          const y = ((j / (H / block)) - 0.5) * 12;
          const r1 = Math.hypot(x + d / 2, y);
          const r2 = Math.hypot(x - d / 2, y);
          const a1 = Math.sin(k * r1 - w * t.current) / Math.sqrt(Math.max(0.4, r1));
          const a2 = Math.sin(k * r2 - w * t.current + phase) / Math.sqrt(Math.max(0.4, r2));
          const A = a1 + a2; // superposition
          const u = Math.max(-1, Math.min(1, A));
          ctx.fillStyle = u > 0
            ? `rgba(45,212,191,${0.08 + 0.62 * u})`
            : `rgba(244,114,182,${0.08 - 0.62 * u})`;
          ctx.fillRect(i * block, j * block, block + 0.5, block + 0.5);
        }
      }
      // sources
      for (const sgn of [-1, 1]) {
        const sx = W / 2 + (sgn * d / 12) * W, sy = H / 2;
        ctx.fillStyle = "#fbbf24";
        ctx.beginPath(); ctx.arc(sx, sy, 6, 0, Math.PI * 2); ctx.fill();
      }
    });
  }, running);

  return (
    <Panel title="معادلات مدل" tex={["y = A_1 + A_2 = \\sin(kr_1-\\omega t) + \\sin(kr_2-\\omega t+\\Delta\\varphi)", "\\Delta\\varphi_{\\text{مکان}} = k(r_2 - r_1)"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <p className="text-[11px] text-muted">فیروزه‌ای: قله/تراکم • صورتی: دره/تخلخل — نوارهای تداخل سازنده/مخرب هذلولی‌وار دور دو چشمه‌اند.</p>
      </div>
      <Controls running={running} onToggle={() => setRunning((r) => !r)} onReset={() => { t.current = 0; }}>
        <Slider label="طول موج λ" value={lam} min={0.3} max={2} step={0.05} unit="m" onChange={setLam} />
        <Slider label="فاصلهٔ چشمه‌ها d" value={d} min={1} max={8} step={0.25} unit="m" onChange={setD} />
        <Slider label="اختلاف فاز اولیه Δφ" value={phase} min={0} max={Math.PI} step={0.1} unit="rad" onChange={setPhase} />
        <Note>مدل دوگانهٔ «جمع» است (دوگانه‌گذاری نابرجاست با k(r₁−r₂)+Δφ). گرادیان دامنه با 1/√r مدل‌سازی شده تا لبه‌ها خوانا بمانند. تداخل صرفاً از اصل برهم‌نهیِ موج ناشی می‌شود.</Note>
      </Controls>
    </Panel>
  );
}

/* ==================== 5. Lorentz force (cyclotron) ==================== */

export function LorentzExp() {
  const [q, setQ] = useState(1);
  const [m, setM] = useState(1);
  const [v0, setV0] = useState(2);
  const [B, setB] = useState(1.5);
  const [running, setRunning] = useState(true);
  const { ref, draw } = useCanvas2D();
  const st = useRef({ th: 0 });

  const wC = Math.abs(q * B) / m; // rad/s magnitude
  const radius = (m * v0) / Math.abs(q * B);
  const T = (2 * Math.PI) / Math.max(1e-9, wC);

  useLoop((dt) => {
    st.current.th += ((q * B) / m) * dt;
    draw((ctx, W, H) => {
      // B field symbols (out of page = dots)
      ctx.fillStyle = "rgba(96,165,250,0.5)";
      for (let i = 0; i < 10; i++) for (let j = 0; j < 7; j++) {
        const px = 30 + (i * (W - 60)) / 9, py = 30 + (j * (H - 60)) / 6;
        ctx.beginPath(); ctx.arc(px, py, 2, 0, Math.PI * 2); ctx.fill();
      }
      const cx = W / 2 - Math.min(radius, 3) * 60 * 0.4 * Math.sign(q * B);
      const cy = H / 2;
      const Rpx = Math.min(radius, 3) * 60 * 0.4;
      // path circle
      ctx.strokeStyle = "rgba(255,255,255,0.35)";
      ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.arc(cx, cy, Rpx, 0, Math.PI * 2); ctx.stroke();
      ctx.setLineDash([]);
      // particle on circle (qB sign flips direction)
      const px = cx + Rpx * Math.cos(st.current.th * 40 / 40);
      const py = cy + Rpx * Math.sin(st.current.th);
      ctx.fillStyle = q > 0 ? "#f87171" : "#60a5fa";
      ctx.beginPath(); ctx.arc(px, py, 8, 0, Math.PI * 2); ctx.fill();
      // velocity tangent arrow
      const vx = -Math.sin(st.current.th), vy = Math.cos(st.current.th);
      ctx.strokeStyle = "#2dd4bf";
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px + vx * 30 * Math.sign(q * B), py + vy * 30 * Math.sign(q * B)); ctx.stroke();
    });
  }, running);

  return (
    <Panel title="معادلات (تحلیلی دقیق)" tex={["\\vec F = q\\,\\vec v \\times \\vec B", "r = \\frac{mv}{|q|B}, \\qquad T = \\frac{2\\pi m}{|q|B}"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <div className="grid grid-cols-3 gap-2 text-center text-xs" dir="ltr">
          <span className="chip justify-center font-mono">r = {radius.toFixed(2)} m</span>
          <span className="chip justify-center font-mono">ω = {wC.toFixed(2)} rad/s</span>
          <span className="chip justify-center font-mono">T = {T.toFixed(2)} s</span>
        </div>
      </div>
      <Controls running={running} onToggle={() => setRunning((r) => !r)} onReset={() => { st.current.th = 0; }}>
        <Slider label="بار q (+/−)" value={q} min={-3} max={3} step={0.5} unit="e" onChange={setQ} />
        <Slider label="جرم m" value={m} min={0.5} max={5} step={0.5} unit="u" onChange={setM} />
        <Slider label="تندایی v⊥" value={v0} min={0.5} max={4} step={0.25} unit="km/s" onChange={setV0} />
        <Slider label="میدان B (خارج از صفحه)" value={B} min={0.5} max={5} step={0.25} unit="mT" onChange={setB} />
        <Note>نیروی لورتس همیشه بر سرعت عمود است → کار صفر و تندایی ثابت؛ نتیجه حرکت دایره‌ای یکنواخت. علامت q جهت چرخش را برعکس می‌کند. این مکانیزم سیکلوترون و کمربندهای وان‌آلن است.</Note>
      </Controls>
    </Panel>
  );
}

/* ==================== 6. Electromagnetic induction ==================== */

export function InductionExp() {
  const [N, setN] = useState(200);
  const [f, setF] = useState(0.8);
  const [amp, setAmp] = useState(2);
  const [running, setRunning] = useState(true);
  const { ref, draw } = useCanvas2D();
  const st = useRef({ t: 0 });
  const hist = useRef<{ phi: number[]; emf: number[] }>({ phi: [], emf: [] });
  const [ro, setRo] = useState({ phi: 0, emf: 0 });

  const A = 6.5e-4; // coil area m² (realistic small coil)
  const B0 = 0.3;   // magnet surface field (T)
  const x0 = 8;     // geometry scale
  const Bof = (x: number) => B0 / (1 + (x / x0) ** 2);

  useLoop((dt) => {
    st.current.t += dt;
    const t = st.current.t;
    const x = 8 + amp * Math.sin(2 * Math.PI * f * t);
    const phi = N * A * Bof(x);
    const h = 0.005;
    const xph = 8 + amp * Math.sin(2 * Math.PI * f * (t + h));
    const xmh = 8 + amp * Math.sin(2 * Math.PI * f * (t - h));
    const emf = -(N * A * (Bof(xph) - Bof(xmh))) / (2 * h);
    hist.current.phi.push(phi);
    hist.current.emf.push(emf);
    if (hist.current.phi.length > 260) { hist.current.phi.shift(); hist.current.emf.shift(); }
    draw((ctx, W, H) => {
      // coil
      const cy = 70;
      const coilX = W / 2 - 120;
      ctx.strokeStyle = "#fbbf24";
      ctx.lineWidth = 2.5;
      for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.ellipse(coilX + i * 8, cy, 9, 34, 0, 0, Math.PI * 2);
        ctx.stroke();
      }
      // magnet
      const mpx = coilX + 110 + (x - 8) * 30;
      ctx.fillStyle = "#f87171";
      ctx.fillRect(mpx - 24, cy - 14, 24, 28);
      ctx.fillStyle = "#60a5fa";
      ctx.fillRect(mpx, cy - 14, 24, 28);
      ctx.fillStyle = "#fff"; ctx.font = "10px sans-serif"; ctx.textAlign = "center";
      ctx.fillText("N", mpx - 12, cy + 3); ctx.fillText("S", mpx + 12, cy + 3);
      // graphs
      const gW = W - 60, gH = 70;
      const plot = (arr: number[], color: string, y0: number, scale: number) => {
        ctx.strokeStyle = color; ctx.lineWidth = 1.8;
        ctx.beginPath();
        arr.forEach((v, i) => {
          const px = 30 + (i / 260) * gW;
          const py = y0 + gH / 2 - v * scale * gH / 2;
          i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
        });
        ctx.stroke();
      };
      ctx.strokeStyle = "rgba(255,255,255,0.2)";
      ctx.beginPath(); ctx.moveTo(30, 150 + gH / 2 - 70); ctx.lineTo(W - 30, 150 + gH / 2 - 70); ctx.stroke();
      const phiMax = Math.max(1e-9, ...hist.current.phi.map(Math.abs));
      const emfMax = Math.max(1e-9, ...hist.current.emf.map(Math.abs));
      plot(hist.current.phi, "#2dd4bf", 140, 0.85 / phiMax);
      plot(hist.current.emf, "#f472b6", 250, 0.85 / emfMax);
    });
    setRo({ phi, emf });
  }, running);

  return (
    <Panel title="قانون فارادی (شار محاسبه‌شده، مشتق عددی)" tex={["\\Phi_B = N B(x) A, \\quad B(x) = \\frac{B_0}{1+(x/x_0)^2}", "\\varepsilon = -\\frac{d\\Phi_B}{dt}"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <div className="grid grid-cols-2 gap-2 text-center text-xs" dir="ltr">
          <span className="chip justify-center font-mono !text-accent">Φ = {(ro.phi * 1000).toFixed(1)} mWb</span>
          <span className="chip justify-center font-mono !text-[#f472b6]">ε = {ro.emf.toFixed(2)} V</span>
        </div>
      </div>
      <Controls running={running} onToggle={() => setRunning((r) => !r)} onReset={() => { st.current.t = 0; hist.current = { phi: [], emf: [] }; }}>
        <Slider label="تعداد دور سیم‌پیچ N" value={N} min={50} max={500} step={25} onChange={setN} />
        <Slider label="بسامد حرکت آهنربا" value={f} min={0.2} max={2} step={0.1} unit="Hz" onChange={setF} />
        <Slider label="دامنهٔ حرکت" value={amp} min={0.5} max={4} step={0.25} unit="cm" onChange={setAmp} />
        <Note>نمودارها: Φ(t) فیروزه‌ای و ε(t) صورتی — توجه کنید ε نودرجه جلوتر از Φ است (مشتق سینوس کسینوس). علامت منفی: اصل لنز (جریان مخالفت می‌کند). هرچه حرکت تندتر یا N بیشتر → ε بزرگ‌تر.</Note>
      </Controls>
    </Panel>
  );
}

/* ==================== 7. Thin lens ray diagram ==================== */

export function LensExp() {
  const [f, setF] = useState(4);
  const [obj, setObj] = useState(8);
  const [hm, setHm] = useState(2);
  const [conv, setConv] = useState(true);
  const { ref, draw } = useCanvas2D();

  const ff = conv ? f : -f;
  const di = 1 / (1 / ff - 1 / obj);
  const mag = -di / obj;

  const redraw = useCallback(() => {
    draw((ctx, W, H) => {
      const axisY = H / 2;
      const cx = W / 2;
      const scale = Math.min((W - 80) / 34, 22);
      const X = (v: number) => cx + v * scale; // cm
      const Y = (v: number) => axisY - v * scale;
      // axis
      ctx.strokeStyle = "rgba(255,255,255,0.3)";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(20, axisY); ctx.lineTo(W - 20, axisY); ctx.stroke();
      // lens
      ctx.strokeStyle = "#60a5fa";
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(cx, axisY - 80); ctx.lineTo(cx, axisY + 80); ctx.stroke();
      ctx.fillStyle = "#60a5fa";
      ctx.beginPath();
      if (conv) { ctx.moveTo(cx, axisY - 80); ctx.lineTo(cx + 8, axisY - 70); ctx.lineTo(cx - 8, axisY - 70); ctx.closePath(); ctx.fill(); }
      else { ctx.moveTo(cx, axisY - 80); ctx.lineTo(cx + 8, axisY - 90); ctx.lineTo(cx - 8, axisY - 90); ctx.closePath(); ctx.fill(); }
      // focal points
      ctx.fillStyle = "#fbbf24";
      for (const s of [-1, 1]) {
        const fx = ff * s;
        ctx.beginPath(); ctx.arc(X(fx), axisY, 4, 0, Math.PI * 2); ctx.fill();
        ctx.font = "10px monospace"; ctx.textAlign = "center";
        ctx.fillText("F", X(fx), axisY + 16);
      }
      // object arrow
      ctx.strokeStyle = "#34d399";
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(X(-obj), axisY); ctx.lineTo(X(-obj), Y(hm)); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(X(-obj), Y(hm)); ctx.lineTo(X(-obj) - 5, axisY - (hm - 0.6) * scale); ctx.lineTo(X(-obj) + 5, axisY - (hm - 0.6) * scale); ctx.closePath();
      ctx.fillStyle = "#34d399"; ctx.fill();
      // rays from object tip
      const tipY = hm;
      // parallel ray → refract through far focal point
      ctx.strokeStyle = "#f472b6";
      ctx.lineWidth = 2;
      ctx.setLineDash([]);
      const ray = (x0: number, y0: number, x1: number, y1: number, dash = false) => {
        if (dash) ctx.setLineDash([4, 4]);
        ctx.beginPath(); ctx.moveTo(X(x0), Y(y0)); ctx.lineTo(X(x1), Y(y1)); ctx.stroke();
        ctx.setLineDash([]);
      };
      // incoming parallel
      ray(-obj, tipY, 0, tipY);
      // after lens: (0,tipY) → toward (ff,0)
      const slopeAfter = (0 - tipY) / ff;
      const xEnd = di > 0 ? Math.min(di + 6, 16) : -16;
      ray(0, tipY, xEnd, tipY + slopeAfter * xEnd);
      if (di < 0) ray(0, tipY, 8, tipY + slopeAfter * 8, true), ray(0, tipY, 16, tipY + slopeAfter * 16, true);
      // central ray straight
      const slopeCenter = tipY / obj;
      const end2 = di > 0 ? Math.min(di + 6, 16) : -16;
      ray(-obj, tipY, end2, tipY + slopeCenter * end2);
      // virtual extensions for virtual image
      if (di < 0) ray(0, 0, Math.min(-di + 4, obj), slopeCenter * Math.min(-di + 4, obj) * 0 + (tipY / obj) * (obj) + slopeCenter * (Math.min(-di + 4, obj) - obj) * 0, true);
      // image arrow
      const imY = tipY + (slopeAfter * di);
      if (di > 0) {
        ctx.strokeStyle = "#f472b6";
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(X(di), axisY); ctx.lineTo(X(di), Y(imY)); ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(X(di), Y(imY));
        ctx.lineTo(X(di) - 5, Y(imY + 0.6));
        ctx.lineTo(X(di) + 5, Y(imY + 0.6) < Y(Math.sign(imY) * (0)) ? Y(imY) + (imY < 0 ? 10 : -10) * 0 : 0);
        ctx.closePath();
        ctx.fillStyle = "#f472b6"; ctx.fill();
      } else {
        ctx.strokeStyle = "rgba(244,114,182,0.7)";
        ctx.lineWidth = 3;
        ctx.setLineDash([4, 4]);
        const imY2 = (tipY / obj) * (obj + (-di));
        const imgY = -mag * 0 - (tipY * (Math.abs(di) / obj));
        ctx.beginPath(); ctx.moveTo(X(di), axisY); ctx.lineTo(X(di), Y(imgY)); ctx.stroke();
        ctx.setLineDash([]);
      }
    });
  }, [draw, ff, obj, hm, di, conv]);

  useEffect(redraw, [redraw]);

  return (
    <Panel title="معادلهٔ عدسی نازک (تحلیلی)" tex={["\\frac{1}{f} = \\frac{1}{d_o} + \\frac{1}{d_i}", "m = -\\frac{d_i}{d_o}"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <div className="grid grid-cols-3 gap-2 text-center text-[11px]" dir="ltr">
          <span className="chip justify-center font-mono">d_i = {di.toFixed(2)} cm {di < 0 ? "(مجازی)" : "(حقیقی)"}</span>
          <span className="chip justify-center font-mono">m = {mag.toFixed(2)}×</span>
          <span className="chip justify-center font-mono">{mag < 0 ? "تصویر وارونه" : "تصویر مستقیم"}</span>
        </div>
      </div>
      <div className="space-y-2.5">
        <div className="flex gap-2">
          <button className={`btn flex-1 !text-xs ${conv ? "!border-accent !text-accent" : ""}`} onClick={() => setConv(true)}>عدسی محدب</button>
          <button className={`btn flex-1 !text-xs ${!conv ? "!border-danger !text-danger" : ""}`} onClick={() => setConv(false)}>عدسی مقعر</button>
        </div>
        <Slider label="فاصلهٔ کانونی |f|" value={f} min={1.5} max={10} step={0.25} unit="cm" onChange={setF} />
        <Slider label="فاصلهٔ جسم d_o" value={obj} min={1} max={16} step={0.25} unit="cm" onChange={setObj} />
        <Slider label="ارتفاع جسم" value={hm} min={0.5} max={3.5} step={0.25} unit="cm" onChange={setHm} />
        <Note>دو پرتو اصلی: موازی محور → از کانون می‌گذرد؛ از مرکز عدسی → بدون انحراف. در do &lt; f (محدب) تصویر مجازی و مستقیم می‌دهد — اصل ذره‌بین. مقعر همیشه تصویر مجازی کوچک‌تر می‌دهد.</Note>
      </div>
    </Panel>
  );
}

/* ==================== 8. Carnot cycle ==================== */

export function CarnotExp() {
  const [TH, setTH] = useState(600);
  const [TC, setTC] = useState(320);
  const [VA, setVA] = useState(1);
  const [VB, setVB] = useState(3);
  const [running, setRunning] = useState(true);
  const { ref, draw } = useCanvas2D();
  const st = useRef({ ph: 0 }); // phase 0..1 around loop

  const nmol = 1, R = 8.314, gam = 1.4;
  const VC = VB * Math.pow(TH / TC, 1 / (gam - 1));
  const VD = VA * Math.pow(TH / TC, 1 / (gam - 1));
  const QH = nmol * R * TH * Math.log(VB / VA);
  // build loop
  const branchIso = (T: number, v0: number, v1: number, n = 60) =>
    Array.from({ length: n + 1 }, (_, i) => { const V = v0 + ((v1 - v0) * i) / n; return [V, (nmol * R * T) / V] as const; });
  const branchAd = (t0: number, t1: number, v0: number, v1: number, n = 60) =>
    Array.from({ length: n + 1 }, (_, i) => {
      const V = v0 + ((v1 - v0) * i) / n;
      return [V, (nmol * R * t0) / Math.pow(V, 1) * Math.pow(v0 / V, gam - 1)] as const;
    });
  const loop = [...branchIso(TH, VA, VB), ...branchAd(TH, TC, VB, VC), ...branchIso(TC, VC, VD), ...branchAd(TC, TH, VD, VA)];
  const W = (() => {
    // work over isotherms (adiabatics net exact: nCvΔT which cancel in loop; compute numeric loop integral)
    let s = 0;
    for (let i = 1; i < loop.length; i++) s += ((loop[i][1] + loop[i - 1][1]) / 2) * (loop[i][0] - loop[i - 1][0]);
    return s;
  })();
  const etaT = 1 - TC / TH;
  const etaM = W / QH;

  const pmin = Math.min(...loop.map((p) => p[1])) * 0.7;
  const pmax = Math.max(...loop.map((p) => p[1])) * 1.06;
  const vmax = VC * 1.05;

  useLoop((dt) => {
    st.current.ph = (st.current.ph + dt * 0.16) % 1;
    const idx = Math.floor(st.current.ph * loop.length) % loop.length;
    const piston = loop[idx];
    draw((ctx, Wd, Hd) => {
      const pad = 44;
      const X = (v: number) => pad + (v / vmax) * (Wd - pad - 20);
      const Y = (p: number) => Hd - pad - ((p - pmin) / (pmax - pmin)) * (Hd - pad * 2);
      // shaded work area
      ctx.fillStyle = "rgba(45,212,191,0.12)";
      ctx.beginPath();
      loop.forEach(([v, p], i) => (i ? ctx.lineTo(X(v), Y(p)) : ctx.moveTo(X(v), Y(p))));
      ctx.closePath(); ctx.fill();
      // loop
      ctx.strokeStyle = "#2dd4bf";
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      loop.forEach(([v, p], i) => (i ? ctx.lineTo(X(v), Y(p)) : ctx.moveTo(X(v), Y(p))));
      ctx.closePath(); ctx.stroke();
      // labels 1..4
      const lbl = [[VA, (nmol * R * TH) / VA], [VB, (nmol * R * TH) / VB], [VC, (nmol * R * TC) / VC], [VD, (nmol * R * TC) / VD]] as const;
      ctx.fillStyle = "#fbbf24";
      ctx.font = "11px monospace";
      lbl.forEach(([v, p], i) => ctx.fillText(String(i + 1), X(v) + 5, Y(p) - 6));
      // current state dot
      ctx.fillStyle = "#f472b6";
      ctx.beginPath(); ctx.arc(X(piston[0]), Y(piston[1]), 6, 0, Math.PI * 2); ctx.fill();
      // axes
      ctx.strokeStyle = "rgba(255,255,255,0.4)";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(pad, Hd - pad); ctx.lineTo(Wd - 20, Hd - pad); ctx.moveTo(pad, Hd - pad); ctx.lineTo(pad, 16); ctx.stroke();
      ctx.fillStyle = "#8ea6c8"; ctx.font = "11px monospace";
      ctx.fillText("V (m³)", Wd - 70, Hd - pad + 16);
      ctx.fillText("P (Pa)", pad - 28, 26);
    });
  }, running);


  return (
    <Panel title="چرخهٔ کارنو (۱ مول گاز ایده‌آل، γ=1.4)" tex={["Q_H = nRT_H \\ln\\frac{V_B}{V_A}", "W = \\oint P\\,dV", "\\eta_{max} = 1 - \\frac{T_C}{T_H}"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <div className="grid grid-cols-2 gap-2 text-center text-[11px]" dir="ltr">
          <span className="chip justify-center font-mono">Q_H = {(QH / 1000).toFixed(2)} kJ • W = {(W / 1000).toFixed(2)} kJ</span>
          <span className="chip justify-center font-mono !text-accent">η = {(etaM * 100).toFixed(1)}% ≈ نظری {(etaT * 100).toFixed(1)}%</span>
        </div>
      </div>
      <Controls running={running} onToggle={() => setRunning((r) => !r)} onReset={() => { st.current.ph = 0; }}>
        <Slider label="T_H (گرم)" value={TH} min={400} max={750} step={5} unit="K" onChange={setTH} />
        <Slider label="T_C (سرد)" value={TC} min={250} max={398} step={2} unit="K" onChange={setTC} />
        <Slider label="V_A" value={VA} min={0.5} max={2} step={0.1} unit="m³" onChange={setVA} />
        <Slider label="V_B (انبساط هم‌دما)" value={VB} min={2.2} max={4.5} step={0.1} unit="m³" onChange={setVB} />
        <Note>سطح ناحیهٔ سایه‌دار = کار خالص چرخه. بازدهٔ محاسبه‌شده از شبیه‌سازی با بازدهٔ نظری مطابقت می‌کند — حداکثر بازدهٔ ممکن بین دو دما؛ هیچ ماشین واقعی نمی‌تواند آن را رد کند (قانون دوم).</Note>
      </Controls>
    </Panel>
  );
}

/* ==================== 9. Special relativity: gamma ==================== */

export function RelativityExp() {
  const c = 299792458;
  const [beta, setBeta] = useState(0.86);
  const [running, setRunning] = useState(true);
  const { ref, draw } = useCanvas2D();
  const st = useRef({ t: 0 });

  const gamma = 1 / Math.sqrt(1 - beta * beta);
  const tauMuon = 2.2e-6; // s (proper)
  const distClassic = 0.995 * c * tauMuon;
  const distRel = 0.995 * c * tauMuon / Math.sqrt(1 - 0.995 ** 2);

  useLoop((dt) => {
    st.current.t += dt;
    draw((ctx, W, H) => {
      // two clocks: Earth t vs rocket t/γ (scaled)
      const t = st.current.t;
      const rows: [string, number, string][] = [
        ["ساعت زمینی:  Δt", t % 4, "#60a5fa"],
        ["ساعت راکت (کندتر):  Δt₀ = Δt/γ", (t % 4) / gamma, "#f472b6"],
      ];
      rows.forEach(([label, val, color], i) => {
        const y = 70 + i * 80;
        ctx.fillStyle = "#e6eefb";
        ctx.font = "12px sans-serif";
        ctx.textAlign = "right";
        ctx.fillText(label, W - 30, y - 14);
        ctx.strokeStyle = "rgba(255,255,255,0.25)";
        ctx.strokeRect(30, y, W - 60, 14);
        ctx.fillStyle = color;
        ctx.fillRect(30, y, ((val / 4) % 1) * (W - 60), 14);
      });
      // light clock bounce on moving frame: path grows
      ctx.fillStyle = "#2dd4bf";
      ctx.font = "11px monospace";
      ctx.textAlign = "left";
      ctx.fillText(`γ = ${gamma.toFixed(3)}      v = ${beta}c      L = L₀/γ = ${(1 / gamma).toFixed(3)} L₀`, 30, H - 40);
      // muon strip
      ctx.fillText("مسیر میون (زمین→سطح):", 30, H - 20);
    });
  }, running);

  return (
    <Panel title="نسبیت خاص (تحلیلی دقیق)" tex={["\\gamma = \\frac{1}{\\sqrt{1 - v^2/c^2}}", "\\Delta t = \\gamma\\, \\Delta t_0", "L = L_0/\\gamma"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <div className="grid grid-cols-2 gap-2 text-center text-[11px]" dir="ltr">
          <span className="chip justify-center font-mono">میون با 0.995c کلاسیکی: ≈ {Math.round(distClassic)} m</span>
          <span className="chip justify-center font-mono !text-accent">با اتساع زمان: ≈ {(distRel / 1000).toFixed(1)} km → به زمین می‌رسد ✓</span>
        </div>
      </div>
      <Controls running={running} onToggle={() => setRunning((r) => !r)} onReset={() => { st.current.t = 0; }}>
        <Slider label="v/c (بتا)" value={beta} min={0} max={0.99} step={0.01} onChange={setBeta} />
        <Note>زمان خاص میون‌ها (عمر نیمه‌عمر ≈ ۲٫۲μs) در اتمسفر سنجیده می‌شود ولی دستگاه زمین آن را γ برابر بزرگ‌تر می‌بیند — از نظر میون، اتمسفر منقبض است! هر دو روایت سازگارند.</Note>
      </Controls>
    </Panel>
  );
}

/* ==================== 10. Quantum infinite well ==================== */

export function QuantumWellExp() {
  const [Lnm, setLnm] = useState(2);
  const [n, setN] = useState(2);
  const [shots, setShots] = useState<number[]>([]);
  const { ref, draw } = useCanvas2D();

  const me = 9.109e-31, hbar6 = 6.626e-34, eV = 1.602e-19;
  const E1 = (hbar6 * hbar6) / (8 * me * (Lnm * 1e-9) ** 2) / eV;
  const En = n * n * E1;

  const psi = useCallback((x: number) => Math.sqrt(2) * Math.sin(n * Math.PI * x), [n]); // x∈[0,1]

  const sample = () => {
    // rejection sampling from |ψ|² — Born rule
    let tries = 0;
    while (tries++ < 5000) {
      const x = Math.random();
      const y = Math.random() * 2;
      if (y <= psi(x) ** 2) return x;
    }
    return Math.random();
  };

  useEffect(() => { setShots([]); }, [n, Lnm]);

  const redraw = useCallback(() => {
    draw((ctx, W, H) => {
      const pad = 40, wW = W - pad * 2;
      const X = (x: number) => pad + x * wW;
      // walls
      ctx.strokeStyle = "#f472b6";
      ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(X(0), 20); ctx.lineTo(X(0), H - 120); ctx.moveTo(X(1), 20); ctx.lineTo(X(1), H - 120); ctx.stroke();
      // potential floor
      ctx.strokeStyle = "rgba(255,255,255,0.35)";
      ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.moveTo(X(0), H - 120); ctx.lineTo(X(1), H - 120); ctx.stroke();
      // ψ and |ψ|²
      const midY = H - 160, scY = 70;
      ctx.strokeStyle = "#2dd4bf";
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      for (let i = 0; i <= 400; i++) {
        const x = i / 400;
        const y = midY - psi(x) * scY * 0.5;
        i ? ctx.lineTo(X(x), y) : ctx.moveTo(X(x), y);
      }
      ctx.stroke();
      // |ψ|² filled probability density
      ctx.fillStyle = "rgba(96,165,250,0.35)";
      ctx.beginPath();
      ctx.moveTo(X(0), midY);
      for (let i = 0; i <= 400; i++) {
        const x = i / 400;
        ctx.lineTo(X(x), midY - psi(x) ** 2 * scY * 0.5);
      }
      ctx.lineTo(X(1), midY);
      ctx.closePath();
      ctx.fill();
      // measured dots
      ctx.fillStyle = "#fbbf24";
      shots.forEach((x) => {
        ctx.beginPath(); ctx.arc(X(x), H - 115, 2.4, 0, Math.PI * 2); ctx.fill();
      });
    });
  }, [draw, psi, shots]);

  useEffect(redraw, [redraw]);

  return (
    <Panel title="حل تحلیلی دقیق معادلهٔ شرودینگر (چاه نامتناهی)" tex={["\\psi_n(x) = \\sqrt{\\tfrac{2}{L}}\\sin\\tfrac{n\\pi x}{L}", "E_n = \\frac{n^2 h^2}{8 m_e L^2}"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <div className="grid grid-cols-3 gap-2 text-center text-[11px]" dir="ltr">
          <span className="chip justify-center font-mono">L = {Lnm} nm</span>
          <span className="chip justify-center font-mono">n = {n} ({n - 1} گره)</span>
          <span className="chip justify-center font-mono !text-accent">E_n = {En.toFixed(3)} eV</span>
        </div>
      </div>
      <div className="space-y-2.5">
        <Slider label="پهنای چاه L" value={Lnm} min={0.5} max={4} step={0.1} unit="nm" onChange={setLnm} />
        <Slider label="عدد کوانتومی n" value={n} min={1} max={6} step={1} onChange={(v) => setN(Math.round(v))} />
        <button className="btn btn-primary w-full justify-center !text-xs" onClick={() => setShots((s) => [...s, ...Array.from({ length: 100 }, sample)])}>
          <Zap className="size-3.5" /> ۱۰۰ «اندازه‌گیری مکان» شبیه‌سازی کن
        </button>
        <p className="text-center text-[10px] text-muted" dir="ltr">{shots.length} بار</p>
        <Note>نقاط زرد پای چاه، نتایج شبیه‌سازی‌گیری تصادفی با توزیع |ψ|² (قاعدهٔ بورن)‌اند — هرچه بیشتر شوند، همان ناحیهٔ آبی را می‌سازند. انرژی‌ها دقیق و گسسته‌اند؛ الکترون نمی‌تواند بین آن‌ها باشد.</Note>
      </div>
    </Panel>
  );
}

export const EXPERIMENTS_2 = [
  { id: "incline", fa: "قوانین نیوتن و اصطکاک (سطح شیب‌دار)", en: "Newton + friction", C: InclineExp },
  { id: "double-pendulum", fa: "آونگ دوگانه (آشوب)", en: "Double pendulum", C: DoublePendulumExp },
  { id: "resonance", fa: "نوسان اجباری و رزونانس", en: "Resonance", C: ResonanceExp },
  { id: "interference", fa: "تداخل دو چشمهٔ موج", en: "Interference", C: InterferenceExp },
  { id: "lorentz", fa: "نیروی لورتس و گردش", en: "Lorentz force", C: LorentzExp },
  { id: "induction", fa: "القای الکترومغناطیسی", en: "EM induction", C: InductionExp },
  { id: "lens", fa: "عدسی نازک (نمودار پرتویی)", en: "Thin lens", C: LensExp },
  { id: "carnot", fa: "چرخهٔ ترمودینامیکی کارنو", en: "Carnot cycle", C: CarnotExp },
  { id: "relativity", fa: "نسبیت خاص: γ و اتساع زمان", en: "Relativity", C: RelativityExp },
  { id: "quantum", fa: "چاه پتانسیل کوانتومی", en: "Particle in a box", C: QuantumWellExp },
];
