"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Compass, Download, GraduationCap, Lightbulb, RotateCcw, Save, Trash2, FlaskConical } from "lucide-react";
import { TeX } from "@/components/katex";

/* ------------------------- shared 2D stage ------------------------- */

export interface StageApi {
  ctx: CanvasRenderingContext2D;
  W: number;
  H: number;
  toPx: (x: number, y: number) => readonly [number, number];
  toWorld: (px: number, py: number) => [number, number];
  vp: { cx: number; cy: number; scale: number };
}

const nice = (v: number) => {
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  const r = v / p;
  return (r >= 5 ? 5 : r >= 2 ? 2 : 1) * p;
};
export const numFmt = (x: number) => {
  const ax = Math.abs(x);
  if (ax !== 0 && (ax >= 1e5 || ax < 1e-4)) return x.toExponential(3);
  return String(Math.round(x * 1e5) / 1e5);
};

export function Stage2D({
  onDraw,
  deps,
  height = 400,
  onClickWorld,
  onHoverWorld,
  toolbar,
}: {
  onDraw: (api: StageApi) => void;
  deps: unknown[];
  height?: number;
  onClickWorld?: (x: number, y: number) => void;
  onHoverWorld?: (x: number, y: number) => void;
  toolbar?: React.ReactNode;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [vp, setVp] = useState({ cx: 0, cy: 0, scale: 55 });
  const [cursor, setCursor] = useState<{ x: number; y: number } | null>(null);
  const vpRef = useRef(vp);
  vpRef.current = vp;
  const dragRef = useRef<{ x: number; y: number; cx: number; cy: number } | null>(null);
  const onDrawRef = useRef(onDraw);
  onDrawRef.current = onDraw;

  const repaint = useCallback(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const W = wrap.clientWidth;
    const H = height;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    canvas.style.height = `${H}px`;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const css = getComputedStyle(document.documentElement);
    const colBg = css.getPropertyValue("--surface2").trim() || "#10233e";
    const colLine = css.getPropertyValue("--line").trim() || "#1c3355";
    const colFg = css.getPropertyValue("--fg").trim() || "#e6eefb";
    const colMuted = css.getPropertyValue("--muted").trim() || "#8ea6c8";
    ctx.fillStyle = colBg;
    ctx.fillRect(0, 0, W, H);

    const { cx, cy, scale } = vpRef.current;
    const toPx = (x: number, y: number) => [W / 2 + (x - cx) * scale, H / 2 - (y - cy) * scale] as const;
    const toWorld = (px: number, py: number): [number, number] => [cx + (px - W / 2) / scale, cy - (py - H / 2) / scale];

    // grid + axes
    const step = nice(80 / scale);
    const [x0w, y1w] = toWorld(0, 0);
    const [x1w, y0w] = toWorld(W, H);
    ctx.font = "9px monospace";
    ctx.textAlign = "center";
    for (let gx = Math.ceil(x0w / step) * step; gx <= x1w; gx += step) {
      const [px] = toPx(gx, 0);
      ctx.strokeStyle = colLine;
      ctx.globalAlpha = 0.45;
      ctx.beginPath(); ctx.moveTo(px, 0); ctx.lineTo(px, H); ctx.stroke();
      ctx.globalAlpha = 1;
      if (Math.abs(gx) > 1e-12) {
        ctx.fillStyle = colMuted;
        ctx.fillText(numFmt(gx), px, Math.min(H - 4, Math.max(10, toPx(0, 0)[1] + 12)));
      }
    }
    for (let gy = Math.ceil(y0w / step) * step; gy <= y1w; gy += step) {
      const [, py] = toPx(0, gy);
      ctx.strokeStyle = colLine;
      ctx.globalAlpha = 0.45;
      ctx.beginPath(); ctx.moveTo(0, py); ctx.lineTo(W, py); ctx.stroke();
      ctx.globalAlpha = 1;
      if (Math.abs(gy) > 1e-12) {
        ctx.fillStyle = colMuted;
        ctx.textAlign = "left";
        ctx.fillText(numFmt(gy), Math.min(W - 30, Math.max(4, toPx(0, 0)[0] + 5)), py - 3);
        ctx.textAlign = "center";
      }
    }
    ctx.strokeStyle = colFg;
    ctx.globalAlpha = 0.75;
    ctx.lineWidth = 1.2;
    const [ox, oy] = toPx(0, 0);
    ctx.beginPath(); ctx.moveTo(0, oy); ctx.lineTo(W, oy); ctx.moveTo(ox, 0); ctx.lineTo(ox, H); ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.lineWidth = 1;

    onDrawRef.current({ ctx, W, H, toPx, toWorld, vp: vpRef.current });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [height, ...deps]);

  useEffect(() => {
    repaint();
    const onResize = () => repaint();
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [repaint]);

  useEffect(() => repaint(), [vp, repaint]);

  return (
    <div>
      <div ref={wrapRef} className="card relative overflow-hidden" style={{ cursor: onClickWorld ? "crosshair" : "grab" }}>
        <canvas
          ref={canvasRef}
          onClick={(e) => {
            if (!onClickWorld) return;
            const r = canvasRef.current!.getBoundingClientRect();
            const { cx, cy, scale } = vpRef.current;
            onClickWorld(cx + (e.clientX - r.left - r.width / 2) / scale, cy - (e.clientY - r.top - r.height / 2) / scale);
          }}
          onPointerDown={(e) => {
            (e.target as HTMLElement).setPointerCapture(e.pointerId);
            dragRef.current = { x: e.clientX, y: e.clientY, cx: vpRef.current.cx, cy: vpRef.current.cy };
          }}
          onPointerMove={(e) => {
            const r = canvasRef.current!.getBoundingClientRect();
            const { cx, cy, scale } = vpRef.current;
            const wx = cx + (e.clientX - r.left - r.width / 2) / scale;
            const wy = cy - (e.clientY - r.top - r.height / 2) / scale;
            setCursor({ x: wx, y: wy });
            onHoverWorld?.(wx, wy);
            const d = dragRef.current;
            if (d) setVp({ cx: d.cx - (e.clientX - d.x) / scale, cy: d.cy + (e.clientY - d.y) / scale, scale });
          }}
          onPointerUp={() => { dragRef.current = null; }}
          onPointerLeave={() => { dragRef.current = null; setCursor(null); }}
          onWheel={(e) => {
            const r = canvasRef.current!.getBoundingClientRect();
            const factor = e.deltaY < 0 ? 1.12 : 1 / 1.12;
            const { cx, cy, scale } = vpRef.current;
            const ns = Math.min(1e5, Math.max(0.02, scale * factor));
            const wx = cx + (e.clientX - r.left - r.width / 2) / scale;
            const wy = cy - (e.clientY - r.top - r.height / 2) / scale;
            setVp({ cx: wx - (e.clientX - r.left - r.width / 2) / ns, cy: wy + (e.clientY - r.top - r.height / 2) / ns, scale: ns });
          }}
        />
        <div className="absolute bottom-2 left-2">
          <span className="chip !bg-surface/80 !text-[10px] font-mono" dir="ltr">
            {cursor ? `(${numFmt(cursor.x)}, ${numFmt(cursor.y)})` : "—"}
          </span>
        </div>
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-2">
        <button className="btn !px-2.5 !py-1.5 !text-[11px]" onClick={() => setVp({ cx: 0, cy: 0, scale: 55 })}>
          <RotateCcw className="size-3.5" /> بازنشانی نما
        </button>
        <button
          className="btn !px-2.5 !py-1.5 !text-[11px]"
          onClick={() => {
            const c = canvasRef.current;
            if (!c) return;
            const a = document.createElement("a");
            a.download = "mathverse-2d.png";
            a.href = c.toDataURL("image/png");
            a.click();
          }}
        >
          <Download className="size-3.5" /> خروجی PNG
        </button>
        {toolbar}
        <span className="chip !text-[10px]">کشیدن: پیمایش • چرخ: بزرگ‌نمایی</span>
      </div>
    </div>
  );
}

/* ----------------------- learn / explore modes ---------------------- */

export type Mode = "explore" | "learn";

export function ModeToggle({ mode, onChange }: { mode: Mode; onChange: (m: Mode) => void }) {
  return (
    <div className="flex rounded-xl border border-line bg-surface p-1">
      <button
        onClick={() => onChange("explore")}
        className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs transition-colors ${mode === "explore" ? "bg-accentsoft font-bold text-accent" : "text-muted"}`}
      >
        <FlaskConical className="size-3.5" /> کاوش آزاد
      </button>
      <button
        onClick={() => onChange("learn")}
        className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs transition-colors ${mode === "learn" ? "bg-accentsoft font-bold text-accent" : "text-muted"}`}
      >
        <GraduationCap className="size-3.5" /> حالت آموزشی
      </button>
    </div>
  );
}

export interface Guide {
  intro: string;
  steps?: string[];
  formulas?: string[];
  tryIt?: string[];
}

export function GuidePanel({ guide, mode }: { guide?: Guide; mode: Mode }) {
  if (mode !== "learn" || !guide) return null;
  return (
    <div className="card mt-3 border-accent/30 !bg-accentsoft/25 p-4">
      <h4 className="mb-2 flex items-center gap-1.5 text-xs font-bold text-accent">
        <GraduationCap className="size-4" /> راهنمای آموزشی
      </h4>
      <p className="mb-2 text-xs leading-6">{guide.intro}</p>
      {guide.steps && (
        <ol className="mr-4 list-decimal space-y-1 text-xs leading-6 text-muted">
          {guide.steps.map((s, i) => <li key={i}>{s}</li>)}
        </ol>
      )}
      {guide.formulas && (
        <div className="my-2 space-y-1">
          {guide.formulas.map((f, i) => <TeX key={i} block>{f}</TeX>)}
        </div>
      )}
      {guide.tryIt && (
        <div className="mt-2 flex flex-wrap gap-1.5">
          {guide.tryIt.map((t, i) => (
            <span key={i} className="chip !border-accent/40 !text-accent"><Lightbulb className="size-3" /> {t}</span>
          ))}
        </div>
      )}
    </div>
  );
}

/* --------------------------- scene saver --------------------------- */

interface SavedScene { name: string; at: number; data: unknown }

export function SceneSaver({
  storageKey,
  serialize,
  apply,
}: {
  storageKey: string;
  serialize: () => unknown;
  apply: (data: unknown) => void;
}) {
  const key = `mv-scene-${storageKey}`;
  const [name, setName] = useState("");
  const [scenes, setScenes] = useState<SavedScene[]>([]);

  useEffect(() => {
    try {
      setScenes(JSON.parse(localStorage.getItem(key) ?? "[]"));
    } catch {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  const persist = (list: SavedScene[]) => {
    setScenes(list);
    try { localStorage.setItem(key, JSON.stringify(list)); } catch {}
  };

  return (
    <div className="card p-4">
      <h4 className="mb-2 flex items-center gap-1.5 text-xs font-bold">
        <Save className="size-4 text-accent" /> ذخیره و بازیافت صحنه (محلی)
      </h4>
      <div className="flex gap-2">
        <input className="input flex-1 !py-1.5 !text-xs" placeholder="نام صحنه…" value={name} onChange={(e) => setName(e.target.value)} />
        <button
          className="btn !py-1.5 !text-xs"
          onClick={() => {
            const list = [...scenes, { name: name.trim() || `صحنه ${scenes.length + 1}`, at: Date.now(), data: serialize() }];
            persist(list);
            setName("");
          }}
        >
          <Save className="size-3.5" /> ذخیره
        </button>
      </div>
      {scenes.length > 0 && (
        <ul className="mt-2 space-y-1.5">
          {scenes.map((s, i) => (
            <li key={i} className="flex items-center gap-2 rounded-lg bg-surface2 px-2.5 py-1.5 text-xs">
              <Compass className="size-3.5 text-accent" />
              <span className="flex-1 font-medium">{s.name}</span>
              <span className="text-[10px] text-muted" dir="ltr">{new Date(s.at).toLocaleTimeString("fa-IR")}</span>
              <button className="text-accent hover:underline" onClick={() => apply(s.data)}>بازیافت</button>
              <button className="text-danger hover:underline" onClick={() => persist(scenes.filter((_, j) => j !== i))}>
                <Trash2 className="size-3.5" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
