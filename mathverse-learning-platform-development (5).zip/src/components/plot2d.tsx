"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { create, all } from "mathjs";
import { Eye, EyeOff, Plus, RotateCcw, Download, Trash2, MousePointer2 } from "lucide-react";
import { TeX } from "@/components/katex";

const math = create(all);

export type FnMode = "cart" | "param" | "polar";

export interface PlotFn {
  id: number;
  name: string;
  expr: string;
  expr2: string; // for param: y(t)
  mode: FnMode;
  color: string;
  visible: boolean;
  showDeriv: boolean;
  tmin: number;
  tmax: number;
}

const PALETTE = ["#2dd4bf", "#60a5fa", "#f472b6", "#fbbf24", "#a78bfa", "#34d399"];
const nice = (v: number) => {
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  const r = v / p;
  const s = r >= 5 ? 5 : r >= 2 ? 2 : 1;
  return s * p;
};
const numFmt = (x: number) => {
  const ax = Math.abs(x);
  if (ax !== 0 && (ax >= 1e5 || ax < 1e-4)) return x.toExponential(3);
  return String(Math.round(x * 1e5) / 1e5);
};

interface VP {
  cx: number;
  cy: number;
  scale: number; // px per unit
}

export interface Plot2DScene {
  fns?: PlotFn[];
  vp?: VP;
}

export default function Plot2D({
  initialScene,
  onSceneChange,
}: {
  initialScene?: Plot2DScene;
  onSceneChange?: (scene: { fns: PlotFn[]; vp: VP }) => void;
} = {}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [fns, setFns] = useState<PlotFn[]>(initialScene?.fns ?? [
    { id: 1, name: "f", expr: "x^2 / 4", expr2: "", mode: "cart", color: PALETTE[0], visible: true, showDeriv: false, tmin: 0, tmax: 2 * Math.PI },
    { id: 2, name: "g", expr: "sin(x)", expr2: "", mode: "cart", color: PALETTE[1], visible: true, showDeriv: false, tmin: 0, tmax: 2 * Math.PI },
  ]);
  const [vp, setVp] = useState<VP>(initialScene?.vp ?? { cx: 0, cy: 0, scale: 60 });
  const [cursor, setCursor] = useState<{ x: number; y: number } | null>(null);
  const [tangentFn, setTangentFn] = useState<number | null>(null);
  const [tangentPt, setTangentPt] = useState<number | null>(null);
  const [intA, setIntA] = useState("-1");
  const [intB, setIntB] = useState("2");
  const [integralFn, setIntegralFn] = useState<number | null>(null);
  const tangentRef = useRef<{ fn: number; x0: number } | null>(null);
  const vpRef = useRef(vp);
  vpRef.current = vp;
  const dragRef = useRef<{ x: number; y: number; cx: number; cy: number } | null>(null);

  const compile = useCallback((f: PlotFn) => {
    try {
      const c1 = math.compile(f.expr);
      const c2 = f.mode === "param" ? math.compile(f.expr2 || "0") : null;
      return { c1, c2 };
    } catch {
      return null;
    }
  }, []);

  const evalFn = useCallback(
    (f: PlotFn, t: number): { x: number; y: number } | null => {
      const c = compile(f);
      if (!c) return null;
      try {
        if (f.mode === "cart") {
          const y = c.c1.evaluate({ x: t });
          if (typeof y !== "number" || !isFinite(y)) return null;
          return { x: t, y };
        }
        if (f.mode === "polar") {
          const r = c.c1.evaluate({ t, th: t, theta: t });
          if (typeof r !== "number" || !isFinite(r)) return null;
          return { x: r * Math.cos(t), y: r * Math.sin(t) };
        }
        const x = c.c1.evaluate({ t });
        const y = c.c2!.evaluate({ t });
        if (typeof x !== "number" || typeof y !== "number" || !isFinite(x) || !isFinite(y)) return null;
        return { x, y };
      } catch {
        return null;
      }
    },
    [compile]
  );

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const W = wrap.clientWidth;
    const H = Math.max(380, Math.min(560, window.innerHeight * 0.62));
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    canvas.style.width = `${W}px`;
    canvas.style.height = `${H}px`;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.scale(dpr, dpr);
    const css = getComputedStyle(document.documentElement);
    const colBg = css.getPropertyValue("--surface").trim() || "#0b1a30";
    const colLine = css.getPropertyValue("--line").trim() || "#1c3355";
    const colFg = css.getPropertyValue("--fg").trim() || "#e6eefb";
    const colMuted = css.getPropertyValue("--muted").trim() || "#8ea6c8";
    ctx.fillStyle = colBg;
    ctx.fillRect(0, 0, W, H);

    const { cx, cy, scale } = vpRef.current;
    const toPx = (x: number, y: number) => [W / 2 + (x - cx) * scale, H / 2 - (y - cy) * scale] as const;
    const toW = (px: number, py: number): [number, number] => [cx + (px - W / 2) / scale, cy - (py - H / 2) / scale];

    // grid
    const stepW = nice(80 / scale);
    const [x0w, y1w] = toW(0, 0);
    const [x1w, y0w] = toW(W, H);
    ctx.font = "10px monospace";
    ctx.textAlign = "center";
    for (let gx = Math.ceil(x0w / stepW) * stepW; gx <= x1w; gx += stepW) {
      const [px] = toPx(gx, 0);
      ctx.strokeStyle = colLine;
      ctx.globalAlpha = 0.5;
      ctx.beginPath();
      ctx.moveTo(px, 0);
      ctx.lineTo(px, H);
      ctx.stroke();
      ctx.globalAlpha = 1;
      ctx.fillStyle = colMuted;
      ctx.fillText(numFmt(gx), px, Math.min(H - 4, Math.max(12, toPx(0, 0)[1] + 14)));
    }
    for (let gy = Math.ceil(y0w / stepW) * stepW; gy <= y1w; gy += stepW) {
      const [, py] = toPx(0, gy);
      ctx.strokeStyle = colLine;
      ctx.globalAlpha = 0.5;
      ctx.beginPath();
      ctx.moveTo(0, py);
      ctx.lineTo(W, py);
      ctx.stroke();
      ctx.globalAlpha = 1;
      ctx.fillStyle = colMuted;
      ctx.textAlign = "left";
      ctx.fillText(numFmt(gy), Math.min(W - 34, Math.max(4, toPx(0, 0)[0] + 6)), py - 3);
      ctx.textAlign = "center";
    }
    // axes
    ctx.strokeStyle = colFg;
    ctx.lineWidth = 1.4;
    const [ox, oy] = toPx(0, 0);
    ctx.globalAlpha = 0.85;
    ctx.beginPath();
    ctx.moveTo(0, oy);
    ctx.lineTo(W, oy);
    ctx.moveTo(ox, 0);
    ctx.lineTo(ox, H);
    ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.lineWidth = 1;

    // integral shading
    if (integralFn != null) {
      const f = fns.find((q) => q.id === integralFn);
      const a = parseFloat(intA);
      const b = parseFloat(intB);
      if (f && f.mode === "cart" && f.visible && isFinite(a) && isFinite(b) && a < b) {
        ctx.beginPath();
        let started = false;
        for (let px = 0; px <= W; px++) {
          const [xw] = toW(px, 0);
          if (xw < a || xw > b) continue;
          const p = evalFn(f, xw);
          if (!p) continue;
          const [sx, sy] = toPx(p.x, p.y);
          if (!started) {
            const [, ay] = toPx(a, 0);
            ctx.moveTo(sx, ay);
            started = true;
          }
          ctx.lineTo(sx, sy);
        }
        if (started) {
          const [bx2, ay2] = toPx(b, 0);
          ctx.lineTo(bx2, ay2);
          ctx.closePath();
          ctx.fillStyle = f.color + "33";
          ctx.fill();
        }
      }
    }

    // curves
    for (const f of fns) {
      if (!f.visible) continue;
      const pass = (deriv: boolean) => {
        ctx.strokeStyle = f.color;
        ctx.lineWidth = deriv ? 1.4 : 2.2;
        ctx.setLineDash(deriv ? [5, 4] : []);
        ctx.beginPath();
        let pen = false;
        let prevSy = 0;
        const N = f.mode === "cart" ? W : 1200;
        for (let i = 0; i <= N; i++) {
          let p: { x: number; y: number } | null;
          if (f.mode === "cart") {
            const [xw] = toW(i, 0);
            if (deriv) {
              const h = 1e-4;
              const yp = evalFn(f, xw + h);
              const ym = evalFn(f, xw - h);
              p = yp && ym ? { x: xw, y: (yp.y - ym.y) / (2 * h) } : null;
            } else {
              p = evalFn(f, xw);
            }
          } else {
            const t = f.tmin + ((f.tmax - f.tmin) * i) / N;
            p = evalFn(f, t);
          }
          if (!p) {
            pen = false;
            continue;
          }
          const [sx, sy] = toPx(p.x, p.y);
          if (pen && Math.abs(sy - prevSy) > H * 1.5) {
            pen = false; // discontinuity break
          }
          if (!pen) {
            ctx.moveTo(sx, sy);
            pen = true;
          } else {
            ctx.lineTo(sx, sy);
          }
          prevSy = sy;
        }
        ctx.stroke();
        ctx.setLineDash([]);
      };
      pass(false);
      if (f.showDeriv && f.mode === "cart") pass(true);
    }

    // tangent
    const tg = tangentRef.current;
    if (tg) {
      const f = fns.find((q) => q.id === tg.fn);
      if (f && f.mode === "cart" && f.visible) {
        const p0 = evalFn(f, tg.x0);
        const h = 1e-4;
        const pp = evalFn(f, tg.x0 + h);
        const pm = evalFn(f, tg.x0 - h);
        if (p0 && pp && pm) {
          const m = (pp.y - pm.y) / (2 * h);
          const [xA] = toW(0, 0);
          const [xB] = toW(W, 0);
          ctx.strokeStyle = "#f472b6";
          ctx.lineWidth = 1.6;
          ctx.beginPath();
          const yA = p0.y + m * (xA - tg.x0);
          const yB = p0.y + m * (xB - tg.x0);
          const [ax, ay] = toPx(xA, yA);
          const [bx, by] = toPx(xB, yB);
          ctx.moveTo(ax, ay);
          ctx.lineTo(bx, by);
          ctx.stroke();
          const [px, py] = toPx(tg.x0, p0.y);
          ctx.fillStyle = "#f472b6";
          ctx.beginPath();
          ctx.arc(px, py, 4, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }
    ctx.lineWidth = 1;
  }, [fns, intA, intB, integralFn, evalFn]);

  useEffect(() => {
    draw();
    const onResize = () => draw();
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [draw]);

  useEffect(() => {
    draw();
  }, [vp, draw]);

  // tangent selection click
  const onClick = (e: React.MouseEvent) => {
    if (tangentFn == null) return;
    const rect = canvasRef.current!.getBoundingClientRect();
    const px = e.clientX - rect.left;
    const { cx, scale } = vpRef.current;
    const xw = cx + (px - rect.width / 2) / scale;
    tangentRef.current = { fn: tangentFn, x0: xw };
    setTangentPt(xw);
    draw();
  };

  const tangentValue = (() => {
    const tg = tangentRef.current;
    if (!tg || tangentPt == null) return null;
    const f = fns.find((q) => q.id === tg.fn);
    if (!f) return null;
    const p0 = evalFn(f, tg.x0);
    const h = 1e-4;
    const pp = evalFn(f, tg.x0 + h);
    const pm = evalFn(f, tg.x0 - h);
    if (!p0 || !pp || !pm) return null;
    return { y: p0.y, m: (pp.y - pm.y) / (2 * h) };
  })();

  const integralValue = (() => {
    if (integralFn == null) return null;
    const f = fns.find((q) => q.id === integralFn);
    const a = parseFloat(intA);
    const b = parseFloat(intB);
    if (!f || f.mode !== "cart" || !isFinite(a) || !isFinite(b) || a >= b) return null;
    const n = 1000;
    const h = (b - a) / n;
    let s = (evalFn(f, a)?.y ?? NaN) + (evalFn(f, b)?.y ?? NaN);
    if (!isFinite(s)) return null;
    for (let i = 1; i < n; i++) {
      const p = evalFn(f, a + i * h);
      if (!p) return null;
      s += p.y * (i % 2 ? 4 : 2);
    }
    return (s * h) / 3;
  })();

  let nextId = useRef(3);
  const addFn = (mode: FnMode) => {
    const id = nextId.current++;
    setFns((f) => [
      ...f,
      {
        id, name: `h${id}`,
        expr: mode === "param" ? "cos(t)" : mode === "polar" ? "1 + cos(t)" : "x*sin(x)",
        expr2: mode === "param" ? "sin(t)" : "",
        mode, color: PALETTE[f.length % PALETTE.length],
        visible: true, showDeriv: false, tmin: 0, tmax: 2 * Math.PI,
      },
    ]);
  };

  // scene publish (for local save/restore) — additive, optional
  useEffect(() => {
    nextId.current = Math.max(0, ...fns.map((f) => f.id)) + 1;
    onSceneChange?.({ fns, vp });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fns, vp]);

  const cssColors = { accent: "#2dd4bf" };

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_320px]">
      <div>
        <div
          ref={wrapRef}
          className="card relative overflow-hidden"
          style={{ cursor: tangentFn ? "crosshair" : "grab" }}
        >
          <canvas
            ref={canvasRef}
            onClick={onClick}
            onPointerDown={(e) => {
              if (tangentFn != null) return;
              (e.target as HTMLElement).setPointerCapture(e.pointerId);
              dragRef.current = { x: e.clientX, y: e.clientY, cx: vpRef.current.cx, cy: vpRef.current.cy };
            }}
            onPointerMove={(e) => {
              const rect = canvasRef.current!.getBoundingClientRect();
              const px = e.clientX - rect.left;
              const py = e.clientY - rect.top;
              const { cx, cy, scale } = vpRef.current;
              setCursor({ x: cx + (px - rect.width / 2) / scale, y: cy - (py - rect.height / 2) / scale });
              const d = dragRef.current;
              if (d) {
                setVp({ cx: d.cx - (e.clientX - d.x) / scale, cy: d.cy + (e.clientY - d.y) / scale, scale });
              }
            }}
            onPointerUp={() => { dragRef.current = null; }}
            onPointerLeave={() => { dragRef.current = null; setCursor(null); }}
            onWheel={(e) => {
              const rect = canvasRef.current!.getBoundingClientRect();
              const factor = e.deltaY < 0 ? 1.12 : 1 / 1.12;
              const { cx, cy, scale } = vpRef.current;
              const ns = Math.min(1e6, Math.max(0.01, scale * factor));
              const px = e.clientX - rect.left;
              const py = e.clientY - rect.top;
              // zoom towards cursor
              const wx = cx + (px - rect.width / 2) / scale;
              const wy = cy - (py - rect.height / 2) / scale;
              setVp({ cx: wx - (px - rect.width / 2) / ns, cy: wy + (py - rect.height / 2) / ns, scale: ns });
            }}
          />
          <div className="absolute bottom-2 left-2 flex gap-2 text-[10px]">
            <span className="chip !bg-surface/80" dir="ltr">
              {cursor ? `(${numFmt(cursor.x)}, ${numFmt(cursor.y)})` : "—"}
            </span>
          </div>
        </div>

        <div className="mt-3 flex flex-wrap gap-2">
          <button className="btn !text-xs" onClick={() => setVp({ cx: 0, cy: 0, scale: 60 })}>
            <RotateCcw className="size-3.5" /> بازنشانی نما
          </button>
          <button
            className="btn !text-xs"
            onClick={() => {
              const c = canvasRef.current;
              if (!c) return;
              const a = document.createElement("a");
              a.download = "mathverse-plot.png";
              a.href = c.toDataURL("image/png");
              a.click();
            }}
          >
            <Download className="size-3.5" /> خروجی PNG
          </button>
          <span className="chip">کشیدن: پیمایش • چرخ: بزرگ‌نمایی</span>
        </div>

        {/* Tangent + integral readout */}
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <div className="card p-3 text-xs leading-6">
            <div className="mb-1 font-bold">خط مماس</div>
            {tangentFn == null ? (
              <p className="text-muted">یک تابع دکارتی را برای مماس انتخاب کنید:</p>
            ) : (
              <p className="text-muted">روی نمودار کلیک کنید تا نقطه‌ی تماس ثبت شود.</p>
            )}
            <div className="mt-1 flex flex-wrap gap-1.5">
              {fns.filter((f) => f.mode === "cart").map((f) => (
                <button key={f.id}
                  className={`chip ${tangentFn === f.id ? "!border-accent !text-accent" : ""}`}
                  onClick={() => { setTangentFn(tangentFn === f.id ? null : f.id); if (tangentFn === f.id) { tangentRef.current = null; setTangentPt(null); draw(); } }}>
                  <MousePointer2 className="size-3" /> {f.name}
                </button>
              ))}
            </div>
            {tangentValue && (
              <div className="mt-2 rounded-lg bg-surface2 p-2" dir="ltr">
                <div>f({numFmt(tangentPt!)}) = {numFmt(tangentValue.y)}</div>
                <div>f′({numFmt(tangentPt!)}) ≈ {numFmt(tangentValue.m)}</div>
                <div dir="ltr">y = {numFmt(tangentValue.y)} + {numFmt(tangentValue.m)}(x − {numFmt(tangentPt!)})</div>
              </div>
            )}
          </div>
          <div className="card p-3 text-xs leading-6">
            <div className="mb-1 font-bold">انتگرال معین (سیمپسون، n=1000)</div>
            <div className="flex flex-wrap items-center gap-1.5">
              <select className="input !w-20 !px-2 !py-1 font-mono" dir="ltr"
                value={integralFn ?? ""} onChange={(e) => setIntegralFn(e.target.value ? Number(e.target.value) : null)}>
                <option value="">تابع</option>
                {fns.filter((f) => f.mode === "cart").map((f) => (
                  <option key={f.id} value={f.id}>{f.name}</option>
                ))}
              </select>
              <input className="input !w-16 !px-2 !py-1 font-mono" dir="ltr" value={intA} onChange={(e) => setIntA(e.target.value)} placeholder="a" />
              <input className="input !w-16 !px-2 !py-1 font-mono" dir="ltr" value={intB} onChange={(e) => setIntB(e.target.value)} placeholder="b" />
            </div>
            {integralValue != null && (
              <div className="mt-2 rounded-lg bg-surface2 p-2 font-mono" dir="ltr">
                ∫ ≈ {numFmt(integralValue)}
              </div>
            )}
            <p className="mt-1 text-[10px] text-muted">مساحت علامت‌دار؛ ناحیه زیر محور منفی است.</p>
          </div>
        </div>
      </div>

      {/* Function list */}
      <aside className="space-y-3">
        <div className="card p-4">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-sm font-bold">توابع</h3>
            <div className="flex gap-1">
              <button className="btn !px-2 !py-1 !text-[10px]" onClick={() => addFn("cart")}><Plus className="size-3" /> دکارتی</button>
              <button className="btn !px-2 !py-1 !text-[10px]" onClick={() => addFn("param")}><Plus className="size-3" /> پارامتری</button>
              <button className="btn !px-2 !py-1 !text-[10px]" onClick={() => addFn("polar")}><Plus className="size-3" /> قطبی</button>
            </div>
          </div>
          <div className="space-y-3">
            {fns.map((f) => (
              <div key={f.id} className="rounded-xl border border-line bg-surface2 p-3">
                <div className="mb-2 flex items-center gap-2">
                  <input type="color" value={f.color} className="size-6 cursor-pointer rounded border-0 bg-transparent"
                    onChange={(e) => setFns((s) => s.map((q) => q.id === f.id ? { ...q, color: e.target.value } : q))} />
                  <input value={f.name} className="input !w-12 !px-1.5 !py-0.5 text-center font-mono text-xs" dir="ltr"
                    onChange={(e) => setFns((s) => s.map((q) => q.id === f.id ? { ...q, name: e.target.value } : q))} />
                  <span className="chip !text-[9px]">{f.mode === "cart" ? "y=f(x)" : f.mode === "param" ? "پارامتری" : "r(θ)"}</span>
                  <div className="mr-auto flex gap-1">
                    {f.mode === "cart" && (
                      <button className={`btn !px-1.5 !py-0.5 !text-[10px] ${f.showDeriv ? "!border-warn !text-warn" : ""}`}
                        title="نمایش مشتق عددی"
                        onClick={() => setFns((s) => s.map((q) => q.id === f.id ? { ...q, showDeriv: !q.showDeriv } : q))}>
                        f′
                      </button>
                    )}
                    <button className="btn !px-1.5 !py-0.5" onClick={() => { setFns((s) => s.map((q) => q.id === f.id ? { ...q, visible: !q.visible } : q)); }}>
                      {f.visible ? <Eye className="size-3.5" /> : <EyeOff className="size-3.5" />}
                    </button>
                    <button className="btn !px-1.5 !py-0.5 hover:!border-danger hover:!text-danger"
                      onClick={() => setFns((s) => s.filter((q) => q.id !== f.id))}>
                      <Trash2 className="size-3.5" />
                    </button>
                  </div>
                </div>
                <div className="flex gap-1.5" dir="ltr">
                  <input className="input flex-1 !px-2 !py-1 font-mono text-xs" value={f.expr}
                    placeholder={f.mode === "param" ? "x(t)" : f.mode === "polar" ? "r(t)" : "y(x)"}
                    onChange={(e) => setFns((s) => s.map((q) => q.id === f.id ? { ...q, expr: e.target.value } : q))} />
                  {f.mode === "param" && (
                    <input className="input flex-1 !px-2 !py-1 font-mono text-xs" value={f.expr2}
                      placeholder="y(t)"
                      onChange={(e) => setFns((s) => s.map((q) => q.id === f.id ? { ...q, expr2: e.target.value } : q))} />
                  )}
                </div>
                {f.mode !== "cart" && (
                  <div className="mt-1.5 flex items-center gap-1.5 text-[10px] text-muted" dir="ltr">
                    t: <input className="input !w-16 !px-1.5 !py-0.5 font-mono" value={f.tmin} onChange={(e) => setFns((s) => s.map((q) => q.id === f.id ? { ...q, tmin: Number(e.target.value) || 0 } : q))} />
                    → <input className="input !w-16 !px-1.5 !py-0.5 font-mono" value={f.tmax} onChange={(e) => setFns((s) => s.map((q) => q.id === f.id ? { ...q, tmax: Number(e.target.value) || 0 } : q))} />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
        <div className="card p-4 text-xs leading-6 text-muted">
          <strong className="text-fg">نحوه‌ی محاسبات:</strong> عبارت‌ها با math.js تجزیه می‌شوند (متغیر x یا t)؛
          مشتق با تفاضل مرکزی و انتگرال با قاعده‌ی سیمپسون محاسبه می‌شود — هر دو تقریب عددی‌اند و با خط‌چین/سایه
          مشخص می‌شوند. قطع‌گیری ناپیوستگی‌ها (مانند مجانب) خودکار انجام می‌شود.
          <div className="mt-2" dir="ltr">
            <TeX>{"f'(x) \\approx \\frac{f(x+h) - f(x-h)}{2h}"}</TeX>
          </div>
        </div>
      </aside>
    </div>
  );
}
