"use client";

import katex from "katex";

/**
 * KaTeX renderer for MATHVERSE.
 * - LTR-isolated math inside RTL Persian text.
 * - throwOnError: false → malformed TeX degrades to KaTeX's red error span,
 *   never breaks the whole lesson.
 * - strict: "warn" in production logs silently ignored warnings; in dev it
 *   surfaces issues via console for authors.
 * - trust defaults to false: no \href URL injection / \htmlClass tricks.
 * - errorCallback route: development logging for content authors.
 */
export function TeX({
  children,
  block = false,
  className = "",
}: {
  children: string;
  block?: boolean;
  className?: string;
}) {
  let html = "";
  const isDev = typeof process !== "undefined" && process.env.NODE_ENV !== "production";
  try {
    html = katex.renderToString(children, {
      displayMode: block,
      throwOnError: false,
      strict: isDev ? "warn" : "ignore",
      errorColor: "#f43f5e",
      output: "html",
    });
  } catch (e) {
    if (isDev) console.error("[MATHVERSE KaTeX] failed:", children, e);
    // graceful: show the raw expression in a monospace sans-serif span
    html = `<code style="color:#f43f5e;font-size:.85em">${children.replace(/</g, "&lt;")}</code>`;
  }
  return (
    <span
      dir="ltr"
      className={`katex-wrap ${block ? "block" : ""} ${className}`}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}
