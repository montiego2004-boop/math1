"use client";

import { useEffect } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  Bookmark,
  BookmarkCheck,
  CheckCircle2,
  Clock3,
  ExternalLink,
  FlaskConical,
  Lightbulb,
  NotebookPen,
  Sparkles,
  Target,
} from "lucide-react";
import type { Lesson } from "@/data/lesson-types";
import { useBookmarks, useNotes, useProgress } from "@/lib/store";
import { TeX } from "@/components/katex";
import { Inline } from "@/components/academy-browser";

export default function LessonView({ lesson }: { lesson: Lesson }) {
  const { progress, visitLesson, toggleLessonComplete } = useProgress();
  const { bookmarks, toggleBookmark } = useBookmarks();
  const { notes, setNote } = useNotes();
  const key = `${lesson.academy}/${lesson.id}`;
  const done = progress.completedLessons.includes(key);
  const saved = bookmarks.includes(key);

  useEffect(() => {
    visitLesson(key);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  return (
    <article className="fade-up">
      <Link
        href={`/academy/${lesson.academy}`}
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted transition-colors hover:text-accent"
      >
        <ArrowLeft className="size-4" /> بازگشت به آکادمی
      </Link>

      <header className="card mb-6 p-6">
        <div className="mb-3 flex flex-wrap items-center gap-2 text-xs">
          <span className="chip !text-accent">{lesson.level}</span>
          <span className="chip">{lesson.subject}</span>
          <span className="chip">
            <Clock3 className="size-3" /> ~{lesson.minutes} دقیقه
          </span>
          <span className="chip" dir="ltr">{lesson.en}</span>
        </div>
        <h1 className="mb-3 text-2xl font-extrabold lg:text-3xl">{lesson.title}</h1>
        <p className="leading-8 text-muted">{lesson.intro}</p>
        <div className="mt-5 flex flex-wrap gap-2">
          <button className={`btn ${done ? "btn-primary" : ""}`} onClick={() => toggleLessonComplete(key)}>
            <CheckCircle2 className="size-4" />
            {done ? "تکمیل شده ✓" : "علامت به‌عنوان تکمیل‌شده"}
          </button>
          <button className="btn" onClick={() => toggleBookmark(key)}>
            {saved ? <BookmarkCheck className="size-4 text-accent" /> : <Bookmark className="size-4" />}
            {saved ? "نشان شده" : "نشانه‌گذاری"}
          </button>
          {lesson.interactive && (
            <Link href={lesson.interactive.href} className="btn !border-accent !text-accent">
              <FlaskConical className="size-4" /> {lesson.interactive.label}
            </Link>
          )}
        </div>
      </header>

      <div className="grid gap-6 lg:grid-cols-[1fr_300px]">
        <div>
          <section className="card mb-6 p-6">
            <h2 className="mb-4 flex items-center gap-2 font-bold">
              <Target className="size-5 text-accent" /> اهداف یادگیری
            </h2>
            <ul className="space-y-2 text-sm leading-7">
              {lesson.objectives.map((o, i) => (
                <li key={i} className="flex gap-2">
                  <span className="mt-2.5 size-1.5 shrink-0 rounded-full bg-accent" />
                  <span>{o}</span>
                </li>
              ))}
            </ul>
            <div className="mt-4 border-t border-line pt-3 text-xs text-muted">
              پیش‌نیازها: {lesson.prerequisites.join("، ")}
            </div>
          </section>

          <section className="card prose-mv p-6">
            {lesson.body.map((b, i) => {
              switch (b.t) {
                case "h":
                  return (
                    <h3 key={i} className="flex items-center gap-2">
                      <span className="h-px w-5 bg-accent" /> {b.s}
                    </h3>
                  );
                case "p":
                  return (
                    <p key={i}>
                      <Inline s={b.s} />
                    </p>
                  );
                case "tex":
                  return <TeX key={i} block>{b.s}</TeX>;
                case "ul":
                  return (
                    <ul key={i}>
                      {b.items.map((it, j) => (
                        <li key={j}>
                          <Inline s={it} />
                        </li>
                      ))}
                    </ul>
                  );
                case "note":
                  return (
                    <div key={i} className="my-4 rounded-xl border border-warn/40 bg-warn/5 p-4 text-sm leading-7">
                      <strong className="mb-1 flex items-center gap-1.5 text-warn">
                        <Lightbulb className="size-4" /> توجه — فرض‌ها و محدودیت‌ها
                      </strong>
                      <Inline s={b.s} />
                    </div>
                  );
                case "definition":
                  return (
                    <div key={i} className="my-4 rounded-xl border border-accent/50 bg-accentsoft/30 p-4">
                      <strong className="mb-1 block text-sm text-accent">تعریف</strong>
                      <p className="text-sm leading-7"><Inline s={b.s} /></p>
                    </div>
                  );
                case "theorem":
                  return (
                    <div key={i} className="my-4 rounded-xl border border-accent2/50 bg-accent2/5 p-4">
                      <strong className="mb-1 block text-sm text-accent2">قضیه / گزاره</strong>
                      <p className="text-sm leading-7"><Inline s={b.s} /></p>
                    </div>
                  );
                case "proof":
                  return (
                    <div key={i} className="my-4 rounded-xl border border-line bg-surface2 p-4">
                      <strong className="mb-1 block text-sm text-muted">اثبات</strong>
                      <p className="text-sm leading-7 text-muted"><Inline s={b.s} /> <span className="text-accent">□</span></p>
                    </div>
                  );
                case "warn":
                  return (
                    <div key={i} className="my-4 rounded-xl border border-danger/50 bg-danger/5 p-4">
                      <strong className="mb-1 block text-sm text-danger">اشتباهات رایج / هشدار دقت</strong>
                      <p className="text-sm leading-7"><Inline s={b.s} /></p>
                    </div>
                  );
                case "summary":
                  return (
                    <div key={i} className="my-4 rounded-xl border border-accent/40 bg-accentsoft/40 p-4">
                      <strong className="mb-1 block text-sm font-bold">خلاصهٔ درس</strong>
                      <p className="text-sm leading-7"><Inline s={b.s} /></p>
                    </div>
                  );
                case "example":
                  return (
                    <div key={i} className="my-4 rounded-xl border border-accent/30 bg-accentsoft/30 p-4">
                      <strong className="mb-2 flex items-center gap-1.5 text-accent">
                        <Sparkles className="size-4" /> مثال: {b.title}
                      </strong>
                      <ol className="space-y-2 text-sm leading-7">
                        {b.steps.map((st, j) => (
                          <li key={j} className="flex items-baseline gap-2">
                            <span className="chip !px-1.5 !text-[10px]">{j + 1}</span>
                            <span className="flex-1">
                              <Inline s={st.text} />
                              {st.tex && <TeX block>{st.tex}</TeX>}
                            </span>
                          </li>
                        ))}
                      </ol>
                    </div>
                  );
              }
            })}
          </section>

          <section className="card mt-6 p-6">
            <h2 className="mb-3 flex items-center gap-2 font-bold">
              <NotebookPen className="size-5 text-accent" /> یادداشت شخصی شما
            </h2>
            <textarea
              className="input min-h-28"
              placeholder="یادداشت شما درباره‌ی این درس — فقط روی همین دستگاه ذخیره می‌شود..."
              value={notes[key] ?? ""}
              onChange={(e) => setNote(key, e.target.value)}
            />
          </section>
        </div>

        <aside className="space-y-4">
          <div className="card p-5">
            <h3 className="mb-3 text-sm font-bold">کاربردهای عملی</h3>
            <ul className="space-y-2 text-sm leading-6 text-muted">
              {lesson.applications.map((a, i) => (
                <li key={i} className="flex gap-2">
                  <span className="mt-2 size-1.5 shrink-0 rounded-full bg-accent2" />
                  {a}
                </li>
              ))}
            </ul>
          </div>
          <div className="card p-5">
            <h3 className="mb-3 text-sm font-bold">درس‌ها و ابزارهای مرتبط</h3>
            <ul className="space-y-1.5 text-sm">
              {lesson.related.map((r, i) => (
                <li key={i}>
                  <Link href={r.href} className="text-muted transition-colors hover:text-accent">
                    ← {r.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div className="card p-5">
            <h3 className="mb-3 text-sm font-bold">مراجع و مطالعه‌ی بیشتر</h3>
            <ul className="space-y-2 text-xs leading-6">
              {lesson.references.map((r, i) => (
                <li key={i}>
                  <a
                    href={r.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-start gap-1.5 text-muted transition-colors hover:text-accent"
                  >
                    <ExternalLink className="mt-0.5 size-3.5 shrink-0" />
                    {r.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </aside>
      </div>
    </article>
  );
}
