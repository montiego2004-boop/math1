"use client";

import { useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, Moon, Sun, X, Sigma } from "lucide-react";
import { SECTIONS } from "@/lib/sections";

export default function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [theme, setTheme] = useState<"dark" | "light">("dark");

  const current = SECTIONS.find((s) =>
    s.href === "/" ? pathname === "/" : pathname.startsWith(s.href)
  );

  useEffect(() => {
    const t = (typeof localStorage !== "undefined" && localStorage.getItem("mv-theme")) || "dark";
    setTheme(t === "light" ? "light" : "dark");
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (typeof navigator !== "undefined" && "serviceWorker" in navigator && process.env.NODE_ENV === "production") {
      // Derive SW path from the manifest link so it also works when the app
      // is served from a sub-path (e.g. GitHub Pages: /mathverse/).
      const manifestHref =
        document.querySelector<HTMLLinkElement>('link[rel="manifest"]')?.getAttribute("href") ??
        "/manifest.webmanifest";
      const swUrl = new URL("sw.js", new URL(manifestHref, window.location.origin)).pathname;
      navigator.serviceWorker.register(swUrl).catch(() => {});
    }
  }, []);

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    document.documentElement.dataset.theme = next;
    try {
      localStorage.setItem("mv-theme", next);
    } catch {}
  };

  return (
    <div className="min-h-screen">
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 right-0 z-50 w-[280px] border-l border-line bg-surface/95 backdrop-blur-xl transition-transform duration-300 lg:translate-x-0 ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex h-full flex-col">
          <Link href="/" className="flex items-center gap-3 border-b border-line px-5 py-5">
            <span className="grid size-11 place-items-center rounded-2xl bg-gradient-to-br from-accent to-accent2 text-white shadow-lg shadow-accent/20">
              <Sigma className="size-6" />
            </span>
            <span>
              <span className="block text-lg font-extrabold tracking-tight">مث‌ورس</span>
              <span className="block text-[11px] font-medium tracking-[0.2em] text-muted" dir="ltr">
                MATHVERSE
              </span>
            </span>
          </Link>
          <nav className="flex-1 overflow-y-auto px-3 py-4">
            {SECTIONS.map((s) => {
              const active = s.href === "/" ? pathname === "/" : pathname.startsWith(s.href);
              return (
                <Link
                  key={s.href}
                  href={s.href}
                  className={`mb-1 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors ${
                    active
                      ? "bg-accentsoft font-bold text-accent"
                      : "text-muted hover:bg-surface2 hover:text-fg"
                  }`}
                >
                  <s.icon className={`size-[18px] shrink-0 ${active ? "text-accent" : ""}`} />
                  <span className="flex-1">{s.fa}</span>
                  {active && <span className="size-1.5 rounded-full bg-accent" />}
                </Link>
              );
            })}
          </nav>
          <div className="border-t border-line px-5 py-4 text-[11px] leading-relaxed text-muted">
            پروژه‌ای آموزشی، آزاد و بدون نیاز به ثبت‌نام.
            <br />
            داده‌های شما فقط روی همین دستگاه ذخیره می‌شود.
          </div>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {open && (
        <button
          aria-label="بستن منو"
          className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      {/* Main */}
      <div className="min-h-screen lg:pr-[280px]">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-line bg-bg/85 px-4 py-3 backdrop-blur-xl lg:px-8">
          <button
            className="btn !px-2.5 lg:hidden"
            onClick={() => setOpen(true)}
            aria-label="باز کردن منو"
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-base font-bold">{current?.fa ?? "مث‌ورس"}</h1>
            <p className="truncate text-[11px] text-muted" dir="ltr">
              {current?.en ?? "MATHVERSE"}
            </p>
          </div>
          <button className="btn !px-2.5" onClick={toggleTheme} aria-label="تغییر پوسته">
            {theme === "dark" ? <Sun className="size-5" /> : <Moon className="size-5" />}
          </button>
        </header>
        <main className="mx-auto w-full max-w-6xl px-4 py-6 lg:px-8 lg:py-10">{children}</main>
      </div>
    </div>
  );
}
