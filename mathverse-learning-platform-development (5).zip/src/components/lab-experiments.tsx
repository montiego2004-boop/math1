"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Pause, Play, RotateCcw, Info } from "lucide-react";
import { TeX } from "@/components/katex";

export const G = 9.81;

/* RK4 integrator for y' = f(t, y) */
export function rk4(y: number[], f: (t: number, y: number[]) => number[], t: number, dt: number) {
  const k1 = f(t, y);
  const k2 = f(t + dt / 2, y.map((v, i) => v + (dt / 2) * k1[i]));
  const k3 = f(t + dt / 2, y.map((v, i) => v + (dt / 2) * k2[i]));
  const k4 = f(t + dt, y.map((v, i) => v + dt * k3[i]));
  return y.map((v, i) => v + (dt / 6) * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]));
}

export function useLoop(cb: (dt: number) => void, running: boolean) {
  const cbRef = useRef(cb);
  cbRef.current = cb;
  useEffect(() => {
    if (!running) return;
    let raf = 0;
    let last = -1;
    const step = (t: number) => {
      if (last >= 0) cbRef.current(Math.min(0.05, (t - last) / 1000));
      last = t;
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [running]);
}

export function useCanvas2D() {
  const ref = useRef<HTMLCanvasElement>(null);
  const draw = useCallback((fn: (ctx: CanvasRenderingContext2D, W: number, H: number) => void) => {
    const c = ref.current;
    if (!c) return;
    const W = c.clientWidth;
    const H = Math.max(300, Math.min(420, window.innerHeight * 0.5));
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (c.width !== W * dpr || c.height !== H * dpr) {
      c.width = W * dpr;
      c.height = H * dpr;
      c.style.height = `${H}px`;
    }
    const ctx = c.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const bg = getComputedStyle(document.documentElement).getPropertyValue("--surface2").trim() || "#10233e";
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);
    fn(ctx, W, H);
  }, []);
  return { ref, draw };
}

export function Slider({ label, value, min, max, step, unit, onChange }: {
  label: string; value: number; min: number; max: number; step: number; unit?: string;
  onChange: (v: number) => void;
}) {
  return (
    <label className="block text-xs">
      <span className="mb-1 flex justify-between text-muted">
        <span>{label}</span>
        <span dir="ltr" className="font-mono text-fg">{value}{unit ? ` ${unit}` : ""}</span>
      </span>
      <input type="range" min={min} max={max} step={step} value={value} className="w-full"
        onChange={(e) => onChange(Number(e.target.value))} />
    </label>
  );
}

export function Controls({ running, onToggle, onReset, children }: {
  running: boolean; onToggle: () => void; onReset: () => void; children?: React.ReactNode;
}) {
  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <button className="btn btn-primary !text-xs" onClick={onToggle}>
          {running ? <Pause className="size-3.5" /> : <Play className="size-3.5" />}
          {running ? "توقف" : "شروع"}
        </button>
        <button className="btn !text-xs" onClick={onReset}>
          <RotateCcw className="size-3.5" /> بازنشانی
        </button>
      </div>
      <div className="space-y-2.5">{children}</div>
    </div>
  );
}

export function Note({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-warn/40 bg-warn/5 p-3 text-[11px] leading-6">
      <strong className="mb-1 flex items-center gap-1 text-warn"><Info className="size-3.5" /> فرض‌ها و محدودیت مدل</strong>
      {children}
    </div>
  );
}

export function Panel({ title, tex, children }: { title: string; tex?: string[]; children: React.ReactNode }) {
  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_300px]">
      {children}
      <div className="space-y-3">
        {tex && (
          <div className="card p-4">
            <h4 className="mb-2 text-xs font-bold">{title}</h4>
            {tex.map((t, i) => <TeX key={i} block>{t}</TeX>)}
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================ 1. Projectile ============================ */

export function ProjectileExp() {
  const [v0, setV0] = useState(22);
  const [deg, setDeg] = useState(45);
  const [dragC, setDragC] = useState(0);
  const [running, setRunning] = useState(false);
  const { ref, draw } = useCanvas2D();
  const st = useRef({ x: 0, y: 0, vx: 0, vy: 0, t: 0 });
  const trail = useRef<[number, number][]>([]);
  const [readout, setReadout] = useState({ t: 0, x: 0, y: 0, v: 0 });
  const frame = useRef(0);

  const reset = useCallback(() => {
    const th = (deg * Math.PI) / 180;
    st.current = { x: 0, y: 0, vx: v0 * Math.cos(th), vy: v0 * Math.sin(th), t: 0 };
    trail.current = [];
  }, [v0, deg]);
  useEffect(reset, [reset]);

  const deriv = useCallback(
    (_t: number, y: number[]) => {
      const [x, yy, vx, vy] = y;
      const sp = Math.hypot(vx, vy);
      const ax = -dragC * sp * vx;
      const ay = -G - dragC * sp * vy;
      return [vx, vy, ax, ay];
    },
    [dragC]
  );

  useLoop((dt) => {
    const s = st.current;
    let [x, y, vx, vy] = [s.x, s.y, s.vx, s.vy];
    // substep for stability
    const n = 8;
    const h = (dt * 1.6) / n; // slightly sped up for visibility
    let t = s.t;
    for (let i = 0; i < n; i++) {
      [x, y, vx, vy] = rk4([x, y, vx, vy], deriv, t, h);
      t += h;
      if (y < 0) { y = 0; vx = 0; vy = 0; break; }
    }
    st.current = { x, y, vx, vy, t };
    const last = trail.current[trail.current.length - 1];
    if (!last || Math.hypot(last[0] - x, last[1] - y) > 0.15) trail.current.push([x, y]);
    if (y === 0 && s.t > 0) setRunning(false);

    const th = (deg * Math.PI) / 180;
    const R0 = (v0 * v0 * Math.sin(2 * th)) / G;
    const H0 = (v0 * v0 * Math.sin(th) ** 2) / (2 * G);
    draw((ctx, W, H) => {
      const sc = Math.min((W - 30) / Math.max(R0 * 1.15, 8), (H - 50) / Math.max(H0 * 1.3, 5));
      const ox = 20, oy = H - 25;
      const px = (x: number) => ox + x * sc;
      const py = (y: number) => oy - y * sc;
      // ground
      ctx.strokeStyle = "#2dd4bf";
      ctx.beginPath(); ctx.moveTo(0, oy); ctx.lineTo(W, oy); ctx.stroke();
      // analytic ghost path (no drag)
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = "#60a5fa88";
      ctx.beginPath();
      for (let xw = 0; xw <= R0; xw += R0 / 200) {
        const yw = Math.tan(th) * xw - (G * xw * xw) / (2 * v0 * v0 * Math.cos(th) ** 2);
        if (xw === 0) ctx.moveTo(px(xw), py(yw)); else ctx.lineTo(px(xw), py(yw));
      }
      ctx.stroke();
      ctx.setLineDash([]);
      // trail
      ctx.strokeStyle = "#2dd4bf";
      ctx.lineWidth = 2;
      ctx.beginPath();
      trail.current.forEach(([tx, ty], i) => (i ? ctx.lineTo(px(tx), py(ty)) : ctx.moveTo(px(tx), py(ty))));
      ctx.stroke();
      // ball
      ctx.fillStyle = "#f472b6";
      ctx.beginPath(); ctx.arc(px(x), py(y), 6, 0, Math.PI * 2); ctx.fill();
    });
    if (frame.current++ % 6 === 0) setReadout({ t, x, y, v: Math.hypot(vx, vy) });
  }, running);

  return (
    <Panel title="معادلات مدل (بدون مقاومت)" tex={["x(t) = v_0\\cos\\theta\\, t", "y(t) = v_0\\sin\\theta\\, t - \\tfrac{1}{2}gt^2", "R = \\frac{v_0^2 \\sin 2\\theta}{g}"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <div className="grid grid-cols-4 gap-2 text-center text-xs" dir="ltr">
          {(["t = " + readout.t.toFixed(2) + " s", "x = " + readout.x.toFixed(1) + " m", "y = " + readout.y.toFixed(1) + " m", "v = " + readout.v.toFixed(1) + " m/s"]).map((s) => (
            <span key={s} className="chip justify-center font-mono">{s}</span>
          ))}
        </div>
        <p className="text-[11px] text-muted">مسیر آبی خط‌چین: راه‌حل تحلیلی بدون مقاومت. مسیر فیروزه‌ای: شبیه‌سازی عددی (RK4 با مقاومت درصورت فعال بودن).</p>
      </div>
      <Controls running={running} onToggle={() => setRunning((r) => !r)} onReset={() => { reset(); setRunning(false); }}>
        <Slider label="تندایی اولیه v₀" value={v0} min={5} max={45} step={1} unit="m/s" onChange={setV0} />
        <Slider label="زاویه پرتاب θ" value={deg} min={10} max={80} step={1} unit="°" onChange={setDeg} />
        <Slider label="ضریب مقاومت هوا (۰ = خاموش)" value={dragC} min={0} max={0.08} step={0.005} unit="1/m" onChange={setDragC} />
        <Note>بدون مقاومت: جواب تحلیلی دقیق. با مقاومت درجهٔ دو: ادغام عددی RK4 — مدل تقریبی (ضریب کشش ثابت فرض می‌شود) و نه فیزیک کامل ایرودینامیک.</Note>
      </Controls>
    </Panel>
  );
}

/* ============================ 2. Free fall ============================ */

export function FreeFallExp() {
  const [m, setM] = useState(2);
  const [b, setB] = useState(1.5);
  const [running, setRunning] = useState(false);
  const { ref, draw } = useCanvas2D();
  const st = useRef({ t: 0 });
  const [readout, setReadout] = useState({ v1: 0, v2: 0, t: 0 });

  const vt = (m * G) / b; // terminal velocity
  const tau = m / b;

  const reset = useCallback(() => { st.current = { t: 0 }; }, []);
  useEffect(reset, []);

  useLoop((dt) => {
    st.current.t += dt;
    const t = st.current.t;
    const v1 = G * t;
    const v2 = vt * (1 - Math.exp(-t / tau));
    draw((ctx, W, H) => {
      const maxY = H - 40;
      ctx.strokeStyle = "#2dd4bf";
      ctx.beginPath(); ctx.moveTo(20, 15); ctx.lineTo(20, H - 20); ctx.lineTo(W - 20, H - 20); ctx.stroke();
      // v(t) curves up to 6s
      const tv = Math.min(t, 6);
      ctx.strokeStyle = "#60a5fa";
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 0; i <= 100; i++) {
        const tt = (6 * i) / 100;
        if (tt > tv) break;
        const px = 20 + (tt / 6) * (W - 40);
        const pyv = 15 + (1 - Math.min((G * tt) / (vt * 2 + 15), 1)) * maxY;
        i === 0 ? ctx.moveTo(px, pyv) : ctx.lineTo(px, pyv);
      }
      ctx.stroke();
      ctx.strokeStyle = "#f472b6";
      ctx.beginPath();
      for (let i = 0; i <= 100; i++) {
        const tt = (6 * i) / 100;
        if (tt > tv) break;
        const px = 20 + (tt / 6) * (W - 40);
        const vv = vt * (1 - Math.exp(-tt / tau));
        const pyv = 15 + (1 - Math.min(vv / (vt * 2 + 15), 1)) * maxY;
        i === 0 ? ctx.moveTo(px, pyv) : ctx.lineTo(px, pyv);
      }
      ctx.stroke();
      // terminal velocity dashed line
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = "#f472b688";
      const pyt = 15 + (1 - Math.min(vt / (vt * 2 + 15), 1)) * maxY;
      ctx.beginPath(); ctx.moveTo(20, pyt); ctx.lineTo(W - 20, pyt); ctx.stroke();
      ctx.setLineDash([]);
    });
    setReadout({ v1, v2, t });
  }, running);

  return (
    <Panel title="معادلات مدل" tex={["\\text{بدون مقاومت: } v = gt", "\\text{مقاومت خطی: } m\\dot v = mg - bv", "v(t) = v_t(1 - e^{-t/\\tau}), \\;\\; v_t = \\frac{mg}{b}, \\;\\; \\tau = \\frac{m}{b}"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <div className="grid grid-cols-3 gap-2 text-center text-xs" dir="ltr">
          <span className="chip justify-center font-mono">t = {readout.t.toFixed(2)} s</span>
          <span className="chip justify-center font-mono !text-[#60a5fa]">بدون مقاومت: {readout.v1.toFixed(1)} m/s</span>
          <span className="chip justify-center font-mono !text-[#f472b6]">با مقاومت: {readout.v2.toFixed(1)} m/s</span>
        </div>
      </div>
      <Controls running={running} onToggle={() => setRunning((r) => !r)} onReset={() => { reset(); setRunning(false); }}>
        <Slider label="جرم m" value={m} min={0.5} max={10} step={0.5} unit="kg" onChange={setM} />
        <Slider label="ضریب مقاومت b" value={b} min={0.5} max={5} step={0.25} unit="kg/s" onChange={setB} />
        <Note>نمودار v–t برای ۶ ثانیه‌ی اول. مقاومت خطی (Stokes) برای ذرات کوچک معتبر است؛ سرعت‌های بالا معمولاً مقاومت درجهٔ دو دارند. راه‌حل تحلیلی دقیق است.</Note>
      </Controls>
    </Panel>
  );
}

/* ============================ 3. Pendulum ============================ */

export function PendulumExp() {
  const [L, setL] = useState(1.5);
  const [deg0, setDeg0] = useState(25);
  const [damp, setDamp] = useState(0);
  const [running, setRunning] = useState(false);
  const { ref, draw } = useCanvas2D();
  const st = useRef({ th: 0.4, w: 0, t: 0 });
  const crossRef = useRef<{ lastTh: number; crossings: number[] }>({ lastTh: 0.4, crossings: [] });
  const [readout, setReadout] = useState({ th: 0, w: 0, t: 0, tNum: 0 });

  const tLin = 2 * Math.PI * Math.sqrt(L / G);

  const reset = useCallback(() => {
    st.current = { th: (deg0 * Math.PI) / 180, w: 0, t: 0 };
    crossRef.current = { lastTh: (deg0 * Math.PI) / 180, crossings: [] };
  }, [deg0]);
  useEffect(reset, [reset]);

  const deriv = useCallback((_t: number, y: number[]) => [y[1], -(G / L) * Math.sin(y[0]) - damp * y[1]], [L, damp]);

  useLoop((dt) => {
    const s = st.current;
    let th = s.th, w = s.w, t = s.t;
    const n = 6, h = dt / n;
    for (let i = 0; i < n; i++) {
      [th, w] = rk4([th, w], deriv, t, h);
      t += h;
      if (crossRef.current.lastTh < 0 && th >= 0 && w > 0) {
        crossRef.current.crossings.push(t);
        if (crossRef.current.crossings.length > 3) crossRef.current.crossings.shift();
      }
      crossRef.current.lastTh = th;
    }
    st.current = { th, w, t };
    const cs = crossRef.current.crossings;
    const tNum = cs.length >= 2 ? cs[cs.length - 1] - cs[cs.length - 2] : 0;
    draw((ctx, W, H) => {
      const cx = W / 2, cy = 30;
      const sc = Math.min((H - 80) / L, 300);
      const bx = cx + Math.sin(th) * L * sc;
      const by = cy + Math.cos(th) * L * sc;
      const maxA = Math.PI / 3;
      // arc guide
      ctx.strokeStyle = "#60a5fa55";
      ctx.beginPath(); ctx.arc(cx, cy, L * sc, Math.PI / 2 - maxA, Math.PI / 2 + maxA); ctx.stroke();
      ctx.strokeStyle = "#8ea6c8";
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(bx, by); ctx.stroke();
      ctx.fillStyle = "#f472b6";
      ctx.beginPath(); ctx.arc(bx, by, 11, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#2dd4bf";
      ctx.beginPath(); ctx.arc(cx, cy, 4, 0, Math.PI * 2); ctx.fill();
    });
    setReadout({ th: (th * 180) / Math.PI, w, t, tNum });
  }, running);

  return (
    <Panel title="معادلات مدل" tex={["\\frac{d^2\\theta}{dt^2} = -\\frac{g}{L}\\sin\\theta - \\gamma\\,\\dot\\theta", "T_{\\text{خطی}} = 2\\pi\\sqrt{\\frac{L}{g}}"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <div className="grid grid-cols-3 gap-2 text-center text-xs" dir="ltr">
          <span className="chip justify-center font-mono">θ = {readout.th.toFixed(1)}°</span>
          <span className="chip justify-center font-mono">T (اندازه‌گیری) = {readout.tNum ? readout.tNum.toFixed(3) : "—"} s</span>
          <span className="chip justify-center font-mono !text-accent">T (زاویه کوچک) = {tLin.toFixed(3)} s</span>
        </div>
      </div>
      <Controls running={running} onToggle={() => setRunning((r) => !r)} onReset={() => { reset(); setRunning(false); }}>
        <Slider label="طول L" value={L} min={0.5} max={3} step={0.1} unit="m" onChange={setL} />
        <Slider label="زاویه اولیه θ₀" value={deg0} min={5} max={80} step={1} unit="°" onChange={setDeg0} />
        <Slider label="میرایی γ" value={damp} min={0} max={1} step={0.05} unit="1/s" onChange={setDamp} />
        <Note>معادلهٔ کامل غیرخطی با sinθ حل می‌شود (RK4). با افزایش θ₀ می‌بینید دورهٔ اندازه‌گیری‌شده از T=2π√(L/g) بزرگ‌تر می‌شود — تقریب زاویهٔ کوچک فقط برای θ≲۱۰° دقیق است.</Note>
      </Controls>
    </Panel>
  );
}

/* ============================ 4. Spring-mass ============================ */

export function SpringExp() {
  const [m, setM] = useState(1);
  const [k, setK] = useState(60);
  const [c, setC] = useState(0.2);
  const [x0, setX0] = useState(0.6);
  const [running, setRunning] = useState(false);
  const { ref, draw } = useCanvas2D();
  const st = useRef({ x: 0.6, v: 0, t: 0 });
  const [readout, setReadout] = useState({ x: 0, v: 0, E: 0, K: 0, U: 0 });

  const omega = Math.sqrt(k / m);
  const T = (2 * Math.PI) / omega;
  const reset = useCallback(() => { st.current = { x: x0, v: 0, t: 0 }; }, [x0]);
  useEffect(reset, [reset]);

  const deriv = useCallback((_t: number, y: number[]) => [y[1], -(k / m) * y[0] - (c / m) * y[1]], [k, m, c]);

  useLoop((dt) => {
    const s = st.current;
    let x = s.x, v = s.v, t = s.t;
    const n = 6, h = dt / n;
    for (let i = 0; i < n; i++) { [x, v] = rk4([x, v], deriv, t, h); t += h; }
    st.current = { x, v, t };
    const K = 0.5 * m * v * v, U = 0.5 * k * x * x;
    draw((ctx, W, H) => {
      const cy = H / 2;
      const wallX = 40;
      const eqX = W * 0.45;
      const mx = eqX + x * 140;
      // spring zigzag
      ctx.strokeStyle = "#2dd4bf";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(wallX, cy);
      const coils = 12;
      for (let i = 1; i <= coils; i++) {
        const sx = wallX + ((mx - 20 - wallX) * i) / coils;
        ctx.lineTo(sx, cy + (i % 2 ? 14 : -14));
      }
      ctx.lineTo(mx - 20, cy);
      ctx.stroke();
      // wall
      ctx.fillStyle = "#8ea6c8";
      ctx.fillRect(wallX - 10, cy - 40, 10, 80);
      // mass
      ctx.fillStyle = "#f472b6";
      ctx.fillRect(mx - 20, cy - 22, 40, 44);
      // energy bars
      const E0 = 0.5 * k * x0 * x0;
      const barW = 26;
      const bh = (val: number) => Math.min(1, val / E0) * (H - 90);
      const bx = W - 130;
      const base = H - 30;
      const bars = [[K, "#60a5fa", "K"], [U, "#f472b6", "U"], [K + U, "#2dd4bf", "E"]] as const;
      bars.forEach(([val, col], i) => {
        ctx.fillStyle = col;
        const hgt = bh(val as number);
        ctx.fillRect(bx + i * (barW + 12), base - hgt, barW, hgt);
      });
    });
    setReadout({ x, v, E: K + U, K, U });
  }, running);

  return (
    <Panel title="معادلات مدل" tex={["m\\ddot x + c\\dot x + kx = 0", "\\omega = \\sqrt{k/m}, \\qquad T = 2\\pi\\sqrt{m/k}", "E = \\tfrac12 mv^2 + \\tfrac12 kx^2"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <div className="grid grid-cols-4 gap-2 text-center text-[11px]" dir="ltr">
          <span className="chip justify-center font-mono">x = {readout.x.toFixed(2)} m</span>
          <span className="chip justify-center font-mono">T = {T.toFixed(2)} s</span>
          <span className="chip justify-center font-mono !text-[#60a5fa]">K = {readout.K.toFixed(2)} J</span>
          <span className="chip justify-center font-mono !text-accent">E = {readout.E.toFixed(2)} J</span>
        </div>
      </div>
      <Controls running={running} onToggle={() => setRunning((r) => !r)} onReset={() => { reset(); setRunning(false); }}>
        <Slider label="جرم m" value={m} min={0.2} max={4} step={0.1} unit="kg" onChange={setM} />
        <Slider label="ثابت فنر k" value={k} min={10} max={200} step={5} unit="N/m" onChange={setK} />
        <Slider label="میرایی c" value={c} min={0} max={4} step={0.1} unit="kg/s" onChange={setC} />
        <Slider label="کشش اولیه x₀" value={x0} min={0.1} max={1} step={0.05} unit="m" onChange={setX0} />
        <Note>ستون‌های انرژی (راست): ژنبشی K (آبی)، پتانسیل U (صورتی)، کل E (فیروزه‌ای). با c=0 انرژی پایسته می‌ماند؛ با میرایی، E به گرما تبدیل می‌شود (کاهش E عمدی و واقعی است، نه خطای عددی).</Note>
      </Controls>
    </Panel>
  );
}

/* ============================ 5. Collision ============================ */

export function CollisionExp() {
  const [m1, setM1] = useState(2);
  const [m2, setM2] = useState(1);
  const [v1, setV1] = useState(3);
  const [v2, setV2] = useState(0);
  const [running, setRunning] = useState(false);
  const { ref, draw } = useCanvas2D();
  const st = useRef({ x1: 0, x2: 0, t: 0, collided: false });
  const [phase, setPhase] = useState<"pre" | "post">("pre");

  const v1p = ((m1 - m2) * v1 + 2 * m2 * v2) / (m1 + m2);
  const v2p = ((m2 - m1) * v2 + 2 * m1 * v1) / (m1 + m2);
  const p0 = m1 * v1 + m2 * v2;
  const K0 = 0.5 * m1 * v1 * v1 + 0.5 * m2 * v2 * v2;
  const K1 = 0.5 * m1 * v1p * v1p + 0.5 * m2 * v2p * v2p;

  const reset = useCallback(() => { st.current = { x1: 0, x2: 5, t: 0, collided: false }; setPhase("pre"); }, []);
  useEffect(reset, [reset]);

  useLoop((dt) => {
    const s = st.current;
    const sp = dt * 1.4;
    if (!s.collided) {
      s.x1 += v1 * sp;
      s.x2 += v2 * sp;
      if (s.x1 + 0.5 >= s.x2 - 0.5 && v1 > v2) {
        s.x1 = s.x2 - 1;
        s.collided = true;
        setPhase("post");
      }
    } else {
      s.x1 += v1p * sp;
      s.x2 += v2p * sp;
    }
    s.t += sp;
    draw((ctx, W, H) => {
      const cy = H / 2;
      ctx.strokeStyle = "#2dd4bf";
      ctx.beginPath(); ctx.moveTo(20, cy + 30); ctx.lineTo(W - 20, cy + 30); ctx.stroke();
      const px = (x: number) => 30 + ((x % 10) / 10) * (W - 60);
      ctx.fillStyle = "#60a5fa";
      ctx.fillRect(px(s.x1) - 20, cy - 10, 40, 40);
      ctx.fillStyle = "#f472b6";
      ctx.fillRect(px(s.x2) - 20, cy - 10, 40, 40);
      ctx.fillStyle = "#8ea6c8";
      ctx.font = "11px monospace";
      ctx.fillText("m1", px(s.x1) - 8, cy + 46);
      ctx.fillText("m2", px(s.x2) - 8, cy + 46);
    });
  }, running);

  return (
    <Panel title="قوانین حاکم (کشسان)" tex={["p = \\sum m_i v_i \\; \\text{پایسته}", "K = \\sum \\tfrac12 m_i v_i^2 \\; \\text{پایسته}", "v_1' = \\tfrac{m_1-m_2}{m_1+m_2}v_1 + \\tfrac{2m_2}{m_1+m_2}v_2"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <div className="grid grid-cols-2 gap-2 text-xs" dir="ltr">
          <div className="rounded-lg bg-surface2 p-2 font-mono">
            <div className="mb-1 text-muted">قبل:</div>
            <div>p = {p0.toFixed(2)} kg·m/s</div>
            <div>K = {K0.toFixed(2)} J</div>
          </div>
          <div className="rounded-lg bg-surface2 p-2 font-mono">
            <div className="mb-1 text-muted">بعد (تحلیلی):</div>
            <div>v₁ᵖ = {v1p.toFixed(2)}, v₂ᵖ = {v2p.toFixed(2)} m/s</div>
            <div>K = {K1.toFixed(2)} J {Math.abs(K1 - K0) < 1e-9 ? "✓" : ""}</div>
          </div>
        </div>
      </div>
      <Controls running={running} onToggle={() => setRunning((r) => !r)} onReset={() => { reset(); setRunning(false); }}>
        <Slider label="m₁" value={m1} min={0.5} max={5} step={0.5} unit="kg" onChange={setM1} />
        <Slider label="v₁" value={v1} min={0} max={6} step={0.5} unit="m/s" onChange={(v) => { setV1(v); reset(); }} />
        <Slider label="m₂" value={m2} min={0.5} max={5} step={0.5} unit="kg" onChange={setM2} />
        <Slider label="v₂" value={v2} min={-3} max={3} step={0.5} unit="m/s" onChange={(v) => { setV2(v); reset(); }} />
        <Note>سرعت‌های پس از برخورد از حل تحلیلی پایستگی تکانه و انرژی محاسبه می‌شود (نه تقریب عددی). وضعیت فعلی: {phase === "pre" ? "پیش از برخورد" : "پس از برخورد"}.</Note>
      </Controls>
    </Panel>
  );
}

/* ============================ 6. Waves ============================ */

export function WaveExp() {
  const [A, setA] = useState(1);
  const [n, setN] = useState(2);
  const [f, setF] = useState(1);
  const [mode, setMode] = useState<"standing" | "travel">("standing");
  const [running, setRunning] = useState(true);
  const { ref, draw } = useCanvas2D();
  const st = useRef({ t: 0 });

  const Ls = 10; // string length (m, fictional scale)
  const lam = mode === "standing" ? (2 * Ls) / n : Ls / 2;
  const v = f * lam;

  useLoop((dt) => {
    st.current.t += dt;
    const t = st.current.t;
    const w = 2 * Math.PI * f;
    const k = (2 * Math.PI) / lam;
    draw((ctx, W, H) => {
      const cy = H / 2;
      ctx.strokeStyle = "#2dd4bf";
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      for (let i = 0; i <= 300; i++) {
        const x = (i / 300) * Ls;
        const y = mode === "standing" ? A * Math.sin(n * Math.PI * (x / Ls)) * Math.cos(w * t) : A * Math.sin(k * x - w * t);
        const px = 30 + (i / 300) * (W - 60);
        const py = cy + y * (H / 2 - 40);
        i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
      }
      ctx.stroke();
      if (mode === "standing") {
        ctx.fillStyle = "#f472b6";
        for (let i = 0; i <= n; i++) {
          const px = 30 + (i / n) * (W - 60);
          ctx.beginPath(); ctx.arc(px, cy, 4, 0, Math.PI * 2); ctx.fill();
        }
      }
    });
  }, running);

  return (
    <Panel title="معادلات مدل" tex={mode === "standing"
      ? ["y = 2A\\sin(kx)\\cos(\\omega t)", "\\lambda_n = \\frac{2L}{n}", "v = f\\lambda"]
      : ["y(x,t) = A\\sin(kx - \\omega t)", "k = \\tfrac{2\\pi}{\\lambda}, \\quad \\omega = 2\\pi f"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full" />
        <div className="grid grid-cols-3 gap-2 text-center text-xs" dir="ltr">
          <span className="chip justify-center font-mono">λ = {lam.toFixed(2)} m</span>
          <span className="chip justify-center font-mono">f = {f.toFixed(1)} Hz</span>
          <span className="chip justify-center font-mono">v = {v.toFixed(2)} m/s</span>
        </div>
      </div>
      <Controls running={running} onToggle={() => setRunning((r) => !r)} onReset={() => { st.current.t = 0; }}>
        <div className="flex gap-2">
          <button className={`btn flex-1 !text-xs ${mode === "standing" ? "!border-accent !text-accent" : ""}`} onClick={() => setMode("standing")}>موج ایستاده</button>
          <button className={`btn flex-1 !text-xs ${mode === "travel" ? "!border-accent !text-accent" : ""}`} onClick={() => setMode("travel")}>موج پیش‌رونده</button>
        </div>
        <Slider label="دامنه A" value={A} min={0.2} max={1} step={0.05} unit="" onChange={setA} />
        {mode === "standing" && <Slider label="مود n" value={n} min={1} max={6} step={1} onChange={(v) => setN(Math.round(v))} />}
        <Slider label="بسامد f" value={f} min={0.2} max={3} step={0.1} unit="Hz" onChange={setF} />
        <Note>نقاط صورتی «گره» هستند: همیشه ساکن‌اند. موج ایستاده برهم‌نهی دو موج پیش‌روندهٔ مخالف است؛ در طناب واقعی بسامدها گسسته‌اند چون دو انتهای طناب ثابت‌اند (شرط مرزی).</Note>
      </Controls>
    </Panel>
  );
}

/* ============================ 7. Electric field ============================ */

interface Charge { x: number; y: number; q: number; }

export function EFieldExp() {
  const { ref, draw } = useCanvas2D();
  const [charges, setCharges] = useState<Charge[]>([
    { x: -0.3, y: 0, q: 1 },
    { x: 0.3, y: 0, q: -1 },
  ]);
  const drag = useRef<number | null>(null);
  const [probe, setProbe] = useState<{ ex: number; ey: number; em: number } | null>(null);
  const chargesRef = useRef(charges);
  chargesRef.current = charges;

  const fieldAt = useCallback((nx: number, ny: number) => {
    let ex = 0, ey = 0;
    for (const c of chargesRef.current) {
      const dx = nx - c.x, dy = ny - c.y;
      const r2 = dx * dx + dy * dy + 0.002;
      const r3 = Math.pow(r2, 1.5);
      ex += (8.988 * c.q * dx) / r3;
      ey += (8.988 * c.q * dy) / r3;
    }
    return { ex, ey, em: Math.hypot(ex, ey) };
  }, []);

  const redraw = useCallback(() => {
    draw((ctx, W, H) => {
      const nx = 26, ny = 17;
      for (let i = 0; i < nx; i++) {
        for (let j = 0; j < ny; j++) {
          const gx = -1 + (2 * i) / (nx - 1);
          const gy = -1 + (2 * j) / (ny - 1);
          const { ex, ey, em } = fieldAt(gx, gy);
          const ang = Math.atan2(ey, ex);
          const len = Math.min(14, 5 + Math.log10(1 + em) * 6);
          const px = 20 + ((gx + 1) / 2) * (W - 40);
          const py = 20 + ((gy + 1) / 2) * (H - 40);
          const u = Math.min(1, em / 40);
          ctx.strokeStyle = u > 0.66 ? "#f472b6" : u > 0.33 ? "#fbbf24" : "#2dd4bf";
          ctx.lineWidth = 1.4;
          ctx.beginPath();
          ctx.moveTo(px, py);
          ctx.lineTo(px - len * Math.cos(ang), py - len * Math.sin(ang));
          ctx.stroke();
          ctx.beginPath();
          ctx.arc(px, py, 1.4, 0, Math.PI * 2);
          ctx.fillStyle = ctx.strokeStyle;
          ctx.fill();
        }
      }
      for (const c of chargesRef.current) {
        const px = 20 + ((c.x + 1) / 2) * (W - 40);
        const py = 20 + ((c.y + 1) / 2) * (H - 40);
        ctx.beginPath(); ctx.arc(px, py, 11, 0, Math.PI * 2);
        ctx.fillStyle = c.q > 0 ? "#f87171" : "#60a5fa";
        ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.font = "bold 13px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(c.q > 0 ? "+" : "−", px, py);
      }
    });
  }, [draw, fieldAt]);
  useEffect(redraw, [redraw, charges]);

  const toNorm = (e: React.PointerEvent) => {
    const r = (ref.current as HTMLCanvasElement).getBoundingClientRect();
    return [(((e.clientX - r.left - 20) / (r.width - 40)) * 2 - 1), (((e.clientY - r.top - 20) / (r.height - 40)) * 2 - 1)];
  };

  return (
    <Panel title="معادلات مدل" tex={["\\vec{E}(\\vec r) = \\sum_i k\\frac{q_i}{r_i^2}\\,\\hat r_i", "k = 8.988\\times 10^9 \\; \\mathrm{N\\,m^2/C^2}", "\\vec F = q\\vec E"]}>
      <div className="space-y-3">
        <canvas ref={ref} className="card w-full cursor-move" style={{ touchAction: "none" }}
          onPointerDown={(e) => {
            const [gx, gy] = toNorm(e);
            let best = -1, bd = 0.15;
            charges.forEach((c, i) => {
              const d = Math.hypot(c.x - gx, c.y - gy);
              if (d < bd) { bd = d; best = i; }
            });
            if (best >= 0) {
              drag.current = best;
              (e.target as HTMLElement).setPointerCapture(e.pointerId);
            }
          }}
          onPointerMove={(e) => {
            const [gx, gy] = toNorm(e);
            if (drag.current != null) {
              const i = drag.current;
              setCharges((s) => s.map((c, j) => j === i ? { ...c, x: Math.max(-0.98, Math.min(0.98, gx)), y: Math.max(-0.98, Math.min(0.98, gy)) } : c));
            } else if ((e.buttons & 1) === 0) {
              setProbe(fieldAt(gx, gy));
            }
          }}
          onPointerUp={() => { drag.current = null; }}
        />
        <div className="flex flex-wrap items-center gap-2">
          <button className="btn !text-xs" onClick={() => setCharges((c) => [...c, { x: 0, y: 0.5, q: 1 }])}>+ افزودن بار مثبت</button>
          <button className="btn !text-xs" onClick={() => setCharges((c) => [...c, { x: 0, y: -0.5, q: -1 }])}>− افزودن بار منفی</button>
          <button className="btn !text-xs" onClick={() => setCharges((c) => c.slice(0, -1))}>حذف آخرین</button>
          {probe && (
            <span className="chip font-mono" dir="ltr">|E| = {probe.em.toExponential(2)} N/C (نسبی)</span>
          )}
        </div>
      </div>
      <div className="space-y-3">
        <Note>طراحی: بارها را بکشید. فلش‌ها جهت میدان و رنگ‌آمیزی شدت نسبی را نشان می‌دهد (مقیاس لگاریتمی برای خوانایی). میدان دقیقاً از جمع برداری کولن محاسبه می‌شود؛ مقدار مطلق با واحد نسبی نمایش داده می‌شود.</Note>
      </div>
    </Panel>
  );
}

export const EXPERIMENTS = [
  { id: "projectile", fa: "حرکت پرتابه", en: "Projectile", C: ProjectileExp },
  { id: "freefall", fa: "سقوط با مقاومت هوا", en: "Free fall + drag", C: FreeFallExp },
  { id: "pendulum", fa: "آونگ غیرخطی", en: "Nonlinear pendulum", C: PendulumExp },
  { id: "spring", fa: "جرم–فنر و انرژی", en: "Spring–mass", C: SpringExp },
  { id: "collision", fa: "برخورد کشسان", en: "Elastic collision", C: CollisionExp },
  { id: "wave", fa: "امواج ایستاده و پیش‌رونده", en: "Waves", C: WaveExp },
  { id: "efield", fa: "میدان الکتریکی", en: "Electric field", C: EFieldExp },
];
