"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { CheckCircle2, CircleDashed, Clock3, Search } from "lucide-react";
import type { Level } from "@/data/curriculum";
import { ALL_LESSONS } from "@/data/lessons";
import { useProgress } from "@/lib/store";
import { TeX } from "@/components/katex";

export default function AcademyBrowser({
  levels,
  academy,
  academyFa,
}: {
  levels: Level[];
  academy: "math" | "physics";
  academyFa: string;
}) {
  const [active, setActive] = useState(levels[0].id);
  const [q, setQ] = useState("");
  const { progress } = useProgress();
  const level = levels.find((l) => l.id === active) ?? levels[0];

  const filtered = useMemo(() => {
    if (!q.trim()) return level.subjects;
    const needle = q.trim();
    return level.subjects
      .map((s) => ({
        ...s,
        lessons: s.lessons.filter((l) => l.title.includes(needle) || s.title.includes(needle)),
      }))
      .filter((s) => s.lessons.length > 0);
  }, [level, q]);

  const total = levels.reduce((acc, lv) => acc + lv.subjects.reduce((a, s) => a + s.lessons.length, 0), 0);
  const ready = ALL_LESSONS.filter((l) => l.academy === academy).length;

  return (
    <div className="fade-up">
      <div className="mb-6 flex flex-wrap items-center gap-3">
        {levels.map((lv) => (
          <button
            key={lv.id}
            onClick={() => setActive(lv.id)}
            className={`btn ${active === lv.id ? "!border-accent !bg-accentsoft !text-accent" : ""}`}
          >
            {lv.code} — {lv.title}
          </button>
        ))}
      </div>

      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted" />
          <input
            className="input !pr-9"
            placeholder={`جست‌وجو در ${academyFa}...`}
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
        <div className="flex gap-2 text-xs">
          <span className="chip">{total} موضوع برنامه‌ریزی‌شده</span>
          <span className="chip !text-accent">{ready} درس کامل آماده</span>
        </div>
      </div>

      <div className="card mb-6 border-accent/30 !bg-accentsoft/40 p-4 text-sm leading-7 text-muted">
        <strong className="text-fg">{level.title}:</strong> {level.desc}. درس‌های دارای نشان
        «<CheckCircle2 className="inline size-4 text-accent" /> آماده» محتوای کامل آموزشی دارند؛ باقی
        درس‌ها در نقشه‌ی راه توسعه قرار دارند و به‌تدریج کامل می‌شوند.
      </div>

      {level.id === "d" && (
        <div className="card mb-4 border-warn/40 !bg-warn/5 p-4 text-xs leading-6">
          <strong className="text-warn">توجه صادقانهٔ آکادمیک:</strong> درس‌های این سطح «معرفی مسیر تحصیلات تکمیلی»
          هستند — نقشهٔ راه، پیش‌نیازها و ایده‌های کلیدی — نه دورهٔ کامل. درس‌های واقعیِ Graduate در برنامهٔ توسعه‌اند
          (وضعیت هرکدام با «به‌زودی» مشخص است).
        </div>
      )}
      <div className="grid gap-4 md:grid-cols-2">
        {filtered.map((s) => {
          const readyCount = s.lessons.filter((l) => l.ready).length;
          let lastChapter: string | undefined;
          return (
            <div key={s.id} className="card p-5">
              <div className="mb-1 flex flex-wrap items-center gap-2">
                <h3 className="font-bold">{s.title}</h3>
                <span className={`chip !text-[10px] ${readyCount > 0 ? "!text-accent" : ""}`}>
                  {readyCount}/{s.lessons.length} درس آماده
                </span>
              </div>
              {s.desc && <p className="mb-1 text-[11px] leading-6 text-muted">{s.desc}</p>}
              {s.prereq && s.prereq.length > 0 && (
                <p className="mb-3 text-[10px] leading-5 text-muted">
                  <strong className="text-accent2">پیش‌نیاز:</strong> {s.prereq.join(" ← ")}
                </p>
              )}
              <ul className="space-y-1.5">
                {s.lessons.map((l) => {
                  const chHeader = l.chapter && l.chapter !== lastChapter ? l.chapter : null;
                  lastChapter = l.chapter;
                  const done = progress.completedLessons.includes(`${academy}/${l.id}`);
                  const inner = l.ready ? (
                    <Link
                      href={`/academy/${academy}/${l.id}`}
                      className="group flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm transition-colors hover:bg-accentsoft"
                    >
                      {done ? (
                        <CheckCircle2 className="size-4 shrink-0 text-accent" />
                      ) : (
                        <CircleDashed className="size-4 shrink-0 text-muted group-hover:text-accent" />
                      )}
                      <span className="flex-1 group-hover:text-accent">{l.title}</span>
                      {(() => {
                        const meta = ALL_LESSONS.find((x) => x.id === l.id);
                        return meta ? (
                          <span className="chip !text-[10px]">
                            <Clock3 className="size-3" /> {meta.minutes} دقیقه
                          </span>
                        ) : null;
                      })()}
                    </Link>
                  ) : (
                    <div
                      className="flex items-center gap-2 px-2 py-1.5 text-sm text-muted/60"
                      title="این درس در نقشهٔ توسعه است"
                    >
                      <CircleDashed className="size-4 shrink-0" />
                      <span className="flex-1">{l.title}</span>
                      <span className="chip !text-[10px]">به‌زودی</span>
                    </div>
                  );
                  return (
                    <li key={l.id}>
                      {chHeader && (
                        <p className="mb-1 mt-3 text-[10px] font-bold tracking-wide text-accent2">{chHeader}</p>
                      )}
                      {inner}
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/** Lightweight rich text: **bold** segments */
function RichText({ s }: { s: string }) {
  const seg = s.split(/\*\*(.+?)\*\*/g);
  return (
    <>
      {seg.map((p, i) =>
        i % 2 === 1 ? (
          <strong key={i} className="font-bold text-fg">{p}</strong>
        ) : (
          <span key={i}>{p}</span>
        )
      )}
    </>
  );
}

/**
 * Renders text with {{...}} inline math segments.
 * Brace-depth-aware tokenizer: closing "}}" only counts at LaTeX depth 0,
 * so nested TeX like \frac{a}{b} (which itself ends in "}}") is never truncated.
 * Unclosed delimiters degrade gracefully to plain text.
 * Supports **bold** within plain text and multiline math content.
 */
export function Inline({ s }: { s: string }) {
  const parts: { kind: "text" | "math"; v: string }[] = [];
  let i = 0;
  while (i < s.length) {
    const open = s.indexOf("{{", i);
    if (open === -1) {
      parts.push({ kind: "text", v: s.slice(i) });
      break;
    }
    if (open > i) parts.push({ kind: "text", v: s.slice(i, open) });
    // balanced scan from after the opening delimiter
    let j = open + 2;
    let depth = 0;
    let end = -1;
    while (j < s.length) {
      const ch = s[j];
      if (ch === "\\") {
        j += 2; // skip escaped character (\{, \}, \\ ...)
        continue;
      }
      if (ch === "{") depth++;
      else if (ch === "}") {
        if (depth === 0 && s[j + 1] === "}") {
          end = j;
          break;
        }
        if (depth > 0) depth--;
      }
      j++;
    }
    if (end === -1) {
      // unclosed delimiter → render remainder as plain text
      parts.push({ kind: "text", v: s.slice(open) });
      break;
    }
    parts.push({ kind: "math", v: s.slice(open + 2, end) });
    i = end + 2;
  }
  return (
    <>
      {parts.map((p, k) =>
        p.kind === "math" ? <TeX key={k}>{p.v}</TeX> : <RichText key={k} s={p.v} />
      )}
    </>
  );
}
