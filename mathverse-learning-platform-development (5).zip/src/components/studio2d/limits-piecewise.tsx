"use client";

import { useMemo, useState } from "react";
import { create, all } from "mathjs";
import { CheckCircle2, XCircle } from "lucide-react";
import { Stage2D, numFmt } from "@/components/studio-ui";
import { Slider } from "@/components/lab-experiments";
import { TeX } from "@/components/katex";

const math = create(all);

type Preset = "hole" | "jump" | "sinx/x" | "osc" | "abs" | "custom";

export default function LimitsModule() {
  const [preset, setPreset] = useState<Preset>("hole");
  const [eps, setEps] = useState(0.5);
  const [delta, setDelta] = useState(0.4);
  const [c, setC] = useState(1);
  const [custom1, setCustom1] = useState("x + 1");
  const [custom2, setCustom2] = useState("3 - x");

  const meta = useMemo(() => {
    const compile = (s: string) => {
      try { const c0 = math.compile(s); return (x: number) => { try { const v = c0.evaluate({ x }); return typeof v === "number" && isFinite(v) ? v : null; } catch { return null; } }; } catch { return () => null; }
    };
    switch (preset) {
      case "hole": return { c: 1, f: (x: number) => (x === 1 ? null : x + 1), tex: "f(x) = \\frac{x^2-1}{x-1} \\;\\; (x \\neq 1)", title: "پنهانشدگی در یک نقطه (حفره)", hole: true };
      case "jump": return { c: 0, f: (x: number) => (x < 0 ? x + 1 : 2 - x), tex: "f(x) = \\begin{cases} x+1 & x<0 \\\\ 2-x & x\\ge0 \\end{cases}", title: "جهش در نقطه" };
      case "sinx/x": return { c: 0, f: (x: number) => (x === 0 ? null : Math.sin(x) / x), tex: "f(x) = \\frac{\\sin x}{x}", title: "حد مشهور: همگرا به ۱" };
      case "osc": return { c: 0, f: (x: number) => (x === 0 ? null : Math.sin(1 / x)), tex: "f(x) = \\sin\\tfrac{1}{x}", title: "نوسان بی‌کران: حد وجود ندارد" };
      case "abs": return { c: 0, f: (x: number) => Math.abs(x), tex: "f(x) = |x|", title: "حد موجود، مشتق‌ناپذیر (گوشه)" };
      default: {
        const f1 = compile(custom1), f2 = compile(custom2);
        return { c, f: (x: number) => (x < c ? f1(x) : f2(x)), tex: `f(x) = \\begin{cases} f_1(x) & x<c \\\\ f_2(x) & x\\ge c \\end{cases}`, title: "قطعه‌ای سفارشی" };
      }
    }
  }, [preset, c, custom1, custom2]);

  const h = 1e-4;
  const left = meta.f(meta.c - h);
  const right = meta.f(meta.c + h);
  const L = left != null && right != null && Math.abs(left - right) < 1e-3 ? (left + right) / 2 : null;

  // numeric ε-δ verification: sample inside δ-window (both sides) and check band |f−L|<ε
  const check = useMemo(() => {
    if (L == null) return null;
    for (const s of [-1, 1]) {
      for (let i = 1; i <= 200; i++) {
        const x = meta.c + (s * delta * i) / 200;
        const v = meta.f(x);
        if (v == null) continue;
        if (Math.abs(v - L) >= eps) return false;
      }
    }
    return true;
  }, [L, meta, delta, eps]);

  const draw = ({ ctx, toPx, toWorld, W }: { ctx: CanvasRenderingContext2D; toPx: (x: number, y: number) => readonly [number, number]; toWorld: (px: number, py: number) => [number, number]; W: number }) => {
    // eps band
    if (L != null) {
      const [xA] = toPx(meta.c - delta, 0);
      const [xB] = toPx(meta.c + delta, 0);
      const [, yTop] = toPx(0, L + eps);
      const [, yBot] = toPx(0, L - eps);
      ctx.fillStyle = "rgba(45,212,191,0.10)";
      ctx.fillRect(xA, yTop, xB - xA, yBot - yTop);
      ctx.strokeStyle = "#2dd4bf";
      ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.moveTo(0, yTop); ctx.lineTo(W, yTop); ctx.moveTo(0, yBot); ctx.lineTo(W, yBot); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(xA, 0); ctx.lineTo(xA, 1e4); ctx.moveTo(xB, 0); ctx.lineTo(xB, 1e4); ctx.stroke();
      ctx.setLineDash([]);
    }
    // function
    ctx.strokeStyle = "#60a5fa";
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    let pen = false; let prevY = 0;
    for (let i = 0; i <= W; i++) {
      const [xw] = toWorld(i, 0);
      const y = meta.f(xw);
      if (y == null) { pen = false; continue; }
      const [px, py] = toPx(xw, y);
      if (pen && Math.abs(py - prevY) > 900) pen = false;
      if (!pen) { ctx.moveTo(px, py); pen = true; } else ctx.lineTo(px, py);
      prevY = py;
    }
    ctx.stroke();
    // c marker
    if (L != null) {
      const [px, py] = toPx(meta.c, L);
      ctx.strokeStyle = "#f472b6";
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(px, py, 5, 0, Math.PI * 2); ctx.stroke(); // open circle at limit point
    }
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <Stage2D onDraw={draw} deps={[preset, eps, delta, c, custom1, custom2]} />
      <aside className="space-y-3">
        <div className="card space-y-3 p-4">
          <div className="flex flex-wrap gap-1.5">
            {([["hole", "حفره"], ["jump", "جهش"], ["sinx/x", "sin x/x"], ["osc", "نوسانی"], ["abs", "گوشه |x|"], ["custom", "قطعه‌ای سفارشی"]] as const).map(([id, fa]) => (
              <button key={id} onClick={() => setPreset(id)} className={`chip cursor-pointer ${preset === id ? "!border-accent !text-accent" : ""}`}>{fa}</button>
            ))}
          </div>
          <div className="rounded-xl bg-surface2 p-3"><TeX block>{meta.tex}</TeX></div>
          <p className="text-[11px] text-muted">{meta.title}</p>
        </div>
        {preset === "custom" && (
          <div className="card space-y-2 p-4">
            <label className="block text-[11px] text-muted">f₁(x) برای x &lt; c</label>
            <input dir="ltr" className="input !py-1 font-mono text-xs" value={custom1} onChange={(e) => setCustom1(e.target.value)} />
            <label className="block text-[11px] text-muted">f₂(x) برای x ≥ c</label>
            <input dir="ltr" className="input !py-1 font-mono text-xs" value={custom2} onChange={(e) => setCustom2(e.target.value)} />
            <Slider label="نقطهٔ اتصال c" value={c} min={-3} max={3} step={0.25} onChange={setC} />
          </div>
        )}
        <div className="card space-y-2.5 p-4">
          <Slider label="ε (باند پیرامون L)" value={eps} min={0.05} max={1.5} step={0.05} onChange={setEps} />
          <Slider label="δ (پنجره پیرامون c)" value={delta} min={0.05} max={1.5} step={0.05} onChange={setDelta} />
        </div>
        <div className="card p-4 text-xs leading-7">
          <div className="flex justify-between"><span className="text-muted">حد چپ:</span><span className="font-mono" dir="ltr">{left != null ? numFmt(left) : "∞/∞"}</span></div>
          <div className="flex justify-between"><span className="text-muted">حد راست:</span><span className="font-mono" dir="ltr">{right != null ? numFmt(right) : "∞/∞"}</span></div>
          <div className="flex justify-between"><span className="text-muted">حد دوطرفه L:</span><span className="font-mono text-accent" dir="ltr">{L != null ? numFmt(L) : "وجود ندارد"}</span></div>
          <div className="mt-2 flex items-center gap-2">
            {check == null ? (
              <span className="chip !text-warn"><XCircle className="size-3" /> حد یکتا وجود ندارد — تعریف ε–δ قابل اجرا نیست</span>
            ) : check ? (
              <span className="chip !text-accent"><CheckCircle2 className="size-3" /> δ فعلی برای ε کافی است (بررسی عددی)</span>
            ) : (
              <span className="chip !text-danger"><XCircle className="size-3" /> δ فعلی برای ε کافی نیست — δ را کوچک‌تر کنید</span>
            )}
          </div>
          <p className="mt-2 text-[10px] leading-5 text-muted">
            بررسی به‌صورت عددی روی ۴۰۰ نمونه در پنجرهٔ δ انجام می‌شود — ابزار شهودی است نه اثبات صوری.
          </p>
        </div>
      </aside>
    </div>
  );
}
