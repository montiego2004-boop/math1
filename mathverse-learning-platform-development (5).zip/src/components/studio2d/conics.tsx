"use client";

import { useRef, useState } from "react";
import { Play, Pause, RotateCcw } from "lucide-react";
import { Stage2D, numFmt } from "@/components/studio-ui";
import { Slider, useLoop } from "@/components/lab-experiments";
import { TeX } from "@/components/katex";

type Conic = "circle" | "ellipse" | "parabola" | "hyperbola" | "eccentricity" | "line";
type Special = "cycloid" | "cardioid" | "rose" | "lissajous" | "lemniscate";

const fmt = numFmt;

export default function ConicsModule() {
  const [family, setFamily] = useState<"conic" | "special">("conic");
  return (
    <div>
      <div className="mb-4 flex gap-2">
        <button className={`btn !text-xs ${family === "conic" ? "!border-accent !text-accent" : ""}`} onClick={() => setFamily("conic")}>مقاطع مخروطی و خطوط</button>
        <button className={`btn !text-xs ${family === "special" ? "!border-accent !text-accent" : ""}`} onClick={() => setFamily("special")}>منحنی‌های ویژه و حرکت</button>
      </div>
      {family === "conic" ? <ConicPanel /> : <SpecialPanel />}
    </div>
  );
}

/* ------------------------------ Conics ------------------------------ */

function ConicPanel() {
  const [type, setType] = useState<Conic>("ellipse");
  const [h, setH] = useState(0);
  const [k, setK] = useState(0);
  const [a, setA] = useState(3);
  const [b, setB] = useState(2);
  const [e, setE] = useState(0.6);
  const [l, setL] = useState(2);

  const ecc = type === "circle" ? 0 : type === "ellipse" ? Math.sqrt(Math.max(0, 1 - (b * b) / (a * a))) : type === "hyperbola" ? Math.sqrt(1 + (b * b) / (a * a)) : 1;

  const draw = ({ ctx, toPx, vp }: { ctx: CanvasRenderingContext2D; toPx: (x: number, y: number) => readonly [number, number]; vp: { scale: number } }) => {
    const step = (t: number) => 1 / (2 * vp.scale); // world step ~2px
    ctx.lineWidth = 2.2;
    ctx.strokeStyle = "#2dd4bf";
    const path = (f: (t: number) => [number, number] | null, t0: number, t1: number, n = 2400) => {
      ctx.beginPath();
      let pen = false;
      let prevY = 0;
      for (let i = 0; i <= n; i++) {
        const t = t0 + ((t1 - t0) * i) / n;
        const p = f(t);
        if (!p) { pen = false; continue; }
        const [px, py] = toPx(p[0], p[1]);
        if (pen && Math.abs(py - prevY) > 1400) { pen = false; }
        if (!pen) { ctx.moveTo(px, py); pen = true; } else ctx.lineTo(px, py);
        prevY = py;
      }
      ctx.stroke();
    };

    if (type === "circle") {
      path((t) => [h + a * Math.cos(t), k + a * Math.sin(t)], 0, 2 * Math.PI);
    } else if (type === "ellipse") {
      path((t) => [h + a * Math.cos(t), k + b * Math.sin(t)], 0, 2 * Math.PI);
      // foci
      const c = Math.sqrt(Math.max(0, a * a - b * b));
      ctx.fillStyle = "#f472b6";
      for (const s of [-1, 1]) {
        const [fx, fy] = toPx(h + s * c, k);
        ctx.beginPath(); ctx.arc(fx, fy, 4, 0, Math.PI * 2); ctx.fill();
      }
    } else if (type === "parabola") {
      // x² = 4py  (p = a)
      path((t) => [h + t, k + (t * t) / (4 * a)], -14, 14);
      // directrix + focus
      ctx.setLineDash([5, 4]);
      ctx.strokeStyle = "#fbbf24";
      ctx.beginPath();
      const [dx0, dy] = toPx(-30, k - a);
      const [dx1] = toPx(30, k - a);
      ctx.moveTo(dx0, dy); ctx.lineTo(dx1, dy); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = "#f472b6";
      const [fx, fy] = toPx(h, k + a);
      ctx.beginPath(); ctx.arc(fx, fy, 4, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = "#2dd4bf";
    } else if (type === "hyperbola") {
      path((t) => [h + a * Math.cosh(t), k + b * Math.sinh(t)], -2.4, 2.4);
      path((t) => [h - a * Math.cosh(t), k + b * Math.sinh(t)], -2.4, 2.4);
      // asymptotes
      ctx.setLineDash([5, 4]);
      ctx.strokeStyle = "#fbbf24";
      for (const s of [-1, 1]) {
        ctx.beginPath();
        const [x0, y0] = toPx(h - 20, k - (s * b * 20) / a);
        const [x1, y1] = toPx(h + 20, k + (s * b * 20) / a);
        ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      }
      ctx.setLineDash([]);
      ctx.strokeStyle = "#2dd4bf";
    } else if (type === "eccentricity") {
      // polar conic with focus at origin: r = l/(1 - e cos θ)
      path((t) => {
        const den = 1 - e * Math.cos(t);
        if (Math.abs(den) < 1e-6) return null;
        const r = l / den;
        if (r <= 1e-4 || r > 40) return null;
        return [r * Math.cos(t), r * Math.sin(t)];
      }, 0, 2 * Math.PI, 3000);
      void step;
    } else {
      // line y = ax + b through (h,k): slope a
      path((t) => [h + t, k + a * t], -30, 30);
    }
  };

  const eq =
    type === "circle" ? `(x-h)^2+(y-k)^2 = ${a}^2` :
    type === "ellipse" ? `\\frac{(x-${fmt(h)})^2}{${fmt(a)}^2} + \\frac{(y-${fmt(k)})^2}{${fmt(b)}^2} = 1` :
    type === "parabola" ? `(x-${fmt(h)})^2 = 4\\cdot ${fmt(a)}\\,(y-${fmt(k)})` :
    type === "hyperbola" ? `\\frac{(x-${fmt(h)})^2}{${fmt(a)}^2} - \\frac{(y-${fmt(k)})^2}{${fmt(b)}^2} = 1` :
    type === "eccentricity" ? `r = \\frac{l}{1 - e\\cos\\theta}, \\quad e=${fmt(e)},\\; l=${fmt(l)}` :
    `y - ${fmt(k)} = ${fmt(a)}(x - ${fmt(h)})`;

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <Stage2D onDraw={draw} deps={[type, h, k, a, b, e, l]} />
      <aside className="space-y-3">
        <div className="card space-y-2 p-4">
          <div className="flex flex-wrap gap-1.5">
            {([["circle", "دایره"], ["ellipse", "بیضی"], ["parabola", "سهمی"], ["hyperbola", "هذلولی"], ["eccentricity", "بر مبنای لختی e"], ["line", "خط"]] as const).map(([id, fa]) => (
              <button key={id} onClick={() => setType(id)} className={`chip cursor-pointer ${type === id ? "!border-accent !text-accent" : ""}`}>{fa}</button>
            ))}
          </div>
          <div className="rounded-xl bg-surface2 p-3"><TeX block>{eq}</TeX></div>
          {(type === "ellipse" || type === "hyperbola" || type === "circle") && (
            <p className="text-xs text-muted">لختی (eccentricity): <span dir="ltr" className="font-mono">{fmt(ecc)}</span></p>
          )}
        </div>
        <div className="card space-y-2.5 p-4">
          {type !== "eccentricity" && (
            <>
              <Slider label="h (مرکز)" value={h} min={-4} max={4} step={0.25} onChange={setH} />
              <Slider label="k (مرکز)" value={k} min={-4} max={4} step={0.25} onChange={setK} />
            </>
          )}
          {type !== "eccentricity" && <Slider label={type === "line" ? "شیب m" : "a / p"} value={a} min={-5} max={5} step={0.25} onChange={setA} />}
          {(type === "ellipse" || type === "hyperbola") && <Slider label="b" value={b} min={0.5} max={5} step={0.25} onChange={setB} />}
          {type === "eccentricity" && (
            <>
              <Slider label="لختی e" value={e} min={0} max={2} step={0.05} onChange={setE} />
              <Slider label="نیم‌وتر l" value={l} min={0.5} max={6} step={0.25} onChange={setL} />
            </>
          )}
        </div>
        <div className="card p-4 text-[11px] leading-6 text-muted">
          e &lt; 1 بیضی • e = 1 سهمی • e &gt; 1 هذلولی • e = 0 دایره. کانون‌ها صورتی‌اند؛ برای سهمی خط هادی نشانه‌گذاری شده است.
        </div>
      </aside>
    </div>
  );
}

/* --------------------------- Special curves --------------------------- */

function SpecialPanel() {
  const [type, setType] = useState<Special>("cycloid");
  const [a, setA] = useState(1);
  const [n2, setN2] = useState(3);
  const [m2, setM2] = useState(4);
  const [running, setRunning] = useState(true);
  const [tick, setTick] = useState(0);
  const tRef = useRefTicker();

  useLoop((dt) => { tRef.current += dt * 1.2; if (tRef.current > 12 * Math.PI) tRef.current = 0; setTick((t) => t + 1); }, running);

  const T = tRef.current;

  const draw = ({ ctx, toPx }: { ctx: CanvasRenderingContext2D; toPx: (x: number, y: number) => readonly [number, number] }) => {
    const pathN = (f: (t: number) => [number, number] | null, t0: number, t1: number, n = 2000, color = "#2dd4bf", width = 2.2, dash = false) => {
      ctx.strokeStyle = color;
      ctx.lineWidth = width;
      if (dash) ctx.setLineDash([5, 4]);
      ctx.beginPath();
      let pen = false;
      for (let i = 0; i <= n; i++) {
        const p = f(t0 + ((t1 - t0) * i) / n);
        if (!p) { pen = false; continue; }
        const [px, py] = toPx(p[0], p[1]);
        if (!pen) { ctx.moveTo(px, py); pen = true; } else ctx.lineTo(px, py);
      }
      ctx.stroke();
      ctx.setLineDash([]);
    };

    if (type === "cycloid") {
      const t = T % (4 * Math.PI);
      const cx = a * t, cy = a;
      // traced curve so far
      pathN((s) => [a * (s - Math.sin(s)), a * (1 - Math.cos(s))], 0, Math.max(0.001, t));
      // rolling circle
      pathN((s) => [cx + a * Math.cos(s), cy + a * Math.sin(s)], 0, 2 * Math.PI, 200, "#60a5fa", 1.4);
      // radius to marker + marker
      const mx = a * (t - Math.sin(t)), my = a * (1 - Math.cos(t));
      ctx.strokeStyle = "#f472b6";
      ctx.beginPath();
      const [cpx, cpy] = toPx(cx, cy);
      const [mpx, mpy] = toPx(mx, my);
      ctx.moveTo(cpx, cpy); ctx.lineTo(mpx, mpy); ctx.stroke();
      ctx.fillStyle = "#f472b6";
      ctx.beginPath(); ctx.arc(mpx, mpy, 5, 0, Math.PI * 2); ctx.fill();
    } else if (type === "cardioid") {
      const k = n2 / m2;
      const period = (2 * Math.PI) / Math.min(1, Math.abs(k - Math.floor(k)) > 0.001 ? 1 : 1) * (Math.abs(k % 1) > 0.001 ? m2 : 1);
      pathN((t) => {
        const r = 2 * a * (1 + Math.cos(k * t));
        return [r * Math.cos(t), r * Math.sin(t)];
      }, 0, Math.max(4 * Math.PI, period));
    } else if (type === "rose") {
      const k = n2 / m2;
      const period = Math.abs(k % 1) > 1e-6 ? 2 * Math.PI * m2 : k % 2 === 0 ? 2 * Math.PI : Math.PI;
      pathN((t) => {
        const r = a * Math.cos(k * t);
        return [r * Math.cos(t), r * Math.sin(t)];
      }, 0, Math.max(period, 2 * Math.PI * m2));
    } else if (type === "lissajous") {
      pathN((t) => [a * Math.sin(n2 * t + Math.PI / 2), a * Math.sin(m2 * t)], 0, 2 * Math.PI * Math.max(1, m2 / gcd(n2, m2)));
    } else {
      // lemniscate
      pathN((t) => {
        const c = Math.cos(2 * t);
        if (c < 0) return null;
        const r = a * Math.sqrt(c);
        return [r * Math.cos(t), r * Math.sin(t)];
      }, 0, 2 * Math.PI);
      pathN((t) => {
        const c = Math.cos(2 * t);
        if (c < 0) return null;
        const r = -a * Math.sqrt(c);
        return [r * Math.cos(t), r * Math.sin(t)];
      }, 0, 2 * Math.PI, 2000, "#60a5fa");
    }
  };

  const eq =
    type === "cycloid" ? "x=a(\\theta-\\sin\\theta),\\;\\; y=a(1-\\cos\\theta)" :
    type === "cardioid" ? "r = 2a(1+\\cos k\\theta)" :
    type === "rose" ? "r = a\\cos\\left(\\tfrac{n}{m}\\theta\\right)" :
    type === "lissajous" ? "x=a\\sin(nt+\\tfrac\\pi2),\\; y=a\\sin(mt)" :
    "r^2 = a^2\\cos 2\\theta";

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <div>
        <Stage2D onDraw={draw} deps={[type, a, n2, m2, tick]} />
        {type === "cycloid" && (
          <div className="mt-2 flex gap-2">
            <button className="btn !px-2.5 !py-1.5 !text-[11px]" onClick={() => setRunning((r) => !r)}>
              {running ? <Pause className="size-3.5" /> : <Play className="size-3.5" />} {running ? "توقف" : "شروع"}
            </button>
            <button className="btn !px-2.5 !py-1.5 !text-[11px]" onClick={() => { tRef.current = 0; }}>
              <RotateCcw className="size-3.5" /> بازنشانی
            </button>
          </div>
        )}
      </div>
      <aside className="space-y-3">
        <div className="card space-y-2 p-4">
          <div className="flex flex-wrap gap-1.5">
            {([["cycloid", "چرخه‌زاد (سیکلوئید)"], ["cardioid", "قلبي‌وار"], ["rose", "رز"], ["lissajous", "لیساژو"], ["lemniscate", "لمینسکات"]] as const).map(([id, fa]) => (
              <button key={id} onClick={() => setType(id)} className={`chip cursor-pointer ${type === id ? "!border-accent !text-accent" : ""}`}>{fa}</button>
            ))}
          </div>
          <div className="rounded-xl bg-surface2 p-3"><TeX block>{eq}</TeX></div>
        </div>
        <div className="card space-y-2.5 p-4">
          <Slider label="a (اندازه)" value={a} min={0.5} max={3} step={0.25} onChange={setA} />
          {(type === "cardioid" || type === "rose" || type === "lissajous") && (
            <>
              <Slider label="n" value={n2} min={1} max={8} step={1} onChange={(v) => setN2(Math.round(v))} />
              <Slider label="m" value={m2} min={1} max={8} step={1} onChange={(v) => setM2(Math.round(v))} />
            </>
          )}
        </div>
        <div className="card p-4 text-[11px] leading-6 text-muted">
          چرخه‌زاد مسیر نقطه‌ای روی لبه‌ی چرخ غلتان است؛ پاسخ مسئله‌ی معروف «تندترین فرود» (براکیستوکرون). لیساژو خلاصه‌ی
          برهم‌نهی دو نوسان عمود بر هم است — اسیلوسکوپ‌ها از آن استفاده می‌کنند.
        </div>
      </aside>
    </div>
  );
}

function useRefTicker() { return useRef(0); }
function gcd(a: number, b: number): number { return b === 0 ? a : gcd(b, a % b); }
