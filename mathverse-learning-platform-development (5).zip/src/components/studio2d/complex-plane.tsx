"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { create, all, type Complex } from "mathjs";
import { Slider } from "@/components/lab-experiments";
import { TeX } from "@/components/katex";

const math = create(all);

/* HSL → RGB for domain coloring */
function hsl(h: number, l: number): [number, number, number] {
  const s = 0.85;
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const hp = (((h % 360) + 360) % 360) / 60;
  const x = c * (1 - Math.abs((hp % 2) - 1));
  let r = 0, g = 0, b = 0;
  if (hp < 1) [r, g, b] = [c, x, 0];
  else if (hp < 2) [r, g, b] = [x, c, 0];
  else if (hp < 3) [r, g, b] = [0, c, x];
  else if (hp < 4) [r, g, b] = [0, x, c];
  else if (hp < 5) [r, g, b] = [x, 0, c];
  else [r, g, b] = [c, 0, x];
  const m = l - c / 2;
  return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
}

const PRESETS = ["z^2 - 1", "1/z", "(z-1)/(z^2+z+1)", "exp(z)", "sin(z)", "z^3 - z", "log(z)"];

export default function ComplexPlaneModule() {
  const [expr, setExpr] = useState("z^2 - 1");
  const [range, setRange] = useState(2.2);
  const [res, setRes] = useState(0.5);

  const fn = useMemo(() => {
    try {
      const c = math.compile(expr);
      return (re: number, im: number): Complex | null => {
        try {
          const v = c.evaluate({ z: math.complex(re, im) });
          if (v && typeof v === "object" && "re" in v) return v as Complex;
          if (typeof v === "number" && isFinite(v)) return math.complex(v, 0);
          return null;
        } catch { return null; }
      };
    } catch { return null; }
  }, [expr]);

  const draw = ({ ctx, W, H }: { ctx: CanvasRenderingContext2D; W: number; H: number; toPx: (x: number, y: number) => readonly [number, number] }) => {
    if (!fn) {
      ctx.fillStyle = "#f87171";
      ctx.font = "13px sans-serif";
      ctx.fillText("عبارت نامعتبر", 20, 30);
      return;
    }
    const pw = Math.max(40, Math.floor(W * res));
    const ph = Math.max(30, Math.floor(H * res));
    const img = ctx.createImageData(pw, ph);
    const data = img.data;
    const aspect = H / W;
    for (let j = 0; j < ph; j++) {
      for (let i = 0; i < pw; i++) {
        const re = ((i / pw) * 2 - 1) * range;
        const im = (1 - (j / ph) * 2) * range * aspect;
        const v = fn(re, im);
        let r = 10, g = 15, b = 30;
        if (v) {
          const mag = Math.hypot(v.re, v.im);
          if (isFinite(mag)) {
            const hue = (Math.atan2(v.im, v.re) * 180) / Math.PI;
            const l = 0.22 + 0.55 * (mag / (1 + mag));
            const [rr, gg, bb] = hsl(hue, l);
            r = rr; g = gg; b = bb;
          } else {
            r = g = b = 245;
          }
        }
        const o = (j * pw + i) * 4;
        data[o] = r; data[o + 1] = g; data[o + 2] = b; data[o + 3] = 255;
      }
    }
    const off = document.createElement("canvas");
    off.width = pw; off.height = ph;
    off.getContext("2d")!.putImageData(img, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(off, 0, 0, W, H);
    // axes hint
    ctx.strokeStyle = "rgba(230,238,251,0.5)";
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 4]);
    ctx.beginPath(); ctx.moveTo(0, H / 2); ctx.lineTo(W, H / 2); ctx.moveTo(W / 2, 0); ctx.lineTo(W / 2, H); ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "#e6eefb";
    ctx.font = "10px monospace";
    ctx.fillText("Re", W - 26, H / 2 - 6);
    ctx.fillText("Im", W / 2 + 6, 12);
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <div>
        <div className="card overflow-hidden">
          <CanvasHolder onDraw={draw} deps={[expr, range, res]} />
        </div>
        <div className="mt-2 flex gap-2 text-[10px]">
          {["صفر (تیره)", "قطب (روش/سفید)", "فاز + (قرمز)", "فاز − (فیروزه)"].map((t, i) => (
            <span key={t} className="chip">
              <span className="inline-block size-2.5 rounded-full" style={{ background: ["#0e1a2e", "#f8fafc", "#e11d48", "#14b8a6"][i] }} />
              {t}
            </span>
          ))}
        </div>
      </div>
      <aside className="space-y-3">
        <div className="card space-y-2.5 p-4">
          <label className="block text-[11px] font-bold text-muted">f(z) — متغیر z مختلط است</label>
          <input dir="ltr" className="input !py-1.5 font-mono text-xs" value={expr} onChange={(e) => setExpr(e.target.value)} />
          <div className="flex flex-wrap gap-1.5">
            {PRESETS.map((p) => (
              <button key={p} className="chip cursor-pointer font-mono hover:!border-accent" dir="ltr" onClick={() => setExpr(p)}>{p}</button>
            ))}
          </div>
          <Slider label="برد صفحه (±Re/Im)" value={range} min={0.5} max={8} step={0.1} onChange={setRange} />
          <Slider label="کیفیت رندر" value={res} min={0.25} max={1} step={0.05} onChange={setRes} />
        </div>
        <div className="card p-4 text-xs leading-7">
          <h4 className="mb-1 font-bold">رنگ‌بندی دامنه (Domain Coloring)</h4>
          <TeX block>{"w = f(z), \\quad \\text{Hue} = \\arg(w), \\quad \\text{Brightness} = |w|"}</TeX>
          <p className="text-[11px] leading-6 text-muted">
            هر نقطهٔ صفحهٔ z رنگش از مقدار f(z) می‌آید: رنگ = فاز (زاویهٔ) خروجی، روشنایی = اندازهٔ خروجی. صفرها تیره و
            قطب‌ها روشن دیده می‌شوند — مثلاً z²−1 دو صفر در ۱± دارد. دور هر صفرِ ساده، رنگ‌ها دقیقاً یک دور چرخش کامل
            می‌کنند (قضیهٔ argument).
          </p>
        </div>
      </aside>
    </div>
  );
}

/* lightweight canvas holder without grid (image fills everything) */
function CanvasHolder({ onDraw, deps }: { onDraw: (a: { ctx: CanvasRenderingContext2D; W: number; H: number; toPx: (x: number, y: number) => readonly [number, number] }) => void; deps: unknown[] }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const wrap = useRef<HTMLDivElement>(null);
  const cbRef = useRef(onDraw);
  cbRef.current = onDraw;
  useEffect(() => {
    const c = ref.current;
    const w = wrap.current;
    if (!c || !w) return;
    const dpr = Math.min(devicePixelRatio || 1, 1.5);
    const W = w.clientWidth, H = 400;
    c.width = W * dpr;
    c.height = H * dpr;
    c.style.height = `${H}px`;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = "#10233e";
    ctx.fillRect(0, 0, W, H);
    cbRef.current({ ctx, W, H, toPx: () => [0, 0] as const });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return (
    <div ref={wrap}>
      <canvas ref={ref} className="w-full" />
    </div>
  );
}
