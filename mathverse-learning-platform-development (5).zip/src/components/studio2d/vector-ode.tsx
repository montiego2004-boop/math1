"use client";

import { useMemo, useState } from "react";
import { create, all } from "mathjs";
import { MousePointerClick } from "lucide-react";
import { Stage2D, numFmt } from "@/components/studio-ui";
import { rk4 } from "@/components/lab-experiments";
import { TeX } from "@/components/katex";

const math = create(all);

export default function VectorOdeModule() {
  const [tab, setTab] = useState<"vector" | "slope">("vector");
  return (
    <div>
      <div className="mb-4 flex gap-2">
        <button className={`btn !text-xs ${tab === "vector" ? "!border-accent !text-accent" : ""}`} onClick={() => setTab("vector")}>میدان برداری (P, Q)</button>
        <button className={`btn !text-xs ${tab === "slope" ? "!border-accent !text-accent" : ""}`} onClick={() => setTab("slope")}>میدان شیب y′ = f(x,y)</button>
      </div>
      {tab === "vector" ? <VectorPanel /> : <SlopePanel />}
    </div>
  );
}

function useCompiled(expr: string, vars: string[]) {
  return useMemo(() => {
    try {
      const c = math.compile(expr);
      return (scope: Record<string, number>) => {
        try {
          const v = c.evaluate(scope);
          return typeof v === "number" && isFinite(v) ? v : NaN;
        } catch { return NaN; }
      };
    } catch { return null; }
  }, [expr]); // eslint-disable-line react-hooks/exhaustive-deps
}

/* --------------------------- Vector field --------------------------- */

function VectorPanel() {
  const [pex, setPex] = useState("y");
  const [qex, setQex] = useState("-x");
  const [normalized, setNormalized] = useState(true);
  const [seed, setSeed] = useState<[number, number]>([1, 0.5]);
  const P = useCompiled(pex, ["x", "y"]);
  const Q = useCompiled(qex, ["x", "y"]);

  // numeric divergence & curl at seed
  const eps = 1e-3;
  const probe = (() => {
    if (!P || !Q) return null;
    const [x, y] = seed;
    const pxp = P({ x: x + eps, y }), pxm = P({ x: x - eps, y });
    const pyp = P({ x, y: y + eps }), pym = P({ x, y: y - eps });
    const qxp = Q({ x: x + eps, y }), qxm = Q({ x: x - eps, y });
    const qyp = Q({ x, y: y + eps }), qym = Q({ x, y: y - eps });
    if ([pxp, pxm, pyp, pym, qxp, qxm, qyp, qym].some(isNaN)) return null;
    const div = (pxp - pxm) / (2 * eps) + (qyp - qym) / (2 * eps);
    const curl = (qxp - qxm) / (2 * eps) - (pyp - pym) / (2 * eps);
    return { div, curl };
  })();

  const draw = ({ ctx, toPx, toWorld, W, H }: { ctx: CanvasRenderingContext2D; toPx: (x: number, y: number) => readonly [number, number]; toWorld: (px: number, py: number) => [number, number]; W: number; H: number }) => {
    if (!P || !Q) {
      ctx.fillStyle = "#f87171";
      ctx.font = "13px sans-serif";
      ctx.fillText("عبارت نامعتبر", 20, 30);
      return;
    }
    const gx = 24, gy = 16;
    let maxM = 1;
    for (let i = 0; i < gx; i++) for (let j = 0; j < gy; j++) {
      const [xw, yw] = toWorld(((i + 0.5) / gx) * W, ((j + 0.5) / gy) * H);
      const m = Math.hypot(P({ x: xw, y: yw }), Q({ x: xw, y: yw }));
      if (isFinite(m)) maxM = Math.max(maxM, Math.min(m, 50));
    }
    for (let i = 0; i < gx; i++) for (let j = 0; j < gy; j++) {
      const [xw, yw] = toWorld(((i + 0.5) / gx) * W, ((j + 0.5) / gy) * H);
      const pv = P({ x: xw, y: yw });
      const qv = Q({ x: xw, y: yw });
      const m = Math.hypot(pv, qv);
      if (!isFinite(m) || m < 1e-9) continue;
      const u = Math.min(1, m / maxM);
      const ang = Math.atan2(qv, pv);
      const len = normalized ? 11 : Math.min(16, 4 + m * 4);
      const [px, py] = toPx(xw, yw);
      ctx.strokeStyle = u > 0.66 ? "#f472b6" : u > 0.33 ? "#fbbf24" : "#2dd4bf";
      ctx.lineWidth = 1.3;
      ctx.beginPath();
      ctx.moveTo(px - Math.cos(ang) * len * 0.45, py + Math.sin(ang) * len * 0.45);
      ctx.lineTo(px + Math.cos(ang) * len * 0.55, py - Math.sin(ang) * len * 0.55);
      // arrowhead
      const hx = px + Math.cos(ang) * len * 0.55, hy = py - Math.sin(ang) * len * 0.55;
      ctx.moveTo(hx, hy);
      ctx.lineTo(hx - Math.cos(ang - 0.45) * 4.5, hy + Math.sin(ang - 0.45) * 4.5);
      ctx.moveTo(hx, hy);
      ctx.lineTo(hx - Math.cos(ang + 0.45) * 4.5, hy + Math.sin(ang + 0.45) * 4.5);
      ctx.stroke();
    }
    // streamline through seed (RK4 both directions)
    const field = (_t: number, y: number[]) => [P({ x: y[0], y: y[1] }), Q({ x: y[0], y: y[1] })];
    for (const dir of [1, -1]) {
      let p: number[] = [...seed];
      ctx.strokeStyle = "#f472b6";
      ctx.lineWidth = 2;
      ctx.beginPath();
      const [sx0, sy0] = toPx(p[0], p[1]);
      ctx.moveTo(sx0, sy0);
      let pen = true;
      for (let i = 0; i < 420; i++) {
        const pv = P({ x: p[0], y: p[1] }), qv = Q({ x: p[0], y: p[1] });
        if (!isFinite(pv) || !isFinite(qv)) break;
        p = rk4(p, (_t, yy) => { const r = field(0, yy); return [dir * r[0], dir * r[1]]; }, 0, 0.025);
        if (Math.abs(p[0]) > 1e4 || Math.abs(p[1]) > 1e4) break;
        const [px, py] = toPx(p[0], p[1]);
        if (px < -50 || px > W + 50 || py < -50 || py > H + 50) { if (pen) continue; }
        pen = true;
        ctx.lineTo(px, py);
      }
      ctx.stroke();
    }
    const [spx, spy] = toPx(seed[0], seed[1]);
    ctx.fillStyle = "#f472b6";
    ctx.beginPath(); ctx.arc(spx, spy, 5, 0, Math.PI * 2); ctx.fill();
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <div>
        <Stage2D onDraw={draw} deps={[pex, qex, normalized, seed]} onClickWorld={(x, y) => setSeed([x, y])} />
        <p className="mt-2 flex items-center gap-1.5 text-[11px] text-muted"><MousePointerClick className="size-3.5 text-accent" /> روی صفحه کلیک کنید: خط جریان از آن نقطه رسم می‌شود.</p>
      </div>
      <aside className="space-y-3">
        <div className="card space-y-2.5 p-4">
          <label className="block text-[11px] font-bold text-muted">P(x,y) — مؤلفهٔ افقی</label>
          <input dir="ltr" className="input !py-1.5 font-mono text-xs" value={pex} onChange={(e) => setPex(e.target.value)} />
          <label className="block text-[11px] font-bold text-muted">Q(x,y) — مؤلفهٔ قائم</label>
          <input dir="ltr" className="input !py-1.5 font-mono text-xs" value={qex} onChange={(e) => setQex(e.target.value)} />
          <div className="flex gap-1.5">
            {["y, -x", "-y, x", "x, y", "x^2 - y^2, 2*x*y", "sin(y), sin(x)"].map((p) => {
              const [a, b] = p.split(",").map((s) => s.trim());
              return (
                <button key={p} className="chip cursor-pointer font-mono hover:!border-accent" dir="ltr" onClick={() => { setPex(a); setQex(b); }}>
                  ({a}, {b})
                </button>
              );
            })}
          </div>
          <label className="flex cursor-pointer items-center gap-2 text-xs">
            <input type="checkbox" checked={normalized} onChange={(e) => setNormalized(e.target.checked)} />
            یکسان‌سازی طول فلش‌ها (جهت + شدت با رنگ)
          </label>
        </div>
        <div className="card p-4 text-xs leading-7">
          <h4 className="mb-1 font-bold">خوانش عددی در نقطهٔ دانه (تفاضل مرکزی — تقریبی):</h4>
          <div dir="ltr" className="font-mono">({numFmt(seed[0])}, {numFmt(seed[1])})</div>
          {probe ? (
            <>
              <div dir="ltr" className="font-mono">div F ≈ {numFmt(probe.div)}</div>
              <div dir="ltr" className="font-mono">curl F ≈ {numFmt(probe.curl)}</div>
            </>
          ) : <div className="text-muted">—</div>}
          <div className="mt-2"><TeX>{"\\nabla\\cdot\\vec F = \\partial_x P + \\partial_y Q"}</TeX></div>
          <TeX>{"\\operatorname{curl}\\vec F = \\partial_x Q - \\partial_y P"}</TeX>
        </div>
      </aside>
    </div>
  );
}

/* ---------------------------- Slope field ---------------------------- */

function SlopePanel() {
  const [fex, setFex] = useState("x - y");
  const [seed, setSeed] = useState<[number, number]>([0, 1]);
  const f = useCompiled(fex, ["x", "y"]);

  const draw = ({ ctx, toPx, toWorld, W, H }: { ctx: CanvasRenderingContext2D; toPx: (x: number, y: number) => readonly [number, number]; toWorld: (px: number, py: number) => [number, number]; W: number; H: number }) => {
    if (!f) {
      ctx.fillStyle = "#f87171";
      ctx.font = "13px sans-serif";
      ctx.fillText("عبارت نامعتبر", 20, 30);
      return;
    }
    const gx = 26, gy = 17;
    for (let i = 0; i < gx; i++) for (let j = 0; j < gy; j++) {
      const [xw, yw] = toWorld(((i + 0.5) / gx) * W, ((j + 0.5) / gy) * H);
      const m = f({ x: xw, y: yw });
      if (!isFinite(m)) continue;
      const ang = Math.atan2(-m, 1); // screen y flipped
      const len = 9;
      const [px, py] = toPx(xw, yw);
      const u = Math.min(1, Math.abs(m) / 4);
      ctx.strokeStyle = u > 0.6 ? "#f472b6" : "#60a5fa";
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(px - Math.cos(ang) * len, py - Math.sin(ang) * len);
      ctx.lineTo(px + Math.cos(ang) * len, py + Math.sin(ang) * len);
      ctx.stroke();
    }
    // solution through seed
    for (const dir of [1, -1]) {
      let x = seed[0], y = seed[1];
      ctx.strokeStyle = dir === 1 ? "#2dd4bf" : "#f472b6";
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      let [px, py] = toPx(x, y);
      ctx.moveTo(px, py);
      const h = 0.02 * dir;
      for (let i = 0; i < 700; i++) {
        // RK4 for scalar ODE
        const k1 = f({ x, y });
        const k2 = f({ x: x + h / 2, y: y + (h / 2) * k1 });
        const k3 = f({ x: x + h / 2, y: y + (h / 2) * k2 });
        const k4 = f({ x: x + h, y: y + h * k3 });
        if (![k1, k2, k3, k4].every(isFinite)) break;
        x += h;
        y += (h / 6) * (k1 + 2 * k2 + 2 * k3 + k4);
        if (Math.abs(y) > 60 || Math.abs(x) > 60) break;
        [px, py] = toPx(x, y);
        ctx.lineTo(px, py);
      }
      ctx.stroke();
    }
    const [sx, sy] = toPx(seed[0], seed[1]);
    ctx.fillStyle = "#f472b6";
    ctx.beginPath(); ctx.arc(sx, sy, 5, 0, Math.PI * 2); ctx.fill();
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <div>
        <Stage2D onDraw={draw} deps={[fex, seed]} onClickWorld={(x, y) => setSeed([x, y])} />
        <p className="mt-2 flex items-center gap-1.5 text-[11px] text-muted"><MousePointerClick className="size-3.5 text-accent" /> کلیک: شرط اولیه‌ی جواب (fیروزه‌ای رو به جلو، صورتی رو به عقب).</p>
      </div>
      <aside className="space-y-3">
        <div className="card space-y-2.5 p-4">
          <label className="block text-[11px] font-bold text-muted">f(x,y) در فرمول y′ = f(x,y)</label>
          <input dir="ltr" className="input !py-1.5 font-mono text-xs" value={fex} onChange={(e) => setFex(e.target.value)} />
          <div className="flex flex-wrap gap-1.5">
            {["x - y", "y - x", "-x*y", "cos(x)", "y*(1-y)", "-y + sin(x)"].map((p) => (
              <button key={p} className="chip cursor-pointer font-mono hover:!border-accent" dir="ltr" onClick={() => setFex(p)}>{p}</button>
            ))}
          </div>
        </div>
        <div className="card p-4 text-xs leading-7">
          <h4 className="mb-1 font-bold">نقطهٔ اولیه:</h4>
          <div dir="ltr" className="font-mono">y({numFmt(seed[0])}) = {numFmt(seed[1])}</div>
          <div dir="ltr" className="font-mono">f = {f ? numFmt(f({ x: seed[0], y: seed[1] })) : "—"}</div>
          <p className="mt-2 text-[11px] leading-5 text-muted">
            جواب با RK4 عددی (h=0.02) رسم می‌شود — تقریب عددی با برچسب شفاف؛ جواب تحلیلی در صورت وجود از حل‌گر نمادین بخواهید.
          </p>
        </div>
      </aside>
    </div>
  );
}
