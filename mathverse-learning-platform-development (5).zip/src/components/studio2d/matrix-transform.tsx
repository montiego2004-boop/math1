"use client";

import { useState } from "react";
import { Play, Pause } from "lucide-react";
import { Stage2D, numFmt } from "@/components/studio-ui";
import { Slider, useLoop } from "@/components/lab-experiments";
import { TeX } from "@/components/katex";

const fmt = numFmt;

export default function MatrixTransformModule() {
  const [a, setA] = useState(1.5);
  const [b, setB] = useState(0.5);
  const [c, setC] = useState(0.2);
  const [d, setD] = useState(1);
  const [anim, setAnim] = useState(true);
  const [t, setT] = useState(0);

  useLoop((dt) => { setT((x) => (x + dt * 0.5) % 2); }, anim);
  // ping-pong 0→1→0
  const t01 = t <= 1 ? t : 2 - t;

  const det = a * d - b * c;
  const tr = a + d;
  // eigenvalues of [[a,b],[c,d]]: λ² − tr λ + det = 0
  const disc = tr * tr - 4 * det;
  const eigs: { re: number; im: number }[] = disc >= 0
    ? [{ re: (tr + Math.sqrt(disc)) / 2, im: 0 }, { re: (tr - Math.sqrt(disc)) / 2, im: 0 }]
    : [{ re: tr / 2, im: Math.sqrt(-disc) / 2 }, { re: tr / 2, im: -Math.sqrt(-disc) / 2 }];
  const eigvec = (lam: { re: number; im: number }): [number, number] | null => {
    if (lam.im !== 0) return null;
    // (A - λI) v = 0; try v = (b, λ-a) or (λ-d, c)
    let v: [number, number] | null = null;
    if (Math.abs(b) > 1e-9 || Math.abs(lam.re - a) > 1e-9) v = [b, lam.re - a];
    else if (Math.abs(c) > 1e-9 || Math.abs(lam.re - d) > 1e-9) v = [lam.re - d, c];
    if (!v) return null;
    const m = Math.hypot(v[0], v[1]);
    return m < 1e-9 ? null : [v[0] / m, v[1] / m];
  };

  const apply = (x: number, y: number): [number, number] => {
    const ta = (1 - t01) + t01 * a, tb = t01 * b, tc = t01 * c, td = (1 - t01) + t01 * d;
    return [ta * x + tb * y, tc * x + td * y];
  };

  const draw = ({ ctx, toPx }: { ctx: CanvasRenderingContext2D; toPx: (x: number, y: number) => readonly [number, number] }) => {
    // transformed grid
    ctx.lineWidth = 1;
    for (let k = -8; k <= 8; k++) {
      // vertical line x=k
      ctx.strokeStyle = "rgba(96,165,250,0.35)";
      ctx.beginPath();
      let pen = false;
      for (let i = 0; i <= 200; i++) {
        const y = -10 + (20 * i) / 200;
        const [tx, ty] = apply(k, y);
        const [px, py] = toPx(tx, ty);
        if (!pen) { ctx.moveTo(px, py); pen = true; } else ctx.lineTo(px, py);
      }
      ctx.stroke();
      // horizontal y=k
      ctx.strokeStyle = "rgba(45,212,191,0.3)";
      ctx.beginPath();
      pen = false;
      for (let i = 0; i <= 200; i++) {
        const x = -10 + (20 * i) / 200;
        const [tx, ty] = apply(x, k);
        const [px, py] = toPx(tx, ty);
        if (!pen) { ctx.moveTo(px, py); pen = true; } else ctx.lineTo(px, py);
      }
      ctx.stroke();
    }
    // unit square image
    const corners: [number, number][] = [[0, 0], [1, 0], [1, 1], [0, 1]];
    ctx.strokeStyle = "#f472b6";
    ctx.lineWidth = 2.2;
    ctx.fillStyle = "rgba(244,114,182,0.14)";
    ctx.beginPath();
    corners.forEach(([x, y], i) => {
      const [tx, ty] = apply(x, y);
      const [px, py] = toPx(tx, ty);
      i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
    });
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    // basis vectors
    const arrow = (vx: number, vy: number, color: string, w = 2.6) => {
      ctx.strokeStyle = color;
      ctx.lineWidth = w;
      const [x0, y0] = toPx(0, 0);
      const [x1, y1] = toPx(vx, vy);
      ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      const ang = Math.atan2(y0 - y1, x1 - x0);
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x1 - Math.cos(ang - 0.4) * 9, y1 - Math.sin(ang - 0.4) * 9);
      ctx.moveTo(x1, y1);
      ctx.lineTo(x1 - Math.cos(ang + 0.4) * 9, y1 - Math.sin(ang + 0.4) * 9);
      ctx.stroke();
    };
    const e1 = apply(1, 0), e2 = apply(0, 1);
    arrow(e1[0], e1[1], "#f87171");
    arrow(e2[0], e2[1], "#4ade80");
    // eigenvector directions at full transform
    if (t01 > 0.95) {
      for (const lam of eigs) {
        const v = eigvec(lam);
        if (!v) continue;
        arrow(v[0] * lam.re * 0.9, v[1] * lam.re * 0.9, "#fbbf24", 2);
        arrow(-v[0] * lam.re * 0.9, -v[1] * lam.re * 0.9, "#fbbf24", 1);
      }
    }
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <div>
        <Stage2D onDraw={draw} deps={[a, b, c, d, t01]} />
        <div className="mt-2 flex items-center gap-2">
          <button className="btn !px-2.5 !py-1.5 !text-[11px]" onClick={() => setAnim((v) => !v)}>
            {anim ? <Pause className="size-3.5" /> : <Play className="size-3.5" />} انیمیشن I → A
          </button>
          <span className="chip font-mono" dir="ltr">t = {t01.toFixed(2)}</span>
        </div>
      </div>
      <aside className="space-y-3">
        <div className="card p-4">
          <div className="mb-2 flex items-center justify-between">
            <h4 className="text-xs font-bold">ماتریس A = [[a,b],[c,d]]</h4>
          </div>
          <div className="grid grid-cols-2 gap-1.5" dir="ltr">
            {([[a, setA, "a"], [b, setB, "b"], [c, setC, "c"], [d, setD, "d"]] as const).map(([v, set, l]) => (
              <label key={l} className="text-center text-[10px] text-muted">
                {l}
                <input className="input mt-0.5 !py-1 text-center font-mono text-xs" value={v} onChange={(e) => set(Number(e.target.value) || 0)} />
              </label>
            ))}
          </div>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {[
              ["چرخش ۹۰°", 0, -1, 1, 0], ["برش", 1, 1, 0, 1], ["بازتاب", 1, 0, 0, -1], ["مقیاس", 1.5, 0, 0, 0.5],
            ].map(([l, x0, x1, x2, x3]) => (
              <button key={l as string} className="chip cursor-pointer hover:!border-accent" onClick={() => { setA(x0 as number); setB(x1 as number); setC(x2 as number); setD(x3 as number); }}>{l}</button>
            ))}
          </div>
        </div>
        <div className="card space-y-2 p-4 text-xs leading-7">
          <div className="flex justify-between"><span className="text-muted">دترمینان (ضریب مساحت):</span><span className="font-mono" dir="ltr">{fmt(det)}</span></div>
          <div className="flex justify-between"><span className="text-muted">تر (trace):</span><span className="font-mono" dir="ltr">{fmt(tr)}</span></div>
          <div>
            <span className="text-muted">مقادیر ویژه: </span>
            {eigs.map((l, i) => (
              <span key={i} className="ml-2 font-mono" dir="ltr">{l.im === 0 ? fmt(l.re) : `${fmt(l.re)} ± ${fmt(Math.abs(l.im))}i`}</span>
            ))}
          </div>
          {Math.abs(det) < 1e-9 && <p className="text-warn">دترمینان صفر: صفحه روی یک خط (یا نقطه) فرو می‌ریزد و تبدیل وارون‌پذیر نیست.</p>}
          {disc < 0 && <p className="text-muted">مقادیر ویژه مختلط: رفتار شامل چرخش است (هیچ جهتِ بردار ویژهٔ حقیقی ثابت نمی‌ماند).</p>}
        </div>
        <div className="card p-4 text-[11px] leading-6 text-muted">
          pلپهٔ صورتی: تصویر مربع واحد (مساحتش = |det|) • پیکان‌های زرد: جهت‌های ویژه با طول |λ| • انیمیشن بین ماتریس
          واحد و A نمایش می‌دهد که تبدیل چگونه صفحه را می‌کشد/می‌چرخاند.
        </div>
        <TeX block>{"\\det(\\lambda I - A) = \\lambda^2 - (\\operatorname{tr}A)\\lambda + \\det A = 0"}</TeX>
      </aside>
    </div>
  );
}
