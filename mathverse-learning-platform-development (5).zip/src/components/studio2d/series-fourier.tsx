"use client";

import { useMemo, useState } from "react";
import { Stage2D, numFmt } from "@/components/studio-ui";
import { Slider } from "@/components/lab-experiments";
import { TeX } from "@/components/katex";

const fact = (n: number) => { let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; };

type TaylorPreset = "sin" | "cos" | "exp" | "geom" | "ln" | "atan";

const TAYLOR: Record<TaylorPreset, { fa: string; tex: string; radius: string; f: (x: number) => number; term: (k: number, x: number) => number }> = {
  sin: { fa: "sin(x)", tex: "\\sin x = \\sum_{k=0}^{N} \\frac{(-1)^k x^{2k+1}}{(2k+1)!}", radius: "همگرا برای همهٔ x (R = ∞)", f: Math.sin, term: (k, x) => ((-1) ** k * x ** (2 * k + 1)) / fact(2 * k + 1) },
  cos: { fa: "cos(x)", tex: "\\cos x = \\sum_{k=0}^{N} \\frac{(-1)^k x^{2k}}{(2k)!}", radius: "همگرا برای همهٔ x", f: Math.cos, term: (k, x) => ((-1) ** k * x ** (2 * k)) / fact(2 * k) },
  exp: { fa: "eˣ", tex: "e^x = \\sum_{k=0}^{N} \\frac{x^k}{k!}", radius: "همگرا برای همهٔ x", f: Math.exp, term: (k, x) => x ** k / fact(k) },
  geom: { fa: "1/(1−x)", tex: "\\frac{1}{1-x} = \\sum_{k=0}^{N} x^k", radius: "فقط برای |x| < 1 همگرا — بیرون از آن واگرا!", f: (x) => 1 / (1 - x), term: (k, x) => x ** k },
  ln: { fa: "ln(1+x)", tex: "\\ln(1+x) = \\sum_{k=1}^{N} \\frac{(-1)^{k+1} x^k}{k}", radius: "برای |x| < 1 (و x=1) همگرا", f: (x) => Math.log(1 + x), term: (k, x) => (k === 0 ? 0 : ((-1) ** (k + 1) * x ** k) / k) },
  atan: { fa: "arctan(x)", tex: "\\arctan x = \\sum_{k=0}^{N} \\frac{(-1)^k x^{2k+1}}{2k+1}", radius: "برای |x| ≤ 1 همگرا", f: Math.atan, term: (k, x) => ((-1) ** k * x ** (2 * k + 1)) / (2 * k + 1) },
};

type Wave = "square" | "saw" | "triangle";

const FOURIER: Record<Wave, { fa: string; tex: string; target: (x: number) => number; coef: (k: number) => { a: number; b: number } }> = {
  square: { fa: "موج مربعی", tex: "f(x) = \\frac{4}{\\pi}\\sum_{k\\ \\text{فرد}} \\frac{\\sin kx}{k}", target: (x) => (Math.sin(x) >= 0 ? 1 : -1), coef: (k) => ({ a: 0, b: k % 2 === 1 ? 4 / (Math.PI * k) : 0 }) },
  saw: { fa: "موج دندانه‌اره‌ای", tex: "f(x) = \\frac{2}{\\pi}\\sum_{k\\ge1} \\frac{(-1)^{k+1}\\sin kx}{k}", target: (x) => { const t = ((x % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI); return (t - Math.PI) / Math.PI; }, coef: (k) => ({ a: 0, b: (2 * (-1) ** (k + 1)) / (Math.PI * k) }) },
  triangle: { fa: "موج مثلثی", tex: "f(x) = \\frac{8}{\\pi^2}\\sum_{k\\ \\text{فرد}} \\frac{(-1)^{(k-1)/2}\\sin kx}{k^2}", target: (x) => { const t = ((x % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI); return t < Math.PI ? (2 * t) / Math.PI - 1 : 3 - (2 * t) / Math.PI; }, coef: (k) => ({ a: 0, b: k % 2 === 1 ? (8 * (-1) ** ((k - 1) / 2)) / (Math.PI * Math.PI * k * k) : 0 }) },
};

export default function SeriesFourierModule() {
  const [tab, setTab] = useState<"taylor" | "fourier">("taylor");
  return (
    <div>
      <div className="mb-4 flex gap-2">
        <button className={`btn !text-xs ${tab === "taylor" ? "!border-accent !text-accent" : ""}`} onClick={() => setTab("taylor")}>سری تیلور (سری توان)</button>
        <button className={`btn !text-xs ${tab === "fourier" ? "!border-accent !text-accent" : ""}`} onClick={() => setTab("fourier")}>سری فوریه</button>
      </div>
      {tab === "taylor" ? <TaylorPanel /> : <FourierPanel />}
    </div>
  );
}

function TaylorPanel() {
  const [preset, setPreset] = useState<TaylorPreset>("sin");
  const [N, setN] = useState(6);
  const [x0, setX0] = useState(1.2);
  const P = TAYLOR[preset];

  const partial = (x: number) => { let s = 0; for (let k = 0; k <= N; k++) s += P.term(k, x); return s; };
  const err = Math.abs(P.f(x0) - partial(x0));

  const draw = ({ ctx, toPx, toWorld, W }: { ctx: CanvasRenderingContext2D; toPx: (x: number, y: number) => readonly [number, number]; toWorld: (px: number, py: number) => [number, number]; W: number }) => {
    // exact function (dashed)
    const plot = (fn: (x: number) => number, color: string, width: number, dash: boolean) => {
      ctx.strokeStyle = color; ctx.lineWidth = width;
      if (dash) ctx.setLineDash([5, 4]);
      ctx.beginPath();
      let pen = false; let prevY = 0;
      for (let i = 0; i <= W; i++) {
        const [xw] = toWorld(i, 0);
        const y = fn(xw);
        if (!isFinite(y)) { pen = false; continue; }
        const [px, py] = toPx(xw, y);
        if (pen && Math.abs(py - prevY) > 1200) pen = false;
        if (!pen) { ctx.moveTo(px, py); pen = true; } else ctx.lineTo(px, py);
        prevY = py;
      }
      ctx.stroke(); ctx.setLineDash([]);
    };
    plot(P.f, "#60a5fa", 2.4, true);
    plot(partial, "#2dd4bf", 2.4, false);
    // probe
    const [px, py] = toPx(x0, partial(x0));
    ctx.fillStyle = "#f472b6";
    ctx.beginPath(); ctx.arc(px, Math.min(py, 1e6), 5, 0, Math.PI * 2); ctx.fill();
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <Stage2D onDraw={draw} deps={[preset, N, x0]} />
      <aside className="space-y-3">
        <div className="card space-y-3 p-4">
          <div className="flex flex-wrap gap-1.5">
            {(Object.keys(TAYLOR) as TaylorPreset[]).map((k) => (
              <button key={k} onClick={() => setPreset(k)} className={`chip cursor-pointer font-mono ${preset === k ? "!border-accent !text-accent" : ""}`} dir="ltr">{TAYLOR[k].fa}</button>
            ))}
          </div>
          <div className="rounded-xl bg-surface2 p-3"><TeX block>{P.tex}</TeX></div>
          <p className="text-[11px] leading-6 text-warn">{P.radius}</p>
        </div>
        <div className="card space-y-2.5 p-4">
          <Slider label="تعداد جملات N" value={N} min={1} max={20} step={1} onChange={(v) => setN(Math.round(v))} />
          <Slider label="نقطهٔ آزمون x" value={x0} min={-3} max={3} step={0.05} onChange={setX0} />
        </div>
        <div className="card p-4 text-xs leading-7" dir="ltr">
          <div className="font-mono">f({numFmt(x0)}) = {numFmt(P.f(x0))}</div>
          <div className="font-mono">S_N({numFmt(x0)}) = {numFmt(partial(x0))}</div>
          <div className="font-mono !text-[#f472b6]">|خطا| ≈ {err.toExponential(3)}</div>
        </div>
        <p className="text-[11px] leading-5 text-muted">خط‌چین آبی: تابع دقیق • فیروزه‌ای: جزء Nام (تقریب). برای geom و ln و atan بیرون از شعاع همگرایی واگرایی را ببینید.</p>
      </aside>
    </div>
  );
}

function FourierPanel() {
  const [wave, setWave] = useState<Wave>("square");
  const [N, setN] = useState(9);
  const W = FOURIER[wave];

  const approx = useMemo(
    () => (x: number) => {
      let s = 0;
      for (let k = 1; k <= N; k++) {
        const c = W.coef(k);
        s += c.a * Math.cos(k * x) + c.b * Math.sin(k * x);
      }
      return s;
    },
    [W, N]
  );

  const maxErr = useMemo(() => {
    let m = 0;
    for (let i = 0; i < 1500; i++) {
      const x = (-3 * Math.PI + (6 * Math.PI * i) / 1499);
      m = Math.max(m, Math.abs(approx(x) - W.target(x)));
    }
    return m;
  }, [approx, W]);

  const draw = ({ ctx, toPx, toWorld, W: w }: { ctx: CanvasRenderingContext2D; toPx: (x: number, y: number) => readonly [number, number]; toWorld: (px: number, py: number) => [number, number]; W: number }) => {
    const plot = (fn: (x: number) => number, color: string, width: number, dash: boolean) => {
      ctx.strokeStyle = color; ctx.lineWidth = width;
      if (dash) ctx.setLineDash([5, 4]);
      ctx.beginPath();
      let pen = false;
      for (let i = 0; i <= w; i++) {
        const [xw] = toWorld(i, 0);
        const y = fn(xw);
        const [px, py] = toPx(xw, y);
        if (!pen) { ctx.moveTo(px, py); pen = true; } else ctx.lineTo(px, py);
      }
      ctx.stroke(); ctx.setLineDash([]);
    };
    plot(W.target, "#60a5fa", 2.2, true);
    plot(approx, "#2dd4bf", 2.4, false);
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <Stage2D onDraw={draw} deps={[wave, N]} />
      <aside className="space-y-3">
        <div className="card space-y-3 p-4">
          <div className="flex flex-wrap gap-1.5">
            {(Object.keys(FOURIER) as Wave[]).map((k) => (
              <button key={k} onClick={() => setWave(k)} className={`chip cursor-pointer ${wave === k ? "!border-accent !text-accent" : ""}`}>{FOURIER[k].fa}</button>
            ))}
          </div>
          <div className="rounded-xl bg-surface2 p-3"><TeX block>{W.tex}</TeX></div>
        </div>
        <div className="card space-y-2.5 p-4">
          <Slider label="تعداد هارمونیک‌ها N" value={N} min={1} max={51} step={2} onChange={(v) => setN(Math.round(v))} />
        </div>
        <div className="card p-4 text-xs leading-7">
          <div>بیشترین خطای نمونه‌گیری‌شده: <span className="font-mono text-[#f472b6]" dir="ltr">{maxErr.toFixed(4)}</span></div>
          <p className="mt-1 text-[11px] text-muted">
            نزدیک ناپیوستگی‌ها همیشه فراجهش ~۹٪ می‌ماند (پدیده‌ی گیبس) — هارمونیک‌های بیشتر آن را باریک‌تر می‌کند، ولی حذف نمی‌شود.
          </p>
        </div>
      </aside>
    </div>
  );
}
