"use client";

import { useEffect, useState } from "react";
import { useOrbitScene, clearGroup, parametricMesh } from "./orbit-scene";
import { Slider } from "@/components/lab-experiments";
import { TeX } from "@/components/katex";

type Q = "ellipsoid" | "cylinder" | "cone" | "elliptic-parab" | "hyperbolic-parab" | "hyperboloid1" | "hyperboloid2" | "general";

const DEFS: Record<Q, { fa: string; tex: string }> = {
  ellipsoid: { fa: "کره و بیض‌گون", tex: "\\frac{x^2}{a^2}+\\frac{y^2}{b^2}+\\frac{z^2}{c^2}=1" },
  cylinder: { fa: "استوانه", tex: "x^2 + y^2 = a^2, \\;\\; 0 \\le z \\le h" },
  cone: { fa: "کرهٔ دوگانه مخروط", tex: "z^2 = \\frac{c^2}{a^2}(x^2+y^2)" },
  "elliptic-parab": { fa: "سهموی بیضوی", tex: "z = \\frac{x^2}{a^2}+\\frac{y^2}{b^2}" },
  "hyperbolic-parab": { fa: "سهموی هذلولی (زین)", tex: "z = \\frac{x^2}{a^2}-\\frac{y^2}{b^2}" },
  hyperboloid1: { fa: "هذلولی‌گون یک‌پاره", tex: "\\frac{x^2}{a^2}+\\frac{y^2}{b^2}-\\frac{z^2}{c^2}=1" },
  hyperboloid2: { fa: "هذلولی‌گون دوپاره", tex: "-\\frac{x^2}{a^2}-\\frac{y^2}{b^2}+\\frac{z^2}{c^2}=1" },
  general: { fa: "فرم کلی درجهٔ دو", tex: "Ax^2+By^2+Cz^2 = K" },
};

export default function QuadricsModule() {
  const { mountRef, sceneRef, ready } = useOrbitScene();
  const [type, setType] = useState<Q>("ellipsoid");
  const [a, setA] = useState(2.2);
  const [b, setB] = useState(1.4);
  const [cc, setCc] = useState(2.6);
  const [K, setK] = useState(1);
  const [showAxes, setShowAxes] = useState<number>(0); // re-render trigger for rebuild

  const classify = () => {
    if (K === 0) return "مخروط / نقص‌یافته (K = 0)";
    const signs = [a, b, cc].map((x) => Math.sign(x)).filter((s) => s !== 0);
    const pos = signs.filter((s) => s > 0).length;
    if (signs.length < 3) return "استوانه/نقص‌یافته (یک ضریب صفر)";
    if (pos === 3) return K > 0 ? "بیض‌گون" : "مجموعهٔ تهی";
    if (pos === 0) return K < 0 ? "بیض‌گون" : "مجموعهٔ تهی";
    if (pos === 2) return K > 0 ? "هذلولی‌گون یک‌پاره" : "هذلولی‌گون دوپاره";
    return K > 0 ? "هذلولی‌گون دوپاره" : "هذلولی‌گون یک‌پاره";
  };

  useEffect(() => {
    const S = sceneRef.current;
    if (!ready || !S) return;
    clearGroup(S.group);
    const R = 3;
    let mesh: ReturnType<typeof parametricMesh> = null;
    if (type === "ellipsoid") {
      mesh = parametricMesh((u, v) => {
        const ph = u * Math.PI, th = v * 2 * Math.PI;
        return [a * Math.sin(ph) * Math.cos(th), b * Math.sin(ph) * Math.sin(th), cc * Math.cos(ph)];
      }, 40, 60, "#2dd4bf");
    } else if (type === "cylinder") {
      mesh = parametricMesh((u, v) => {
        const th = v * 2 * Math.PI;
        return [a * Math.cos(th), a * Math.sin(th), u * cc * 2 - cc];
      }, 10, 60, "#60a5fa");
    } else if (type === "cone") {
      mesh = parametricMesh((u, v) => {
        const z = (u * 2 - 1) * cc;
        const r = (a / Math.max(1e-6, cc)) * Math.abs(z);
        const th = v * 2 * Math.PI;
        return [r * Math.cos(th), r * Math.sin(th), z];
      }, 40, 60, "#fbbf24");
    } else if (type === "elliptic-parab") {
      mesh = parametricMesh((u, v) => {
        const x = (u * 2 - 1) * R, y = (v * 2 - 1) * R;
        return [x, y, (x * x) / (a * a) + (y * y) / (b * b)];
      }, 48, 48, "#2dd4bf");
    } else if (type === "hyperbolic-parab") {
      mesh = parametricMesh((u, v) => {
        const x = (u * 2 - 1) * R, y = (v * 2 - 1) * R;
        return [x, y, (x * x) / (a * a) - (y * y) / (b * b)];
      }, 48, 48, "#f472b6");
    } else if (type === "hyperboloid1") {
      mesh = parametricMesh((u, v) => {
        const U = u * 2.4 - 1.2, V = v * 2 * Math.PI;
        return [a * Math.cosh(U) * Math.cos(V), b * Math.cosh(U) * Math.sin(V), cc * Math.sinh(U)];
      }, 40, 60, "#a78bfa");
    } else if (type === "hyperboloid2") {
      const sheet = (sgn: 1 | -1) =>
        parametricMesh((u, v) => {
          const U = 0.15 + u * 1.1, V = v * 2 * Math.PI;
          return [a * Math.sinh(U) * Math.cos(V), b * Math.sinh(U) * Math.sin(V), sgn * cc * Math.cosh(U)];
        }, 36, 56, "#a78bfa");
      const m1 = sheet(1), m2 = sheet(-1);
      if (m1) S.group.add(m1);
      if (m2) S.group.add(m2);
    } else {
      // general: solve z = ± sqrt((K − A x² − B y²)/C)
      if (cc !== 0) {
        const maxZ = 4;
        const mk = (sgn: 1 | -1) =>
          parametricMesh((u, v) => {
            const x = (u * 2 - 1) * R, y = (v * 2 - 1) * R;
            const z2 = (K - a * x * x - b * y * y) / cc;
            if (z2 < 0) return null;
            const z = sgn * Math.sqrt(z2);
            if (Math.abs(z) > maxZ) return null;
            return [x, y, z];
          }, 56, 56, "#34d399");
        const m1 = mk(1);
        const m2 = mk(-1);
        if (m1) S.group.add(m1);
        if (m2) S.group.add(m2);
      }
    }
    if (mesh) S.group.add(mesh);
  }, [ready, type, a, b, cc, K, showAxes, sceneRef]);

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <div ref={mountRef} className="card overflow-hidden" />
      <aside className="space-y-3">
        <div className="card space-y-3 p-4">
          <div className="flex flex-wrap gap-1.5">
            {(Object.keys(DEFS) as Q[]).map((k) => (
              <button key={k} onClick={() => setType(k)} className={`chip cursor-pointer ${type === k ? "!border-accent !text-accent" : ""}`}>{DEFS[k].fa}</button>
            ))}
          </div>
          <div className="rounded-xl bg-surface2 p-3"><TeX block>{DEFS[type].tex}</TeX></div>
          {type === "general" && (
            <p className="rounded-lg bg-accentsoft/40 p-2 text-xs leading-6">
              طبقه‌بندی: <strong className="text-accent">{classify()}</strong>
            </p>
          )}
        </div>
        <div className="card space-y-2.5 p-4">
          <Slider label={type === "general" ? "A (ضریب x²)" : "a"} value={a} min={type === "general" ? -3 : 0.4} max={3} step={0.1} onChange={setA} />
          <Slider label={type === "general" ? "B (ضریب y²)" : "b"} value={b} min={type === "general" ? -3 : 0.4} max={3} step={0.1} onChange={setB} />
          <Slider label={type === "general" ? "C (ضریب z²)" : "c / h"} value={cc} min={type === "general" ? -3 : 0.4} max={4} step={0.1} onChange={setCc} />
          {type === "general" && <Slider label="K (سمت راست)" value={K} min={-4} max={4} step={0.5} onChange={setK} />}
        </div>
        <div className="card p-4 text-[11px] leading-6 text-muted">
          علامت ضرایب A، B، C و K نوع سطح درجهٔ دو را تعیین می‌کند. در هذلولی‌گون یک‌پاره، دو خانواده‌ی خط راسته
          (خط‌ساز) روی سطح قرار می‌گیرند. برش‌های موازی محورها مقاطع مخروطی دوبعدی می‌سازند — با ماژول دوبعدی مقایسه‌شان کنید.
        </div>
      </aside>
    </div>
  );
}
