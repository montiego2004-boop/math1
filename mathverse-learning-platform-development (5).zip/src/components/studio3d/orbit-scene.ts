"use client";

import { useEffect, useRef, useState, type RefObject } from "react";
import * as THREE from "three";

export interface OrbitScene {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  group: THREE.Group; // attach module meshes here
  sph: { th: number; ph: number; r: number };
}

/** Shared Three.js orbit scene — used by all 3D studio modules (loaded only on the 3D page). */
export function useOrbitScene({ grid = true, height = 480 }: { grid?: boolean; height?: number } = {}) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<OrbitScene | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(52, 1, 0.1, 400);
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    } catch {
      return; // graceful fallback: no WebGL
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    mount.appendChild(renderer.domElement);
    const group = new THREE.Group();
    scene.add(group);

    if (grid) {
      const g = new THREE.GridHelper(20, 20, 0x2dd4bf, 0x1c3355);
      (g.material as THREE.Material).transparent = true;
      (g.material as THREE.Material).opacity = 0.45;
      g.position.y = -0.01;
      scene.add(g);
    }
    const mkAxis = (dir: THREE.Vector3, color: number) => {
      const geo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0), dir]);
      return new THREE.Line(geo, new THREE.LineBasicMaterial({ color }));
    };
    scene.add(mkAxis(new THREE.Vector3(8, 0, 0), 0xf87171));
    scene.add(mkAxis(new THREE.Vector3(0, 8, 0), 0x4ade80));
    scene.add(mkAxis(new THREE.Vector3(0, 0, 8), 0x60a5fa));
    scene.add(new THREE.AmbientLight(0xffffff, 0.65));
    const dl = new THREE.DirectionalLight(0xffffff, 1.1);
    dl.position.set(6, 10, 4);
    scene.add(dl);

    const os: OrbitScene = { scene, camera, renderer, group, sph: { th: Math.PI / 4, ph: Math.PI / 3.2, r: 13 } };
    sceneRef.current = os;

    const resize = () => {
      const w = mount.clientWidth;
      const h = height;
      renderer.setSize(w, h);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();
    window.addEventListener("resize", resize);
    renderer.domElement.style.height = `${height}px`;

    let dragging = false;
    let px = 0, py = 0;
    const el = renderer.domElement;
    const down = (e: PointerEvent) => { dragging = true; px = e.clientX; py = e.clientY; el.setPointerCapture(e.pointerId); };
    const up = () => { dragging = false; };
    const move = (e: PointerEvent) => {
      if (!dragging) return;
      os.sph.th -= (e.clientX - px) * 0.008;
      os.sph.ph = Math.min(Math.PI - 0.1, Math.max(0.1, os.sph.ph - (e.clientY - py) * 0.008));
      px = e.clientX; py = e.clientY;
    };
    const wheel = (e: WheelEvent) => {
      e.preventDefault();
      os.sph.r = Math.min(60, Math.max(3, os.sph.r * (e.deltaY > 0 ? 1.1 : 0.9)));
    };
    el.addEventListener("pointerdown", down);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointermove", move);
    el.addEventListener("wheel", wheel, { passive: false });

    let raf = 0;
    const tick = () => {
      const { th, ph, r } = os.sph;
      camera.position.set(r * Math.sin(ph) * Math.cos(th), r * Math.cos(ph), r * Math.sin(ph) * Math.sin(th));
      camera.lookAt(0, 0, 0);
      renderer.render(scene, camera);
      raf = requestAnimationFrame(tick);
    };
    tick();
    setReady(true);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      el.removeEventListener("pointerdown", down);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointermove", move);
      el.removeEventListener("wheel", wheel);
      scene.traverse((o) => {
        const m = o as THREE.Mesh;
        m.geometry?.dispose?.();
        const mat = m.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
        else mat?.dispose?.();
      });
      renderer.dispose();
      mount.removeChild(el);
      sceneRef.current = null;
      setReady(false);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return { mountRef: mountRef as RefObject<HTMLDivElement | null>, sceneRef, ready };
}

/** Clear the module group and dispose geometries/materials. */
export function clearGroup(g: THREE.Group) {
  while (g.children.length) {
    const ch = g.children[0];
    g.remove(ch);
    const m = ch as THREE.Mesh;
    m.geometry?.dispose?.();
    const mat = m.material as THREE.Material | THREE.Material[] | undefined;
    if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
    else mat?.dispose?.();
  }
}

/** Build a parametric surface mesh: p(u,v) → [x,y(z-up screened),z] in math coords (x,y ground, z up). */
export function parametricMesh(
  p: (u: number, v: number) => [number, number, number] | null,
  nu: number,
  nv: number,
  color: string,
  opacity = 0.96
): THREE.Mesh | null {
  const verts: number[] = [];
  const cols: number[] = [];
  const idx: number[] = [];
  const base = new THREE.Color(color);
  let zmin = Infinity, zmax = -Infinity;
  const grid: ([number, number, number] | null)[][] = [];
  for (let i = 0; i <= nu; i++) {
    grid.push([]);
    for (let j = 0; j <= nv; j++) {
      const pt = p(i / nu, j / nv);
      grid[i][j] = pt;
      if (pt) { zmin = Math.min(zmin, pt[2]); zmax = Math.max(zmax, pt[2]); }
    }
  }
  const vIdx: number[][] = [];
  for (let i = 0; i <= nu; i++) {
    vIdx.push([]);
    for (let j = 0; j <= nv; j++) {
      const pt = grid[i][j];
      if (!pt) { vIdx[i][j] = -1; verts.push(0, 0, 0); cols.push(0, 0, 0); continue; }
      // math (x,y,z-up) → three (x, z-up, y)
      verts.push(pt[0], pt[2], pt[1]);
      const tt = zmax > zmin ? (pt[2] - zmin) / (zmax - zmin) : 0.5;
      const c = base.clone().offsetHSL(0.05 * (tt - 0.5), 0.1, 0.12 * (tt - 0.5));
      cols.push(c.r, c.g, c.b);
      vIdx[i][j] = verts.length / 3 - 1;
    }
  }
  let quads = 0;
  for (let i = 0; i < nu; i++) for (let j = 0; j < nv; j++) {
    const a = vIdx[i][j], b = vIdx[i + 1][j], c = vIdx[i][j + 1], d = vIdx[i + 1][j + 1];
    if (a < 0 || b < 0 || c < 0 || d < 0) continue;
    idx.push(a, b, d, a, d, c);
    quads++;
  }
  if (!quads) return null;
  const geo = new THREE.BufferGeometry();
  geo.setIndex(idx);
  geo.setAttribute("position", new THREE.Float32BufferAttribute(verts, 3));
  geo.setAttribute("color", new THREE.Float32BufferAttribute(cols, 3));
  geo.computeVertexNormals();
  const mat = new THREE.MeshStandardMaterial({ vertexColors: true, side: THREE.DoubleSide, metalness: 0.12, roughness: 0.6, transparent: true, opacity });
  return new THREE.Mesh(geo, mat);
}

export function mathLine(points: [number, number, number][], color: string, width = 2): THREE.Line {
  const pts = points.map(([x, y, z]) => new THREE.Vector3(x, z, y));
  const geo = new THREE.BufferGeometry().setFromPoints(pts);
  const mat = new THREE.LineBasicMaterial({ color });
  return new THREE.Line(geo, mat);
}

export function arrowAt(origin: [number, number, number], dir: [number, number, number], len: number, color: string): THREE.ArrowHelper {
  const d = new THREE.Vector3(dir[0], dir[2], dir[1]).normalize();
  const o = new THREE.Vector3(origin[0], origin[2], origin[1]);
  return new THREE.ArrowHelper(d, o, len, new THREE.Color(color).getHex(), len * 0.22, len * 0.1);
}
