"use client";

import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { create, all } from "mathjs";
import { Play, Pause } from "lucide-react";
import { useOrbitScene, clearGroup, parametricMesh, mathLine } from "./orbit-scene";
import { Slider, useLoop } from "@/components/lab-experiments";
import { TeX } from "@/components/katex";

const math = create(all);

type SurfPreset = "torus" | "mobius" | "helicoid" | "knot-shell" | "custom";
type CurvePreset = "helix" | "trefoil" | "viviani" | "custom";

/* ------------------------- Parametric surfaces ------------------------- */

export function SurfacePanel() {
  const { mountRef, sceneRef, ready } = useOrbitScene();
  const [preset, setPreset] = useState<SurfPreset>("torus");
  const [R, setR] = useState(2.4);
  const [rr, setRR] = useState(0.9);
  const [ex, setEx] = useState("(2 + cos(2πv)) * cos(2πu)");
  const [ey, setEy] = useState("(2 + cos(2πv)) * sin(2πu)");
  const [ez, setEz] = useState("sin(2πv)");
  const [err, setErr] = useState("");

  useEffect(() => {
    const S = sceneRef.current;
    if (!ready || !S) return;
    clearGroup(S.group);
    setErr("");
    let param: (u: number, v: number) => [number, number, number] | null;
    const r = rr;
    if (preset === "custom") {
      let cx, cy, cz;
      try {
        cx = math.compile(ex); cy = math.compile(ey); cz = math.compile(ez);
      } catch { setErr("خطا در تجزیهٔ عبارت سفارشی"); return; }
      param = (u, v) => {
        try {
          const x = cx.evaluate({ u, v }), y = cy.evaluate({ u, v }), z = cz.evaluate({ u, v });
          if (typeof x === "number" && typeof y === "number" && typeof z === "number" && isFinite(x) && isFinite(y) && isFinite(z) && Math.max(Math.abs(x), Math.abs(y), Math.abs(z)) < 100) return [x, y, z];
          return null;
        } catch { return null; }
      };
    } else if (preset === "torus") {
      param = (u, v) => {
        const U = u * 2 * Math.PI, V = v * 2 * Math.PI;
        return [(R + r * Math.cos(V)) * Math.cos(U), (R + r * Math.cos(V)) * Math.sin(U), r * Math.sin(V)];
      };
    } else if (preset === "mobius") {
      param = (u, v) => {
        const s = u * 2 * Math.PI, t = (v * 2 - 1) * r;
        return [(R + t * Math.cos(s / 2)) * Math.cos(s), (R + t * Math.cos(s / 2)) * Math.sin(s), t * Math.sin(s / 2)];
      };
    } else if (preset === "helicoid") {
      param = (u, v) => {
        const U = u * 4 * Math.PI, V = (v - 0.5) * 3 * R;
        return [V * Math.cos(U), V * Math.sin(U), r * U];
      };
    } else {
      param = (u, v) => {
        const U = u * 2 * Math.PI, V = v * Math.PI;
        const rad = R * (1 + 0.3 * Math.sin(3 * U) * Math.sin(2 * V));
        return [rad * Math.sin(V) * Math.cos(U), rad * Math.sin(V) * Math.sin(U), rad * Math.cos(V) * 0.7];
      };
    }
    const mesh = parametricMesh(param, 64, 64, preset === "mobius" ? "#f472b6" : preset === "helicoid" ? "#a78bfa" : "#2dd4bf");
    if (mesh) S.group.add(mesh);
    else if (!err) setErr("هیچ ناحیهٔ معتبری رندر نشد — دامنه را بررسی کنید.");
  }, [ready, preset, R, rr, ex, ey, ez, sceneRef]); // eslint-disable-line react-hooks/exhaustive-deps

  const tex =
    preset === "torus" ? "x=(R+r\\cos v)\\cos u,\\; y=(R+r\\cos v)\\sin u,\\; z=r\\sin v" :
    preset === "mobius" ? "x=(R+t\\cos\\tfrac{s}{2})\\cos s,\\;\\ldots,\\; z=t\\sin\\tfrac{s}{2}" :
    preset === "helicoid" ? "x=(v)\\cos u,\\; y=(v)\\sin u,\\; z=cu" :
    preset === "knot-shell" ? "\\text{پوستهٔ گرهم‌مانند}" : "x(u,v),\\; y(u,v),\\; z(u,v)";

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <div ref={mountRef} className="card overflow-hidden" />
      <aside className="space-y-3">
        <div className="card space-y-2.5 p-4">
          <div className="flex flex-wrap gap-1.5">
            {([["torus", "چنبره"], ["mobius", "نوار موبیوس"], ["helicoid", "مارپیچ‌وار"], ["knot-shell", "پوسته"], ["custom", "دلخواه"]] as const).map(([id, fa]) => (
              <button key={id} onClick={() => setPreset(id)} className={`chip cursor-pointer ${preset === id ? "!border-accent !text-accent" : ""}`}>{fa}</button>
            ))}
          </div>
          <div className="rounded-xl bg-surface2 p-2.5"><TeX block>{tex}</TeX></div>
          <Slider label="R" value={R} min={1} max={4} step={0.1} onChange={setR} />
          <Slider label="r / عرض" value={rr} min={0.2} max={1.6} step={0.05} onChange={setRR} />
          {preset === "custom" && (
            <>
              {([["x(u,v)", ex, setEx], ["y(u,v)", ey, setEy], ["z(u,v)", ez, setEz]] as const).map(([l, v, set]) => (
                <div key={l}>
                  <label className="text-[10px] text-muted" dir="ltr">{l}</label>
                  <input dir="ltr" className="input !py-1 font-mono text-xs" value={v} onChange={(e) => set(e.target.value)} />
                </div>
              ))}
              <p className="text-[10px] text-muted">u, v ∈ [0,1]؛ می‌توانید از π به صورت pi استفاده کنید.</p>
            </>
          )}
          {err && <p className="text-[11px] text-danger">{err}</p>}
        </div>
        <div className="card p-4 text-[11px] leading-6 text-muted">
          نوار موبیوس سطحی <strong>یک‌طرفه و نا-جهت‌پذیر</strong> است: بردار نرمال پس از یک دور کامل وارونه می‌شود.
          مارپیچ‌وار (helicoid) سطح مینیمال است — صفحه‌ی صابونِ کشیده‌شده بین دو مارپیچ.
        </div>
      </aside>
    </div>
  );
}

/* ---------------------------- Space curves ---------------------------- */

const CRv3 = (v: [number, number, number], w: [number, number, number]): [number, number, number] => [
  v[1] * w[2] - v[2] * w[1], v[2] * w[0] - v[0] * w[2], v[0] * w[1] - v[1] * w[0],
];
const CRn = (v: [number, number, number]) => Math.hypot(...v);

export function CurvePanel() {
  const { mountRef, sceneRef, ready } = useOrbitScene();
  const [preset, setPreset] = useState<CurvePreset>("helix");
  const [R, setR] = useState(2);
  const [b2, setB2] = useState(0.45);
  const [speed, setSpeed] = useState(0.5);
  const [running, setRunning] = useState(true);
  const [ex, setEx] = useState("2*cos(t)");
  const [ey, setEy] = useState("2*sin(t)");
  const [ez, setEz] = useState("0.3*t");
  const marker = useRef<{ t: number; T?: THREE.ArrowHelper; N?: THREE.ArrowHelper; B?: THREE.ArrowHelper; dot?: THREE.Mesh }>({ t: 0 });
  const [readout, setReadout] = useState({ kappa: 0, tau: 0, v: 0, t: 0 });
  const frame = useRef(0);

  const curveFn = (t: number): [number, number, number] => {
    if (preset === "helix") return [R * Math.cos(t), R * Math.sin(t), b2 * t - 2];
    if (preset === "trefoil") {
      return [(2 + Math.cos(3 * t)) * Math.cos(2 * t) * 0.6, (2 + Math.cos(3 * t)) * Math.sin(2 * t) * 0.6, Math.sin(3 * t) * 0.6];
    }
    if (preset === "viviani") {
      const s = t;
      return [R * (1 + Math.cos(s)) - R, R * Math.sin(s), 2 * R * Math.sin(s / 2) * 0.8];
    }
    try {
      const x = math.evaluate(ex, { t, pi: Math.PI });
      const y = math.evaluate(ey, { t, pi: Math.PI });
      const z = math.evaluate(ez, { t, pi: Math.PI });
      if (typeof x === "number" && typeof y === "number" && typeof z === "number") return [x, y, z];
    } catch {}
    return [0, 0, 0];
  };

  const window = preset === "helix" ? [0, 4 * Math.PI] : preset === "custom" ? [0, 6 * Math.PI] : [0, 2 * Math.PI];

  useEffect(() => {
    const S = sceneRef.current;
    if (!ready || !S) return;
    clearGroup(S.group);
    const pts: [number, number, number][] = [];
    const [t0, t1] = window;
    for (let i = 0; i <= 1100; i++) pts.push(curveFn(t0 + ((t1 - t0) * i) / 1100));
    S.group.add(mathLine(pts, "#2dd4bf", 2));
    // persistent marker objects (scene-level, survive rebuilds)…
    if (!marker.current.T) {
      const T = new THREE.ArrowHelper(new THREE.Vector3(1, 0, 0), new THREE.Vector3(), 1, 0x2dd4bf);
      const N = new THREE.ArrowHelper(new THREE.Vector3(1, 0, 0), new THREE.Vector3(), 1, 0xf472b6);
      const B = new THREE.ArrowHelper(new THREE.Vector3(1, 0, 0), new THREE.Vector3(), 1, 0xfbbf24);
      const dot = new THREE.Mesh(new THREE.SphereGeometry(0.09, 16, 16), new THREE.MeshStandardMaterial({ color: 0xf472b6 }));
      S.scene.add(T, N, B, dot);
      marker.current = { t: 0, T, N, B, dot };
    }
    marker.current.t = window[0];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, preset, R, b2, ex, ey, ez]);

  useEffect(() => {
    const S = sceneRef.current;
    if (!ready || !S) return;
    return () => {
      // keep markers across rerenders but clean on unmount
    };
  }, [ready, sceneRef]);

  const rPrime = (t: number, h = 1e-3): [number, number, number] => {
    const p = curveFn(t + h), m = curveFn(t - h);
    return [(p[0] - m[0]) / (2 * h), (p[1] - m[1]) / (2 * h), (p[2] - m[2]) / (2 * h)];
  };
  const rSecond = (t: number, h = 1e-3): [number, number, number] => {
    const p = curveFn(t + h), c0 = curveFn(t), m = curveFn(t - h);
    return [(p[0] - 2 * c0[0] + m[0]) / (h * h), (p[1] - 2 * c0[1] + m[1]) / (h * h), (p[2] - 2 * c0[2] + m[2]) / (h * h)];
  };
  const rThird = (t: number, h = 2e-3): [number, number, number] => {
    const p = rSecond(t + h), m = rSecond(t - h);
    return [(p[0] - m[0]) / (2 * h), (p[1] - m[1]) / (2 * h), (p[2] - m[2]) / (2 * h)];
  };

  useLoop((dt) => {
    const M = marker.current;
    const S = sceneRef.current;
    if (!M.T || !S || !ready) return;
    const [t0, t1] = window;
    M.t += dt * speed * 2;
    if (M.t > t1) M.t = t0;
    const t = Math.max(t0 + 0.02, M.t);
    const p = curveFn(t);
    const rp = rPrime(t);
    const rsp = rSecond(t);
    const v = CRn(rp);
    const cross = CRv3(rp, rsp);
    const kappa = v > 1e-9 ? CRn(cross) / v ** 3 : 0;
    const rtp = rThird(t);
    const tauDenom = CRn(cross) ** 2;
    const tau = tauDenom > 1e-12 ? (cross[0] * rtp[0] + cross[1] * rtp[1] + cross[2] * rtp[2]) / tauDenom : 0;
    // Frenet frame
    const Tn: [number, number, number] = v > 1e-9 ? [rp[0] / v, rp[1] / v, rp[2] / v] : [1, 0, 0];
    const Bn0: [number, number, number] = CRn(cross) > 1e-9 ? cross : [0, 0, 1];
    const Bm = CRn(Bn0);
    const Bn: [number, number, number] = [Bn0[0] / Bm, Bn0[1] / Bm, Bn0[2] / Bm];
    const Nn = CRv3(Bn, Tn);
    const setA = (A: THREE.ArrowHelper, dir: [number, number, number], len: number) => {
      A.position.set(p[0], p[2], p[1]);
      A.setDirection(new THREE.Vector3(dir[0], dir[2], dir[1]).normalize());
      A.setLength(len, len * 0.25, len * 0.14);
    };
    setA(M.T, Tn, 1.2);
    setA(M.N!, Nn, 1.0);
    setA(M.B!, Bn, 1.0);
    M.dot!.position.set(p[0], p[2], p[1]);
    if (frame.current++ % 8 === 0) setReadout({ kappa, tau, v, t });
  }, running && ready);

  const texMap: Record<CurvePreset, string> = {
    helix: "r(t)=(R\\cos t,\\; R\\sin t,\\; bt)",
    trefoil: "r(t)=((2+\\cos 3t)\\cos 2t,\\;,\\ldots)",
    viviani: "\\text{برخورد استوانه و کره (منحنی ویویانی)}",
    custom: "r(t) = (x(t), y(t), z(t))",
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <div ref={mountRef} className="card overflow-hidden" />
      <aside className="space-y-3">
        <div className="card space-y-2.5 p-4">
          <div className="flex flex-wrap gap-1.5">
            {([["helix", "مارپیچ"], ["trefoil", "گره سه‌برگی"], ["viviani", "ویویانی"], ["custom", "دلخواه"]] as const).map(([id, fa]) => (
              <button key={id} onClick={() => setPreset(id)} className={`chip cursor-pointer ${preset === id ? "!border-accent !text-accent" : ""}`}>{fa}</button>
            ))}
          </div>
          <TeX block>{texMap[preset]}</TeX>
          <Slider label="R" value={R} min={0.8} max={3.5} step={0.1} onChange={setR} />
          {preset === "helix" && <Slider label="گام b" value={b2} min={0.1} max={1.2} step={0.05} onChange={setB2} />}
          <Slider label="سرعت حرکت نقطه" value={speed} min={0} max={2} step={0.1} onChange={setSpeed} />
          <button className="btn w-full justify-center !text-xs" onClick={() => setRunning((r) => !r)}>
            {running ? <Pause className="size-3.5" /> : <Play className="size-3.5" />} قاب فرنه (T,N,B)
          </button>
          {preset === "custom" && (
            <>
              {([["x(t)", ex, setEx], ["y(t)", ey, setEy], ["z(t)", ez, setEz]] as const).map(([l, v, set]) => (
                <div key={l}>
                  <label className="text-[10px] text-muted" dir="ltr">{l}</label>
                  <input dir="ltr" className="input !py-1 font-mono text-xs" value={v} onChange={(e) => set(e.target.value)} />
                </div>
              ))}
            </>
          )}
        </div>
        <div className="card space-y-1 p-4 text-xs leading-7">
          <h4 className="mb-1 font-bold">چارچوب فرنه (تفاضل مرکزی — تقریبی):</h4>
          <div className="flex justify-between"><span className="text-muted">تندی |r′|:</span><span className="font-mono" dir="ltr">{readout.v.toFixed(3)}</span></div>
          <div className="flex justify-between"><span className="text-muted">انحنا κ:</span><span className="font-mono" dir="ltr">{readout.kappa.toFixed(3)}</span></div>
          <div className="flex justify-between"><span className="text-muted">پیچش τ:</span><span className="font-mono" dir="ltr">{readout.tau.toFixed(3)}</span></div>
          <TeX block>{"\\kappa = \\frac{|r'\\times r''|}{|r'|^3}, \\qquad \\tau = \\frac{(r'\\times r'')\\cdot r'''}{|r'\\times r''|^2}"}</TeX>
          <p className="text-[10px] leading-5 text-muted">T فیروزه‌ای، N صورتی (به‌سوی مرکز انحنا)، B زرد. برای مارپیچ κ و τ ثابت‌اند.</p>
        </div>
      </aside>
    </div>
  );
}

export default function ParametricModule() {
  const [tab, setTab] = useState<"surface" | "curve">("surface");
  return (
    <div>
      <div className="mb-4 flex gap-2">
        <button className={`btn !text-xs ${tab === "surface" ? "!border-accent !text-accent" : ""}`} onClick={() => setTab("surface")}>سطوح پارامتری</button>
        <button className={`btn !text-xs ${tab === "curve" ? "!border-accent !text-accent" : ""}`} onClick={() => setTab("curve")}>خم‌های فضایی و قاب فرنه</button>
      </div>
      {tab === "surface" ? <SurfacePanel /> : <CurvePanel />}
    </div>
  );
}
