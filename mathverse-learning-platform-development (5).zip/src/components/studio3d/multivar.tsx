"use client";

import { useEffect, useMemo, useState } from "react";
import * as THREE from "three";
import { create, all } from "mathjs";
import { useOrbitScene, clearGroup, parametricMesh, mathLine, arrowAt } from "./orbit-scene";
import { Slider } from "@/components/lab-experiments";
import { TeX } from "@/components/katex";

const math = create(all);

export default function MultivarModule() {
  const { mountRef, sceneRef, ready } = useOrbitScene();
  const [expr, setExpr] = useState("sin(sqrt(x^2 + y^2))");
  const [R, setR] = useState(3);
  const [showContour, setShowContour] = useState(true);
  const [crossX, setCrossX] = useState(1.2);
  const [tx, setTx] = useState(0.8);
  const [ty, setTy] = useState(0.6);
  const [err, setErr] = useState("");

  const f = useMemo(() => {
    try {
      const c = math.compile(expr);
      return (x: number, y: number) => {
        try {
          const v = c.evaluate({ x, y });
          return typeof v === "number" && isFinite(v) && Math.abs(v) < 1e6 ? v : null;
        } catch { return null; }
      };
    } catch { return null; }
  }, [expr]);

  const eps = 1e-3;
  const partials = useMemo(() => {
    if (!f) return null;
    const f0 = f(tx, ty);
    if (f0 == null) return null;
    const fx = (f(tx + eps, ty) ?? NaN) - (f(tx - eps, ty) ?? NaN);
    const fy = (f(tx, ty + eps) ?? NaN) - (f(tx, ty - eps) ?? NaN);
    const _fx = fx / (2 * eps), _fy = fy / (2 * eps);
    if (!isFinite(_fx) || !isFinite(_fy)) return null;
    return { f0, fx: _fx, fy: _fy };
  }, [f, tx, ty]);

  // numeric double integral over [-R,R]^2 (midpoint rule, n×n) — reference
  const vol = useMemo(() => {
    if (!f) return null;
    const n = 80;
    const h = (2 * R) / n;
    let s = 0, cnt = 0;
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
      const v = f(-R + (i + 0.5) * h, -R + (j + 0.5) * h);
      if (v != null) { s += v; cnt++; }
    }
    return { approx: s * h * h, cells: cnt };
  }, [f, R]);

  useEffect(() => {
    const S = sceneRef.current;
    if (!ready || !S) return;
    clearGroup(S.group);
    setErr("");
    if (!f) { setErr("خطا در تجزیهٔ عبارت"); return; }
    // surface
    const mesh = parametricMesh((u, v) => {
      const x = (u * 2 - 1) * R, y = (v * 2 - 1) * R;
      const z = f(x, y);
      return z == null ? null : [x, y, z];
    }, 72, 72, "#2dd4bf", 0.92);
    if (mesh) S.group.add(mesh);

    // z-range for contour placement
    let zmin = Infinity, zmax = -Infinity;
    const GN = 64;
    const grid: (number | null)[][] = [];
    for (let i = 0; i <= GN; i++) {
      grid.push([]);
      for (let j = 0; j <= GN; j++) {
        const x = -R + (2 * R * i) / GN, y = -R + (2 * R * j) / GN;
        const z = f(x, y);
        grid[i][j] = z;
        if (z != null) { zmin = Math.min(zmin, z); zmax = Math.max(zmax, z); }
      }
    }
    const baseZ = zmin === Infinity ? -3 : zmin - 0.6;

    // contour lines (marching squares), projected below surface
    if (showContour && zmin !== Infinity) {
      const K = 9;
      const pts: THREE.Vector3[] = [];
      const colors: number[] = [];
      const c1 = new THREE.Color("#60a5fa"), c2 = new THREE.Color("#f472b6");
      for (let lv = 0; lv < K; lv++) {
        const iso = zmin + ((zmax - zmin) * (lv + 0.5)) / K;
        const col = c1.clone().lerp(c2, lv / (K - 1));
        for (let i = 0; i < GN; i++) for (let j = 0; j < GN; j++) {
          const x0 = -R + (2 * R * i) / GN, x1 = -R + (2 * R * (i + 1)) / GN;
          const y0 = -R + (2 * R * j) / GN, y1 = -R + (2 * R * (j + 1)) / GN;
          const v00 = grid[i][j], v10 = grid[i + 1][j], v01 = grid[i][j + 1], v11 = grid[i + 1][j + 1];
          if (v00 == null || v10 == null || v01 == null || v11 == null) continue;
          const edges: [number, number, number, number][] = [
            [x0, y0, x1, y0], [x1, y0, x1, y1], [x0, y1, x1, y1], [x0, y0, x0, y1],
          ];
          const vals = [v00, v10, v11, v01];
          const ints: THREE.Vector3[] = [];
          edges.forEach(([ax, ay, bx, by], ei) => {
            const va = vals[[0, 1, 3, 3][ei]], vb = vals[[1, 2, 2, 0][ei]];
            if ((va - iso) * (vb - iso) < 0) {
              const t = (iso - va) / (vb - va);
              ints.push(new THREE.Vector3(ax + (bx - ax) * t, baseZ, ay + (by - ay) * t));
            }
          });
          if (ints.length === 2) {
            pts.push(ints[0], ints[1]);
            colors.push(col.r, col.g, col.b, col.r, col.g, col.b);
          }
        }
      }
      const geo = new THREE.BufferGeometry().setFromPoints(pts);
      geo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
      S.group.add(new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, opacity: 0.85 })));
    }

    // cross-section x = crossX: plane + intersection curve
    {
      const plane = new THREE.Mesh(
        new THREE.PlaneGeometry(2 * R, Math.max(1, (zmax === -Infinity ? 6 : Math.max(4, zmax - zmin + 2)))),
        new THREE.MeshBasicMaterial({ color: "#fbbf24", transparent: true, opacity: 0.08, side: THREE.DoubleSide })
      );
      plane.position.set(crossX, 0, 0);
      plane.rotation.y = Math.PI / 2;
      S.group.add(plane);
      const curve: [number, number, number][] = [];
      for (let i = 0; i <= 200; i++) {
        const y = -R + (2 * R * i) / 200;
        const z = f(crossX, y);
        if (z != null) curve.push([crossX, y, z]);
      }
      if (curve.length > 1) S.group.add(mathLine(curve, "#fbbf24", 2.5));
    }

    // tangent plane + gradient + normal at (tx,ty)
    if (partials) {
      const { f0, fx, fy } = partials;
      const S2 = 0.9;
      const tp = parametricMesh((u, v) => {
        const px = tx + (u * 2 - 1) * S2, py = ty + (v * 2 - 1) * S2;
        return [px, py, f0 + fx * (px - tx) + fy * (py - ty)];
      }, 4, 4, "#f472b6", 0.55);
      if (tp) S.group.add(tp);
      S.group.add(arrowAt([tx, ty, f0], [-fx, -fy, 1], 1.6, "#f472b6")); // normal
      S.group.add(arrowAt([tx, ty, f0], [fx, fy, 0], 1.4, "#fbbf24")); // gradient (in surface direction)
    }
  }, [ready, f, R, showContour, crossX, tx, ty, partials, sceneRef]);

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <div ref={mountRef} className="card overflow-hidden" />
      <aside className="space-y-3">
        <div className="card space-y-2.5 p-4">
          <label className="block text-[11px] font-bold text-muted">z = f(x, y)</label>
          <input dir="ltr" className="input !py-1.5 font-mono text-xs" value={expr} onChange={(e) => setExpr(e.target.value)} />
          <div className="flex flex-wrap gap-1.5">
            {["sin(sqrt(x^2+y^2))", "x^2 - y^2", "exp(-(x^2+y^2)/2)", "sin(x)*cos(y)"].map((p) => (
              <button key={p} className="chip cursor-pointer font-mono hover:!border-accent" dir="ltr" onClick={() => setExpr(p)}>{p}</button>
            ))}
          </div>
          <Slider label="برد ±R" value={R} min={1.5} max={6} step={0.5} onChange={setR} />
          <label className="flex cursor-pointer items-center gap-2 text-xs">
            <input type="checkbox" checked={showContour} onChange={(e) => setShowContour(e.target.checked)} /> خطوط هم‌تراز (contour)
          </label>
          <Slider label="صفحهٔ برش x = x₀" value={crossX} min={-3} max={3} step={0.1} onChange={setCrossX} />
          <Slider label="نقطهٔ تماس x₀" value={tx} min={-2.5} max={2.5} step={0.05} onChange={setTx} />
          <Slider label="y₀" value={ty} min={-2.5} max={2.5} step={0.05} onChange={setTy} />
        </div>
        <div className="card space-y-1.5 p-4 text-xs leading-7">
          <h4 className="font-bold">خوانش در نقطهٔ تماس (تفاضل مرکزی — تقریبی):</h4>
          {partials ? (
            <>
              <div dir="ltr" className="font-mono">f(x₀,y₀) = {partials.f0.toFixed(3)}</div>
              <div dir="ltr" className="font-mono">∂f/∂x ≈ {partials.fx.toFixed(3)}</div>
              <div dir="ltr" className="font-mono">∂f/∂y ≈ {partials.fy.toFixed(3)}</div>
              <div dir="ltr" className="font-mono">|∇f| ≈ {Math.hypot(partials.fx, partials.fy).toFixed(3)}</div>
              {Math.hypot(partials.fx, partials.fy) < 0.05 && <p className="text-accent">نزدیک نقطهٔ بحرانی (∇f ≈ 0): بیشینه/کمینه/زین موضعی</p>}
            </>
          ) : <p className="text-muted">—</p>}
          <TeX block>{"z = f_0 + f_x(x-x_0) + f_y(y-y_0) \\;\\; \\text{(صفحهٔ مماس)}"}</TeX>
        </div>
        <div className="card p-4 text-xs leading-7">
          <h4 className="mb-1 font-bold">انتگرال دوگانه روی [−R,R]² (قاعدهٔ میان‌نقطه n×n — تقریبی):</h4>
          {vol && <div dir="ltr" className="font-mono">∫∫ f dA ≈ {vol.approx.toFixed(4)} ({vol.cells} × سلول معتبر)</div>}
        </div>
        {err && <p className="text-[11px] text-danger">{err}</p>}
      </aside>
    </div>
  );
}
