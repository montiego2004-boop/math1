"use client";

import { useEffect, useMemo, useState } from "react";
import * as THREE from "three";
import { create, all } from "mathjs";
import { useOrbitScene, clearGroup, mathLine } from "./orbit-scene";
import { Slider, rk4 } from "@/components/lab-experiments";
import { TeX } from "@/components/katex";

const math = create(all);

export default function Vector3DModule() {
  const { mountRef, sceneRef, ready } = useOrbitScene();
  const [px, setPx] = useState("-y");
  const [py, setPy] = useState("x");
  const [pz, setPz] = useState("0");
  const [qx, setQx] = useState(1);
  const [qy, setQy] = useState(0.5);
  const [qz, setQz] = useState(0.5);
  const [dres, setDres] = useState(5);

  const comp = useMemo(() => {
    try {
      const cP = math.compile(px);
      const cQ = math.compile(py);
      const cR = math.compile(pz);
      return (x: number, y: number, z: number): [number, number, number] | null => {
        try {
          const a = cP.evaluate({ x, y, z }), b = cQ.evaluate({ x, y, z }), c = cR.evaluate({ x, y, z });
          if (typeof a === "number" && typeof b === "number" && typeof c === "number" && isFinite(a) && isFinite(b) && isFinite(c)) return [a, b, c];
          return null;
        } catch { return null; }
      };
    } catch { return null; }
  }, [px, py, pz]);

  // divergence & curl at probe (central differences)
  const probe = useMemo(() => {
    if (!comp) return null;
    const h = 1e-3;
    const [x, y, z] = [qx, qy, qz];
    const fp = (dx: number, dy: number, dz: number) => comp(x + dx, y + dy, z + dz);
    const g = (idx: 0 | 1 | 2, dx: number, dy: number, dz: number) => {
      const a = fp(dx, dy, dz)?.[idx], b = fp(-dx, -dy, -dz)?.[idx];
      if (a == null || b == null) return NaN;
      return (a - b) / (2 * h);
    };
    const dPdx = g(0, h, 0, 0), dPdy = g(0, 0, h, 0), dPdz = g(0, 0, 0, h);
    const dQdx = g(1, h, 0, 0), dQdy = g(1, 0, h, 0), dQdz = g(1, 0, 0, h);
    const dRdx = g(2, h, 0, 0), dRdy = g(2, 0, h, 0), dRdz = g(2, 0, 0, h);
    if ([dPdx, dPdy, dPdz, dQdx, dQdy, dQdz, dRdx, dRdy, dRdz].some((v) => !isFinite(v))) return null;
    const div = dPdx + dQdy + dRdz;
    const curl: [number, number, number] = [dRdy - dQdz, dPdz - dRdx, dQdx - dPdy];
    // flux through a small cube around probe (surface integral, midpoint samples per face)
    const s = 0.6;
    const n = 6;
    let flux = 0;
    const dA = ((2 * s) / n) ** 2;
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
      const t = -s + ((i + 0.5) * 2 * s) / n;
      const u = -s + ((j + 0.5) * 2 * s) / n;
      const samples: [number, number, number, [number, number, number]][] = [
        [x + s, y + t, z + u, [1, 0, 0]],
        [x - s, y + t, z + u, [-1, 0, 0]],
        [x + t, y + s, z + u, [0, 1, 0]],
        [x + t, y - s, z + u, [0, -1, 0]],
        [x + t, y + u, z + s, [0, 0, 1]],
        [x + t, y + u, z - s, [0, 0, -1]],
      ];
      for (const [sx, sy, sz, nn] of samples) {
        const F = comp(sx, sy, sz);
        if (F) flux += (F[0] * nn[0] + F[1] * nn[1] + F[2] * nn[2]) * dA;
      }
    }
    return { div, curl, flux };
  }, [comp, qx, qy, qz]);

  useEffect(() => {
    const S = sceneRef.current;
    if (!ready || !S || !comp) return;
    clearGroup(S.group);

    // arrows grid
    const n = dres;
    let maxM = 1e-9;
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) for (let k = 0; k < n; k++) {
      const F = comp(-2 + (4 * i) / (n - 1), -2 + (4 * j) / (n - 1), -2 + (4 * k) / (n - 1));
      if (F) maxM = Math.max(maxM, Math.min(8, Math.hypot(...F)));
    }
    const positions: number[] = [];
    const cols: number[] = [];
    const cLow = new THREE.Color("#2dd4bf"), cHigh = new THREE.Color("#f472b6");
    const arrowHeads: number[] = [];
    const arrowHeadCols: number[] = [];
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) for (let k = 0; k < n; k++) {
      const x = -2 + (4 * i) / (n - 1), y = -2 + (4 * j) / (n - 1), z = -2 + (4 * k) / (n - 1);
      const F = comp(x, y, z);
      if (!F) continue;
      const m = Math.hypot(...F);
      if (m < 1e-9 || !isFinite(m)) continue;
      const u = Math.min(1, m / maxM);
      const len = 0.28 + 0.22 * u;
      const dir: [number, number, number] = [F[0] / m, F[1] / m, F[2] / m];
      const c = cLow.clone().lerp(cHigh, u);
      positions.push(x, z, y, x + dir[0] * len, z + dir[2] * len, y + dir[1] * len);
      cols.push(c.r, c.g, c.b, c.r, c.g, c.b);
      // little head segment
      const tip: [number, number, number] = [x + dir[0] * len, y + dir[1] * len, z + dir[2] * len];
      const back: [number, number, number] = [tip[0] - dir[0] * 0.09, tip[1] - dir[1] * 0.09, tip[2] - dir[2] * 0.09];
      arrowHeads.push(back[0], back[2], back[1], tip[0], tip[2], tip[1]);
      arrowHeadCols.push(c.r, c.g, c.b, c.r, c.g, c.b);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute("color", new THREE.Float32BufferAttribute(cols, 3));
    S.group.add(new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, opacity: 0.9 })));
    const hgeo = new THREE.BufferGeometry();
    hgeo.setAttribute("position", new THREE.Float32BufferAttribute(arrowHeads, 3));
    hgeo.setAttribute("color", new THREE.Float32BufferAttribute(arrowHeadCols, 3));
    S.group.add(new THREE.LineSegments(hgeo, new THREE.LineBasicMaterial({ vertexColors: true })));

    // probe point + streamline (RK4)
    const probeMesh = new THREE.Mesh(new THREE.SphereGeometry(0.09, 16, 16), new THREE.MeshStandardMaterial({ color: 0xfbbf24 }));
    probeMesh.position.set(qx, qz, qy);
    S.group.add(probeMesh);
    if (probe) {
      const box = new THREE.LineSegments(
        new THREE.EdgesGeometry(new THREE.BoxGeometry(1.2, 1.2, 1.2)),
        new THREE.LineBasicMaterial({ color: 0xfbbf24 })
      );
      box.position.set(qx, qz, qy);
      S.group.add(box);
    }
    let p: [number, number, number] = [qx, qy, qz];
    const pts: [number, number, number][] = [p];
    const field = (_t: number, y: number[]) => {
      const F = comp(y[0], y[1], y[2]) ?? [0, 0, 0];
      return F;
    };
    for (let i = 0; i < 500; i++) {
      p = rk4(p, field, 0, 0.04) as [number, number, number];
      if (Math.max(Math.abs(p[0]), Math.abs(p[1]), Math.abs(p[2])) > 3.5) break;
      pts.push(p);
    }
    S.group.add(mathLine(pts, "#f472b6", 2));
  }, [ready, comp, qx, qy, qz, probe, dres, sceneRef]);

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <div ref={mountRef} className="card overflow-hidden" />
      <aside className="space-y-3">
        <div className="card space-y-2 p-4">
          {([["P(x,y,z)", px, setPx], ["Q(x,y,z)", py, setPy], ["R(x,y,z)", pz, setPz]] as const).map(([l, v, set]) => (
            <div key={l}>
              <label className="text-[10px] text-muted" dir="ltr">{l}</label>
              <input dir="ltr" className="input !py-1 font-mono text-xs" value={v} onChange={(e) => set(e.target.value)} />
            </div>
          ))}
          <div className="flex flex-wrap gap-1.5">
            {[
              ["چرخهٔ حول z", "-y", "x", "0"],
              ["چشمه", "x", "y", "z"],
              ["چرخهٔ ۳بعدی", "-y", "x", "0.5"],
              ["فرومیریجه", "-x", "-y", "-z"],
            ].map(([fa, a, b, c]) => (
              <button key={fa} className="chip cursor-pointer hover:!border-accent" onClick={() => { setPx(a); setPy(b); setPz(c); }}>{fa}</button>
            ))}
          </div>
          <Slider label="چگالی فلش‌ها" value={dres} min={4} max={8} step={1} onChange={(v) => setDres(Math.round(v))} />
          <Slider label="پروب x" value={qx} min={-2} max={2} step={0.1} onChange={setQx} />
          <Slider label="پروب y" value={qy} min={-2} max={2} step={0.1} onChange={setQy} />
          <Slider label="پروب z" value={qz} min={-2} max={2} step={0.1} onChange={setQz} />
        </div>
        <div className="card space-y-1.5 p-4 text-xs leading-7">
          <h4 className="mb-1 font-bold">در نقطهٔ پروب (زرد):</h4>
          {probe ? (
            <>
              <div dir="ltr" className="font-mono">div F ≈ {probe.div.toFixed(3)}</div>
              <div dir="ltr" className="font-mono">curl F ≈ ({probe.curl.map((v) => v.toFixed(3)).join(", ")})</div>
              <div dir="ltr" className="font-mono">∯ F·dA (مکعب) ≈ {probe.flux.toFixed(3)}</div>
              <p className="text-[10px] leading-5 text-muted">قضیهٔ واگرایی: شار خالص از مکعب ≈ div F × حجم مکعب = {(probe.div * 1.728).toFixed(3)} م {probe.flux.toFixed(3)}</p>
            </>
          ) : <p className="text-muted">—</p>}
          <TeX block>{"\\nabla\\cdot\\vec F, \\qquad \\nabla\\times\\vec F"}</TeX>
        </div>
      </aside>
    </div>
  );
}
