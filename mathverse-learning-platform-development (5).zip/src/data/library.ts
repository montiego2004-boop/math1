export interface Resource {
  id: string;
  title: string;
  author: string;
  subject: "math" | "physics" | "stats" | "general";
  level: string;
  lang: string;
  type: string;
  license: string;
  url: string;
  note: string;
}

/* Only genuine, legally open resources are listed. Licenses were taken
   from each publisher's official page. When re-hosting is not allowed,
   we link to the original source instead of copying files. */

export const RESOURCE_TYPES = ["همه", "کتاب درسی", "جزوه/یادداشت", "دوره دانشگاهی", "درگاه جست‌وجو", "اثر کلاسیک"] as const;
export const RESOURCE_SUBJECTS = [
  { id: "all", fa: "همه موضوع‌ها" },
  { id: "math", fa: "ریاضیات" },
  { id: "physics", fa: "فیزیک" },
  { id: "stats", fa: "آمار و احتمال" },
  { id: "general", fa: "منابع عمومی" },
];

export const LIBRARY: Resource[] = [
  {
    id: "r1", title: "Calculus Volume 1", author: "OpenStax (Gilbert Strang, Edwin Herman و همکاران)",
    subject: "math", level: "دانشگاهی", lang: "انگلیسی", type: "کتاب درسی",
    license: "CC BY-NC-SA 4.0", url: "https://openstax.org/details/books/calculus-volume-1",
    note: "جلد اول حسابان: حد، مشتق، کاربرد مشتق و انتگرال. PDF رایگان از سایت OpenStax.",
  },
  {
    id: "r2", title: "Calculus Volume 2", author: "OpenStax",
    subject: "math", level: "دانشگاهی", lang: "انگلیسی", type: "کتاب درسی",
    license: "CC BY-NC-SA 4.0", url: "https://openstax.org/details/books/calculus-volume-2",
    note: "کاربردهای انتگرال، تکنیک‌های انتگرال‌گیری، سری‌ها و مختصات قطبی.",
  },
  {
    id: "r3", title: "Calculus Volume 3", author: "OpenStax",
    subject: "math", level: "دانشگاهی", lang: "انگلیسی", type: "کتاب درسی",
    license: "CC BY-NC-SA 4.0", url: "https://openstax.org/details/books/calculus-volume-3",
    note: "حسابان چندمتغیره: بردارها، مشتقات جزئی، انتگرال‌های چندگانه و حساب برداری.",
  },
  {
    id: "r4", title: "Algebra and Trigonometry 2e", author: "OpenStax",
    subject: "math", level: "دبیرستان/پیش‌دانشگاهی", lang: "انگلیسی", type: "کتاب درسی",
    license: "CC BY 4.0", url: "https://openstax.org/details/books/algebra-and-trigonometry-2e",
    note: "جبر و مثلثات با تمرین‌های فراوان؛ منبع اصلی درس‌های سطح A و B.",
  },
  {
    id: "r5", title: "Linear Algebra (دوره ۱۸٫۰۶)", author: "MIT OpenCourseWare — Gilbert Strang",
    subject: "math", level: "دانشگاهی", lang: "انگلیسی", type: "دوره دانشگاهی",
    license: "CC BY-NC-SA 4.0", url: "https://ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/",
    note: "دوره‌ی افسانه‌ای جبرخطی استرنگ با ویدیو، تمرین و امتحان‌های واقعی MIT.",
  },
  {
    id: "r6", title: "Single Variable Calculus (دوره ۱۸٫۰۱)", author: "MIT OpenCourseWare",
    subject: "math", level: "دانشگاهی", lang: "انگلیسی", type: "دوره دانشگاهی",
    license: "CC BY-NC-SA 4.0", url: "https://ocw.mit.edu/courses/18-01sc-single-variable-calculus-fall-2010/",
    note: "حسابان تک‌متغیره با یادداشت‌های کامل، تمرین حل‌شده و آزمون.",
  },
  {
    id: "r7", title: "CLP Calculus (جلدهای ۱ تا ۴)", author: "Joel Feldman, Andrew Rechnitzer, Elyse Yeager — UBC",
    subject: "math", level: "دانشگاهی", lang: "انگلیسی", type: "کتاب درسی",
    license: "CC BY-NC-SA 4.0", url: "https://personal.math.ubc.ca/~CLP/",
    note: "کتاب‌های آزاد حسابان دانشگاه بریتیش‌کلمبیا با PDF رایگان و تمرین حل‌شده.",
  },
  {
    id: "r8", title: "University Physics Volume 1", author: "OpenStax",
    subject: "physics", level: "دانشگاهی", lang: "انگلیسی", type: "کتاب درسی",
    license: "CC BY 4.0", url: "https://openstax.org/details/books/university-physics-volume-1",
    note: "مکانیک، نوسان و امواج و ترمودینامیک؛ مرجع اصلی آکادمی فیزیک مث‌ورس.",
  },
  {
    id: "r9", title: "University Physics Volume 2", author: "OpenStax",
    subject: "physics", level: "دانشگاهی", lang: "انگلیسی", type: "کتاب درسی",
    license: "CC BY 4.0", url: "https://openstax.org/details/books/university-physics-volume-2",
    note: "الکتریسیته و مغناطیس، مدارها و نورشناسی.",
  },
  {
    id: "r10", title: "University Physics Volume 3", author: "OpenStax",
    subject: "physics", level: "دانشگاهی", lang: "انگلیسی", type: "کتاب درسی",
    license: "CC BY 4.0", url: "https://openstax.org/details/books/university-physics-volume-3",
    note: "اپتیک و فیزیک مدرن: نسبیت، کوانتوم، اتم و هسته.",
  },
  {
    id: "r11", title: "College Physics 2e", author: "OpenStax",
    subject: "physics", level: "دبیرستان/رتبه مقدماتی", lang: "انگلیسی", type: "کتاب درسی",
    license: "CC BY 4.0", url: "https://openstax.org/details/books/college-physics-2e",
    note: "فیزیک مبتنی بر جبر (بدون حسابان) — مناسب شروع و دبیرستان.",
  },
  {
    id: "r12", title: "Classical Mechanics (دوره ۸٫۰۱)", author: "MIT OpenCourseWare — Walter Lewin",
    subject: "physics", level: "دانشگاهی", lang: "انگلیسی", type: "دوره دانشگاهی",
    license: "CC BY-NC-SA 4.0", url: "https://ocw.mit.edu/courses/8-01sc-classical-mechanics-fall-2016/",
    note: "مکانیک کلاسیک با مشاهده‌ی روابط درس در عمل؛ شامل مسئله و آزمون.",
  },
  {
    id: "r13", title: "OpenIntro Statistics (ویراست ۵)", author: "Diez, Çetinkaya-Rundel, Barr",
    subject: "stats", level: "دانشگاهی", lang: "انگلیسی", type: "کتاب درسی",
    license: "CC BY-SA 3.0", url: "https://www.openintro.org/book/os/",
    note: "کتاب آزاد آمار با داده‌های واقعی؛ PDF رایگان از سایت ناشر.",
  },
  {
    id: "r14", title: "Introduction to Probability", author: "MIT OCW / ocw 18.05 — Jeremy Orloff, Jonathan Bloom",
    subject: "stats", level: "دانشگاهی", lang: "انگلیسی", type: "دوره دانشگاهی",
    license: "CC BY-NC-SA 4.0", url: "https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/",
    note: "احتمال و آمار با یادداشت‌های خوانا و تمرین‌های فراوان.",
  },
  {
    id: "r15", title: "Paul's Online Math Notes", author: "Paul Dawkins — Lamar University",
    subject: "math", level: "دانشگاهی", lang: "انگلیسی", type: "جزوه/یادداشت",
    license: "دسترسی آزاد آنلاین (بازنشر مجاز نیست)", url: "https://tutorial.math.lamar.edu/",
    note: "یادداشت‌های بسیار محبوب جبر، حسابان و معادلات دیفرانسیل — فقط لینک به منبع اصلی.",
  },
  {
    id: "r16", title: "LibreTexts Mathematics", author: "LibreTexts Consortium",
    subject: "math", level: "همه سطوح", lang: "انگلیسی", type: "درگاه جست‌وجو",
    license: "متنوع — هر صفحه مجوز خود را دارد", url: "https://math.libretexts.org/",
    note: "کتابخانه‌ی عظیم متون باز ریاضی؛ پیش از استفاده، مجوز هر صفحه را بررسی کنید.",
  },
  {
    id: "r17", title: "The First Six Books of the Elements of Euclid (Oliver Byrne)", author: "اقلیدس / طراحی رنگی ۱۸۴۷",
    subject: "general", level: "کلاسیک", lang: "انگلیسی", type: "اثر کلاسیک",
    license: "مالکیت عمومی (Public Domain)", url: "https://www.gutenberg.org/ebooks/8107",
    note: "شاهکار هندسه‌ی اقلیدس با نمایش تصویری رنگی — از پروژه گوتنبرگ.",
  },
  {
    id: "r18", title: "arXiv.org", author: "Cornell University",
    subject: "general", level: "پژوهشی", lang: "انگلیسی", type: "درگاه جست‌وجو",
    license: "مجوزهای متنوع نویسندگان", url: "https://arxiv.org/",
    note: "پیش‌چاپ‌های ریاضی و فیزیک؛ برای جست‌وجوی مقالات پژوهشی.",
  },
  {
    id: "r19", title: "Directory of Open Access Books (DOAB)", author: "DOAB Foundation",
    subject: "general", level: "همه سطوح", lang: "چندزبانه", type: "درگاه جست‌وجو",
    license: "کتاب‌های دسترسی‌باز داوری‌شده", url: "https://www.doabooks.org/",
    note: "فهرست معتبر کتاب‌های آکادمیک دسترسی‌باز با مجوز مشخص.",
  },
];
