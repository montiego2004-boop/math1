import type { Lesson } from "./lesson-types";
import { MATH_LESSONS } from "./lessons-math";
import { PHYSICS_LESSONS } from "./lessons-physics";
import { MATH_LESSONS_A } from "./lessons-math-a";
import { MATH_LESSONS_B } from "./lessons-math-b";
import { MATH_LESSONS_C } from "./lessons-math-c";
import { MATH_LESSONS_D } from "./lessons-math-d";
import { MATH_LESSONS_A2 } from "./lessons-math-a2";
import { MATH_LESSONS_B2 } from "./lessons-math-b2";
import { MATH_LESSONS_C2 } from "./lessons-math-c2";
import { MATH_LESSONS_D2 } from "./lessons-math-d2";

export type { Lesson, Block } from "./lesson-types";
export { MATH_LESSONS, PHYSICS_LESSONS, MATH_LESSONS_A, MATH_LESSONS_B, MATH_LESSONS_C, MATH_LESSONS_D, MATH_LESSONS_A2, MATH_LESSONS_B2, MATH_LESSONS_C2, MATH_LESSONS_D2 };

export const ALL_MATH_LESSONS: Lesson[] = [
  ...MATH_LESSONS,
  ...MATH_LESSONS_A,
  ...MATH_LESSONS_B,
  ...MATH_LESSONS_C,
  ...MATH_LESSONS_D,
  ...MATH_LESSONS_A2,
  ...MATH_LESSONS_B2,
  ...MATH_LESSONS_C2,
  ...MATH_LESSONS_D2,
];

export const ALL_LESSONS: Lesson[] = [...ALL_MATH_LESSONS, ...PHYSICS_LESSONS];

export function getLesson(academy: "math" | "physics", id: string): Lesson | undefined {
  return ALL_LESSONS.find((l) => l.academy === academy && l.id === id);
}
