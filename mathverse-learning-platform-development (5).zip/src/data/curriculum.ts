export interface LessonMeta {
  id: string;
  title: string;
  ready: boolean;
  chapter?: string;
}

export interface Subject {
  id: string;
  title: string;
  /** short course summary (displayed in the academy browser) */
  desc?: string;
  /** prerequisite topics (display only) */
  prereq?: string[];
  lessons: LessonMeta[];
}

export interface Level {
  id: string;
  code: string;
  title: string;
  desc: string;
  subjects: Subject[];
}

/* ------------------------------ MATHEMATICS ------------------------------ */

export const MATH_LEVELS: Level[] = [
  {
    id: "a",
    code: "سطح A",
    title: "مبانی ریاضیات",
    desc: "پایه‌ی ضروری برای تمام مسیرهای بعدی: نظام عددی، جبر مقدماتی، هندسه و درک تابع",
    subjects: [
      {
        id: "arith", title: "حساب و نظام عددی",
        desc: "از اعداد طبیعی تا اعداد حقیقی؛ مهارت محاسباتی و نظریهٔ مقدماتی اعداد",
        prereq: ["حساب ابتدایی"],
        lessons: [
          { id: "integers-absolute", title: "اعداد صحیح و قدر مطلق", ready: true, chapter: "نظام عددی" },
          { id: "fractions-percent", title: "کسرها، درصد و تناسب", ready: true, chapter: "نظام عددی" },
          { id: "powers-roots", title: "توان، ریشه و نماد علمی", ready: true, chapter: "نظام عددی" },
          { id: "divisibility-primes", title: "تقسیم‌پذیری، اعداد اول، ب.م.م و ک.م.م", ready: true, chapter: "نظریهٔ اعداد" },
          { id: "arithmetic-order", title: "ترتیب عملیات و محاسبات ذهنی", ready: true, chapter: "نظام عددی" },
          { id: "scientific-notation", title: "دقت، ارقام معنادار و تقریب", ready: true, chapter: "نظام عددی" },
        ],
      },
      {
        id: "alg-basic", title: "جبر پایه",
        desc: "متغیر، عبارت، اتحاد و معادله — زبان نمادین ریاضیات",
        prereq: ["حساب و نظام عددی"],
        lessons: [
          { id: "variables-expressions", title: "متغیرها و عبارت‌های جبری", ready: true, chapter: "نمادگذاری" },
          { id: "linear-equations", title: "معادلهٔ درجهٔ اول و مدل‌سازی کلامی", ready: true, chapter: "معادلات" },
          { id: "identities-factorization", title: "اتحادها و تجزیه", ready: true, chapter: "ابزار نمادین" },
          { id: "quadratic-eq", title: "معادلهٔ درجهٔ دو", ready: true, chapter: "معادلات" },
          { id: "inequalities-absolute", title: "نامعادله‌ها و قدر مطلق", ready: true, chapter: "معادلات" },
          { id: "systems-intro", title: "آشنایی با دستگاه‌های خطی", ready: true, chapter: "معادلات" },
          { id: "exponents-simplify", title: "توان‌گذاری عبارت‌های کسری", ready: true, chapter: "ابزار نمادین" },
        ],
      },
      {
        id: "geom-basic", title: "هندسهٔ پایه",
        desc: "زاویه، مثلث، چندضلعی، دایره؛ فیثاغورس و تشابه",
        prereq: ["حساب و نظام عددی"],
        lessons: [
          { id: "geometry-foundation", title: "نقطه، خط، زاویه و خطوط موازی", ready: true, chapter: "مبانی" },
          { id: "pythagorean-geometry", title: "مثلث‌ها و قضیهٔ فیثاغورس", ready: true, chapter: "مثلث‌ها" },
          { id: "similarity", title: "تشابه و تناسب هندسی", ready: true, chapter: "مثلث‌ها" },
          { id: "circles-polygons", title: "دایره و چندضلعی‌ها", ready: true, chapter: "اشکال" },
          { id: "coordinate-geometry", title: "مختصات و معادلهٔ خط", ready: true, chapter: "هندسه تحلیلی" },
          { id: "area-volume", title: "محیط، مساحت و حجم", ready: true, chapter: "اشکال" },
        ],
      },
      {
        id: "func-trig", title: "توابع و مثلثات پایه",
        desc: "ماشین تابع، نمودار، و دایرهٔ واحد",
        prereq: ["جبر پایه", "هندسهٔ پایه"],
        lessons: [
          { id: "functions-basics", title: "مفهوم تابع، دامنه و برد", ready: true, chapter: "درک تابع" },
          { id: "linear-quadratic-functions", title: "توابع خطی و درجهٔ دو", ready: true, chapter: "درک تابع" },
          { id: "transformations-graphs", title: "انتقال و تغییر مقیاس نمودار", ready: true, chapter: "درک تابع" },
          { id: "inverse-functions", title: "ترکیب و وارون توابع", ready: true, chapter: "درک تابع" },
          { id: "trig-functions", title: "مثلثات و دایرهٔ واحد", ready: true, chapter: "مثلثات" },
          { id: "trig-equations", title: "معادلات مثلثاتی پایه", ready: true, chapter: "مثلثات" },
        ],
      },
    ],
  },
  {
    id: "b",
    code: "سطح B",
    title: "ریاضیات دبیرستان",
    desc: "جبر پیشرفته، مثلثات تکمیلی، هندسهٔ تحلیلی و آشنایی با حسابان، گسسته و احتمال",
    subjects: [
      {
        id: "adv-alg", title: "جبر پیشرفته",
        desc: "چندجمله‌ای‌ها، نما/لگاریتم، اعداد مختلط و دنباله‌ها",
        prereq: ["جبر پایه (سطح A)"],
        lessons: [
          { id: "polynomial-division", title: "تقسیم چندجمله‌ای و قضایای باقی‌مانده/عامل", ready: true, chapter: "چندجمله‌ای‌ها" },
          { id: "rational-expressions", title: "عبارت‌های گویا و معادلات گویا", ready: true, chapter: "چندجمله‌ای‌ها" },
          { id: "exp-log", title: "توابع نمایی و لگاریتمی", ready: true, chapter: "نما و لگاریتم" },
          { id: "complex-numbers", title: "اعداد مختلط و صفحهٔ آرگان", ready: true, chapter: "نظام‌های بسط‌یافته" },
          { id: "sequences-series", title: "دنباله‌ها و سری‌ها", ready: true, chapter: "دنباله و سری" },
          { id: "systems-advanced", title: "دستگاه‌های معادلات و روش‌های معادل", ready: true, chapter: "چندجمله‌ای‌ها" },
        ],
      },
      {
        id: "adv-trig", title: "مثلثات پیشرفته",
        desc: "اتحادها، فرمول‌های مجموع/دوبرابر، قوانین سینوس و کسینوس",
        prereq: ["مثلثات پایه (سطح A)"],
        lessons: [
          { id: "trig-identities", title: "اتحادهای مثلثاتی (مجموع و تفاضل)", ready: true, chapter: "اتحادها" },
          { id: "trig-double-half", title: "فرمول‌های نیم‌زاویه و دوبرابر", ready: true, chapter: "اتحادها" },
          { id: "law-sines-cosines", title: "قوانین سینوس و کسینوس", ready: true, chapter: "حل مثلث" },
          { id: "inverse-trig", title: "توابع معکوس مثلثاتی", ready: true, chapter: "وارون" },
          { id: "trig-applications", title: "کاربردهای مثلثات (کاربردی)", ready: true, chapter: "حل مثلث" },
        ],
      },
      {
        id: "analytic", title: "هندسهٔ تحلیلی",
        desc: "خطوط و مقاطع مخروطی به زبان مختصات",
        prereq: ["معادلهٔ درجهٔ دو", "فیثاغورس"],
        lessons: [
          { id: "conics-analytic", title: "خط، دایره و مقاطع مخروطی", ready: true, chapter: "هندسه با مختصات" },
          { id: "polar-coords", title: "مختصات قطبی و منحنی‌های قطبی", ready: true, chapter: "سیستم‌های جایگزین" },
          { id: "parametric-curves", title: "معادلات پارامتری", ready: true, chapter: "سیستم‌های جایگزین" },
          { id: "vectors-2d", title: "بردارها در صفحه", ready: true, chapter: "بردار" },
        ],
      },
      {
        id: "calculus-intro", title: "آشنایی با حسابان",
        desc: "حد، مشتق و انتگرال — دروازهٔ حسابان",
        prereq: ["توابع", "مثلثات پایه"],
        lessons: [
          { id: "limits", title: "حد و پیوستگی", ready: true, chapter: "حد" },
          { id: "derivatives", title: "مشتق", ready: true, chapter: "مشتق" },
          { id: "derivatives-applications", title: "کاربردهای مشتق (بهینه‌سازی)", ready: true, chapter: "مشتق" },
          { id: "integrals", title: "انتگرال", ready: true, chapter: "انتگرال" },
        ],
      },
      {
        id: "discrete-found", title: "مبانی ریاضیات گسسته",
        desc: "منطق، مجموعه‌ها، شمارش و استقرا",
        prereq: ["جبر پایه"],
        lessons: [
          { id: "sets-logic", title: "منطق، مجموعه‌ها و روش‌های اثبات", ready: true, chapter: "منطق" },
          { id: "induction", title: "استقرای ریاضی", ready: true, chapter: "اثبات" },
          { id: "counting", title: "جایگشت و ترکیب و اصل لانهٔ کبوتر", ready: true, chapter: "شمارش" },
          { id: "relations", title: "رابطه‌ها و توابع بین مجموعه‌ها", ready: true, chapter: "منطق" },
          { id: "graphs-intro", title: "مقدمهٔ نظریهٔ گراف", ready: true, chapter: "گراف" },
        ],
      },
      {
        id: "prob-stat", title: "احتمال و آمار",
        desc: "شمارش، احتمال کلاسیک و شرطی، آمار توصیفی",
        prereq: ["کسرها", "مجموعه‌های پایه"],
        lessons: [
          { id: "statistics-intro", title: "آمار توصیفی: میانگین، واریانس، چارک", ready: true, chapter: "آمار" },
          { id: "probability-intro", title: "احتمال پایه", ready: true, chapter: "احتمال" },
          { id: "conditional-probability", title: "احتمال شرطی و قضیهٔ بیز", ready: true, chapter: "احتمال" },
          { id: "random-variables-intro", title: "متغیرهای تصادفی مقدماتی", ready: true, chapter: "احتمال" },
        ],
      },
    ],
  },
  {
    id: "c",
    code: "سطح C",
    title: "ریاضیات دانشگاهی",
    desc: "دوره‌های اصلی (حسابان I–III، جبرخطی، معادلات دیفرانسیل، آنالیز، احتمال، عددی...)",
    subjects: [
      {
        id: "calc1", title: "حسابان ۱ — تک متغیره",
        desc: "دورهٔ کامل: حد، مشتق، کاربرد مشتق، انتگرال معین، قضیهٔ بنیادی",
        prereq: ["سطح B حسابان مقدماتی", "مثلثات"],
        lessons: [
          { id: "riemann-ftc", title: "مجموع‌های ریمان و قضیهٔ بنیادی حسابان", ready: true, chapter: "فصل ۵ — انتگرال معین" },
          { id: "limits-rigorous", title: "حد به زبان اپسیلون–دلتا", ready: true, chapter: "فصل ۲ — حد" },
          { id: "mvt-optimization", title: "قضیهٔ مقدار میانی و بهینه‌سازی", ready: true, chapter: "فصل ۴ — کاربرد مشتق" },
          { id: "substitution-intro", title: "انتگرال‌گیری با تغییر متغیر (مقدمه)", ready: true, chapter: "فصل ۶ — کاربرد انتگرال" },
        ],
      },
      {
        id: "calc2", title: "حسابان ۲ — تکنیک و سری",
        desc: "تکنیک‌های انتگرال، دنباله و سری بی‌نهایت و سری توان",
        prereq: ["حسابان ۱ (انتگرال و مشتق)"],
        lessons: [
          { id: "integration-techniques", title: "تکنیک‌های انتگرال‌گیری", ready: true, chapter: "فصل ۷" },
          { id: "series-convergence", title: "آزمون‌های همگرایی سری", ready: true, chapter: "فصل ۸ — سری‌ها" },
          { id: "power-taylor", title: "سری توان و تیلور/ماکلورن", ready: true, chapter: "فصل ۹ — سری توان" },
          { id: "improper-integrals", title: "انتگرال‌های نامتعارف", ready: true, chapter: "فصل ۷" },
          { id: "polar-calculus", title: "طول قوس و مساحت در قطبی", ready: true, chapter: "فصل ۱۰" },
        ],
      },
      {
        id: "calc3", title: "حسابان ۳ — چندمتغیره و حساب برداری",
        desc: "مشتقات جزئی تا قضایای گرین/استوکس/واگرایی",
        prereq: ["حسابان ۱ و ۲", "جبرخطی (هم‌زمان)"],
        lessons: [
          { id: "partial-gradient-lagrange", title: "مشتق جزئی، گرادیان و لاگرانژ", ready: true, chapter: "فصل ۱ — مشتق" },
          { id: "double-triple", title: "انتگرال‌های دوگانه و سه‌گانه", ready: true, chapter: "فصل ۲ — انتگرال" },
          { id: "jacobian-coords", title: "مختصات استوانه‌ای، کروی و ژاکوبی", ready: true, chapter: "فصل ۲ — انتگرال" },
          { id: "green-stokes", title: "قضایای گرین، استوکس و واگرایی", ready: true, chapter: "فصل ۳ — حساب برداری" },
        ],
      },
      {
        id: "linalg", title: "جبر خطی",
        desc: "حذف گاوسی تا مقادیر ویژه و قطری‌سازی",
        prereq: ["آشنایی با بردارها"],
        lessons: [
          { id: "matrices", title: "ماتریس‌ها و دترمینان", ready: true, chapter: "فصل ۱" },
          { id: "eigen-systems", title: "دستگاه‌های خطی و مقادیر/بردارهای ویژه", ready: true, chapter: "فصل ۲" },
          { id: "gaussian-elimination", title: "حذف گاوسی سیستماتیک (RREF)", ready: true, chapter: "فصل ۱" },
          { id: "vector-spaces", title: "فضاهای برداری، استقلال و پایه", ready: true, chapter: "فصل ۳" },
          { id: "inner-product", title: "فضاهای ضرب‌داخلی و کمترین مربعات", ready: true, chapter: "فصل ۴" },
        ],
      },
      {
        id: "ode", title: "معادلات دیفرانسیل معمولی",
        desc: "مرتبهٔ اول و دوم، سیستم‌خطی و پایداری",
        prereq: ["حسابان ۱", "آشنایی با جبرخطی"],
        lessons: [
          { id: "ode-first-order", title: "معادلات دیفرانسیل مرتبهٔ اول", ready: true, chapter: "فصل ۱" },
          { id: "ode-second-const", title: "معادلات خطی مرتبهٔ دوم با ضرایب ثابت", ready: true, chapter: "فصل ۲" },
          { id: "laplace", title: "تبدیل لاپلاس", ready: false, chapter: "فصل ۳" },
          { id: "phase-stability", title: "پرترهٔ فاز و پایداری", ready: false, chapter: "فصل ۴" },
        ],
      },
      {
        id: "real-analysis", title: "آنالیز حقیقی",
        desc: "کمال، دنباله‌های کوشی، پیوستگی یکنواخت — پایهٔ دقیق حسابان",
        prereq: ["حسابان ۱ و ۲ + منطق و اثبات"],
        lessons: [
          { id: "completeness-sequences", title: "کمال R، دنباله‌ها و همگرایی دقیق", ready: true, chapter: "فصل ۱" },
          { id: "uniform-convergence", title: "همگرایی یکنواخت دنبالهٔ توابع", ready: false, chapter: "فصل ۲" },
          { id: "riemann-integration-theory", title: "انتگرال ریمانی صوری", ready: false, chapter: "فصل ۳" },
        ],
      },
      {
        id: "complex-analysis", title: "آنالیز مختلط",
        desc: "هولومورفیک، کوشی–ریمان و قضیهٔ انتگرال کوشی",
        prereq: ["حسابان ۳ (مشتقات جزئی)", "اعداد مختلط"],
        lessons: [
          { id: "complex-analysis-intro", title: "مشتق‌پذیری و معادلات کوشی–ریمان", ready: true, chapter: "فصل ۱" },
          { id: "cauchy-integral", title: "قضیهٔ و فرمول انتگرال کوشی", ready: false, chapter: "فصل ۲" },
          { id: "residue-applications", title: "باقیمانده‌ها و کاربردها در انتگرال واقعی", ready: false, chapter: "فصل ۳" },
        ],
      },
      {
        id: "abstract-algebra", title: "جبر مجرد",
        desc: "گروه‌ها به حلقه‌ها و میدان‌ها",
        prereq: ["منطق و مجموعه‌ها", "آشنایی با ماتریس‌ها"],
        lessons: [
          { id: "groups-cyclic", title: "گروه‌ها، زیرگروه‌ها و گروه‌های دوری", ready: false, chapter: "فصل ۱" },
          { id: "cosets-lagrange", title: "همسوجه‌ها و قضیهٔ لاگرانژ", ready: false, chapter: "فصل ۲" },
          { id: "rings-fields", title: "حلقه‌ها، ایده‌آل‌ها و میدان‌ها", ready: false, chapter: "فصل ۳" },
        ],
      },
      {
        id: "prob-theory", title: "نظریهٔ احتمال",
        desc: "فضاهای احتمال تا قضیهٔ حد مرکزی",
        prereq: ["حسابان ۱ (شمارش و انتگرال)"],
        lessons: [
          { id: "random-variables", title: "متغیر تصادفی، توزیع و امید", ready: false, chapter: "فصل ۱" },
          { id: "joint-mgf", title: "توزیع‌های توأم و مولد عزوم", ready: false, chapter: "فصل ۲" },
          { id: "lln-clt", title: "قانون اعداد بزرگ و قضیهٔ حد مرکزی", ready: false, chapter: "فصل ۳" },
        ],
      },
      {
        id: "numerical", title: "آنالیز عددی",
        desc: "محاسبات مدتمدن با خطا تحت کنترل",
        prereq: ["مشتق", "پیوستگی"],
        lessons: [
          { id: "numerical-methods", title: "ریشه‌یابی عددی: دوبخشی، نیوتن، سکانت", ready: true, chapter: "فصل ۱" },
          { id: "interpolation", title: "درون‌یابی چندجمله‌ای و لاگرانژ", ready: false, chapter: "فصل ۲" },
          { id: "numerical-ode", title: "روش‌های عددی ODE (اویلر، رانگه-کوتا)", ready: false, chapter: "فصل ۳" },
        ],
      },
      {
        id: "pde-fourier", title: "معادلات جزئی و تحلیل فوریه",
        desc: "موج، گرما و لاپلاس + سری فوریه",
        prereq: ["حسابان ۳", "معادلات دیفرانسیل"],
        lessons: [
          { id: "fourier-course", title: "سری فوریه، همگرایی و تبدیل", ready: false, chapter: "فصل ۱" },
          { id: "pde-intro", title: "طبقه‌بندی PDE و تفکیک متغیرها", ready: false, chapter: "فصل ۲" },
          { id: "wave-heat", title: "معادلهٔ موج و معادلهٔ گرما", ready: false, chapter: "فصل ۳" },
        ],
      },
      {
        id: "discrete-num-theory", title: "ریاضیات گسسته و نظریهٔ اعداد",
        desc: "گراف، درخت، بازگشتی، پیمانه‌ای",
        prereq: ["منطق و استقرا (سطح B گسسته)"],
        lessons: [
          { id: "graph-theory-course", title: "نظریهٔ گراف: درخت‌ها، رنگ‌آمیزی، مسطح", ready: false, chapter: "گراف" },
          { id: "recurrences", title: "روابط بازگشتی و تابع مولد", ready: false, chapter: "شمارش" },
          { id: "modular-arithmetic", title: "حساب پیمانه‌ای و قضیهٔ اویلر", ready: false, chapter: "نظریهٔ اعداد" },
        ],
      },
    ],
  },
  {
    id: "d",
    code: "سطح D",
    title: "ریاضیات تحصیلات‌تکمیلی",
    desc: "مسیرهای پژوهشی با هشدار صادقانهٔ پیش‌نیاز؛ درس‌های این سطح «معرفی مسیر» هستند نه دورهٔ کامل",
    subjects: [
      {
        id: "measure", title: "نظریهٔ اندازه و انتگرال لبگ",
        desc: "پایهٔ تحلیل مدرن و احتمال نظری",
        prereq: ["آنالیز حقیقی کامل"],
        lessons: [
          { id: "measure-theory-intro", title: "معرفی مسیر: نظریهٔ اندازه", ready: true, chapter: "معرفی مسیر" },
          { id: "lebesgue-integral", title: "انتگرال لبگ و قضیهٔ همگرایی مغلوب", ready: true, chapter: "فصل ۲ — برنامه‌ریزی شده" },
          { id: "lp-spaces", title: "فضاهای L^p و قضیهٔ رادون-نیکودیم", ready: false, chapter: "فصل ۳ — برنامه‌ریزی شده" },
        ],
      },
      {
        id: "funct-analysis", title: "تحلیل تابعی",
        desc: "باناخ، هیلبرت، عملگرها",
        prereq: ["نظریهٔ اندازه"],
        lessons: [
          { id: "functional-analysis-intro", title: "معرفی مسیر: فضاهای باناخ و هیلبرت", ready: true, chapter: "معرفی مسیر" },
          { id: "operator-theory", title: "نظریهٔ عملگر و طیف", ready: false, chapter: "فصل ۲ — برنامه‌ریزی شده" },
          { id: "spectral-theory", title: "قضیهٔ طیفی و کاربرد در PDE", ready: false, chapter: "فصل ۳ — برنامه‌ریزی شده" },
        ],
      },
      {
        id: "topology-grad", title: "توپولوژی عمومی و جبری",
        desc: "فضاهای متریک تا توپولوژی جبری",
        prereq: ["آنالیز حقیقی", "جبر مجرد (هم‌زمان)"],
        lessons: [
          { id: "topology-intro", title: "معرفی مسیر: توپولوژی عمومی", ready: true, chapter: "معرفی مسیر" },
          { id: "fundamental-groups", title: "گروه بنیادی π₁ و پوشش‌ها", ready: false, chapter: "برنامه‌ریزی شده" },
          { id: "homology", title: "همولوژی و جبره‌ای‌شدن توپولوژی", ready: false, chapter: "برنامه‌ریزی شده" },
        ],
      },
      {
        id: "advanced-grad", title: "سطوح پژوهشی برنامه‌ریزی‌شده",
        desc: "مسیرهای پژوهش: هندسهٔ دیفرانسیلی، نظریهٔ نمایش، فرایندهای تصادفی — هنوز محتوا تولید نشده",
        prereq: ["سطح D پیش‌نیاز"],
        lessons: [
          { id: "riemannian-geometry", title: "هندسهٔ ریمانی و انحنا", ready: false, chapter: "برنامه‌ریزی شده" },
          { id: "stochastic-processes", title: "زنجیرهٔ مارکوف و حرکت براونی", ready: false, chapter: "برنامه‌ریزی شده" },
          { id: "representation-theory", title: "نظریهٔ نمایش گروه‌ها", ready: false, chapter: "برنامه‌ریزی شده" },
          { id: "research-methodology", title: "روش‌شناسی پژوهش ریاضی", ready: false, chapter: "برنامه‌ریزی شده" },
        ],
      },
    ],
  },
];

/* -------------------------------- PHYSICS -------------------------------- */

export const PHYSICS_AREAS: Level[] = [
  {
    id: "mechanics",
    code: "شاخه ۱",
    title: "مکانیک کلاسیک",
    desc: "حرکت، نیرو، انرژی و گرانش",
    subjects: [
      { id: "kinematics", title: "سینماتیک", lessons: [
        { id: "kinematics", title: "مکان، سرعت و شتاب", ready: true },
        { id: "free-fall", title: "سقوط آزاد", ready: false },
        { id: "projectile", title: "حرکت پرتابه", ready: true },
      ]},
      { id: "dynamics", title: "دینامیک", lessons: [
        { id: "newtons-laws", title: "قوانین نیوتن", ready: true },
        { id: "friction", title: "اصطکاک (جفت با آزمایش سطح شیب‌دار)", ready: false },
        { id: "circular-motion", title: "حرکت دایره‌ای", ready: false },
      ]},
      { id: "energy-mom", title: "انرژی و تکانه", lessons: [
        { id: "work-energy", title: "کار و انرژی", ready: true },
        { id: "momentum", title: "تکانه و برخورد", ready: true },
        { id: "rotation", title: "حرکت چرخشی (جفت با آزمایش Rotation)", ready: false },
        { id: "gravitation", title: "گرانش جهانی", ready: false },
      ]},
    ],
  },
  {
    id: "waves",
    code: "شاخه ۲",
    title: "نوسان و امواج",
    desc: "حرکت هماهنگ ساده تا امواج ایستاده",
    subjects: [
      { id: "osc", title: "نوسان", lessons: [
        { id: "shm", title: "حرکت هماهنگ ساده", ready: true },
        { id: "forced-resonance", title: "نوسان اجباری و رزونانس (جفت با آزمایش Resonance)", ready: false },
        { id: "double-pendulum", title: "آونگ دوگانه و آشوب (جفت با آزمایش)", ready: false },
      ]},
      { id: "wave-motion", title: "امواج", lessons: [
        { id: "waves-intro", title: "امواج مکانیکی و معادلهٔ موج", ready: false },
        { id: "interference-waves", title: "تداخل و امواج ایستاده (جفت با آزمایش)", ready: false },
        { id: "sound", title: "امواج صوتی و دوپلر", ready: false },
      ]},
    ],
  },
  {
    id: "em",
    code: "شاخه ۳",
    title: "الکتریسیته و مغناطیس",
    desc: "از بار الکتریکی تا معادلات ماکسول",
    subjects: [
      { id: "electrostatics", title: "الکترواستاتیک", lessons: [
        { id: "coulomb", title: "قانون کولن و میدان الکتریکی", ready: false },
        { id: "potential-em", title: "پتانسیل الکتریکی", ready: false },
      ]},
      { id: "circuits", title: "مدارها", lessons: [
        { id: "dc-circuits", title: "مدارهای جریان مستقیم", ready: true },
        { id: "capacitors-rc", title: "خازن و مدار RC", ready: false },
      ]},
      { id: "magnetism", title: "مغناطیس", lessons: [
        { id: "lorentz-force", title: "نیروی لورتس (جفت با آزمایش)", ready: false },
        { id: "induction", title: "القای الکترومغناطیسی (جفت با آزمایش)", ready: false },
      ]},
    ],
  },
  {
    id: "optics",
    code: "شاخه ۴",
    title: "نورشناسی",
    desc: "بازتاب، شکست و عدسی‌ها",
    subjects: [
      { id: "geo-optics", title: "اپتیک هندسی", lessons: [
        { id: "mirrors", title: "آینه‌ها", ready: false },
        { id: "thin-lens", title: "عدسی نازک (جفت با آزمایش)", ready: false },
      ]},
      { id: "wave-optics", title: "اپتیک موجی", lessons: [
        { id: "young-interference", title: "تداخل یانگ", ready: false },
        { id: "diffraction", title: "پراش", ready: false },
      ]},
    ],
  },
  {
    id: "thermo",
    code: "شاخه ۵",
    title: "ترمودینامیک",
    desc: "گرما، گازها و آنتروپی",
    subjects: [
      { id: "heat", title: "گرما و دما", lessons: [
        { id: "temperature-heat", title: "دما، گرما و گاز ایده‌آل", ready: false },
        { id: "heat-transfer", title: "انتقال گرما", ready: false },
      ]},
      { id: "laws", title: "قوانین ترمودینامیک", lessons: [
        { id: "first-law-pv", title: "قوانین اول و چرخهٔ کارنو (جفت با آزمایش PV)", ready: false },
        { id: "entropy", title: "قانون دوم و آنتروپی", ready: false },
      ]},
    ],
  },
  {
    id: "modern",
    code: "شاخه ۶",
    title: "فیزیک مدرن",
    desc: "نسبیت، کوانتوم و هسته",
    subjects: [
      { id: "relativity", title: "نسبیت خاص", lessons: [
        { id: "relativity-gamma", title: "اتساع زمان و انقباض طول (جفت با آزمایش)", ready: false },
      ]},
      { id: "quantum", title: "مکانیک کوانتومی", lessons: [
        { id: "quantum-well", title: "ذره در چاه (جفت با آزمایش)", ready: false },
        { id: "photoelectric", title: "اثر فوتوالکتریک", ready: false },
      ]},
      { id: "nuclear", title: "فیزیک هسته‌ای", lessons: [
        { id: "nuclear-intro", title: "ساختار هسته و واپاشی", ready: false },
      ]},
    ],
  },
];

export function lessonLocation(academy: "math" | "physics", lessonId: string) {
  const levels = academy === "math" ? MATH_LEVELS : PHYSICS_AREAS;
  for (const level of levels) {
    for (const subject of level.subjects) {
      const lesson = subject.lessons.find((l) => l.id === lessonId);
      if (lesson) return { level, subject, lesson };
    }
  }
  return null;
}
