export interface Exercise {
  id: string;
  topic: string;
  academy: "math" | "physics";
  difficulty: 1 | 2 | 3;
  question: string;
  questionTex?: string;
  choices: string[];
  answer: number;
  explanation: string;
  explanationTex?: string;
}

export interface GeneratedQuestion {
  question: string;
  questionTex?: string;
  answer: number;
  unit?: string;
  tolerance: number;
  steps: { text: string; tex?: string }[];
}

export interface Generator {
  id: string;
  topic: string;
  academy: "math" | "physics";
  difficulty: 1 | 2 | 3;
  label: string;
  make: () => GeneratedQuestion;
}

export const DIFF_FA: Record<number, string> = { 1: "آسان", 2: "متوسط", 3: "سخت" };

/* ------------------------- Static MCQ bank ------------------------- */
/* Answers are verified by direct computation.                          */

export const EXERCISES: Exercise[] = [
  {
    id: "m1", topic: "مشتق", academy: "math", difficulty: 1,
    question: "مشتق تابع زیر در x = 2 کدام است؟",
    questionTex: "f(x) = 3x^2",
    choices: ["6", "12", "4", "18"],
    answer: 1,
    explanation: "طبق قاعده‌ی توان، f′(x)=6x و در نقطه‌ی ۲: f′(2)=12.",
    explanationTex: "f'(x) = 6x \\Rightarrow f'(2) = 12",
  },
  {
    id: "m2", topic: "انتگرال", academy: "math", difficulty: 1,
    question: "انتگرال معین زیر چقدر است؟",
    questionTex: "\\int_0^3 2x\\,dx",
    choices: ["3", "6", "9", "12"],
    answer: 2,
    explanation: "پادمشتق 2x برابر x² است؛ طبق قضیه‌ی اساسی: F(3)−F(0) = 9.",
    explanationTex: "\\int_0^3 2x\\,dx = [x^2]_0^3 = 9",
  },
  {
    id: "m3", topic: "حد", academy: "math", difficulty: 2,
    question: "حد مشهور زیر برابر است با:",
    questionTex: "\\lim_{x \\to 0} \\frac{\\sin x}{x}",
    choices: ["0", "1", "∞", "وجود ندارد"],
    answer: 1,
    explanation: "با قضیه‌ی فشار (مقایسه‌ی مساحت‌ها در دایره‌ی واحد) حد برابر ۱ است. x باید به رادیان باشد.",
  },
  {
    id: "m4", topic: "ماتریس", academy: "math", difficulty: 2,
    question: "دترمینان ماتریس زیر چقدر است؟",
    questionTex: "A = \\begin{pmatrix} 3 & 1 \\\\ 2 & 4 \\end{pmatrix}",
    choices: ["10", "14", "12", "-10"],
    answer: 0,
    explanation: "دترمینان = ad − bc = 3×4 − 1×2 = 10.",
    explanationTex: "\\det A = (3)(4) - (1)(2) = 10",
  },
  {
    id: "m5", topic: "احتمال", academy: "math", difficulty: 1,
    question: "در پرتاب یک تاس سالم، احتمال آمدن عدد زوج کدام است؟",
    choices: ["1/6", "1/3", "1/2", "2/3"],
    answer: 2,
    explanation: "نتایج مطلوب {2,4,6} یعنی ۳ حالت از ۶ حالت هم‌شانس: 3/6 = 1/2.",
  },
  {
    id: "m6", topic: "مثلثات", academy: "math", difficulty: 1,
    question: "مقدار sin²θ + cos²θ برای هر زاویه‌ای برابر است با:",
    choices: ["0", "1", "وابسته به θ", "2"],
    answer: 1,
    explanation: "اتحاد بنیادین مثلثات — نتیجه‌ی مستقیم قضیه‌ی فیثاغورس روی دایره‌ی واحد.",
  },
  {
    id: "m7", topic: "جبر", academy: "math", difficulty: 2,
    question: "اگر x² + y² = 25 و x = 3 باشد و y > 0، مقدار y چقدر است؟",
    choices: ["3", "4", "5", "√7"],
    answer: 1,
    explanation: "y² = 25 − 9 = 16 و چون y > 0 داریم y = 4.",
  },
  {
    id: "m8", topic: "بردار", academy: "math", difficulty: 2,
    question: "ضرب داخلی دو بردار a=(2,3) و b=(4,−1) کدام است؟",
    choices: ["11", "5", "8", "−5"],
    answer: 1,
    explanation: "a·b = 2×4 + 3×(−1) = 8 − 3 = 5.",
    explanationTex: "\\vec a \\cdot \\vec b = (2)(4) + (3)(-1) = 5",
  },
  {
    id: "p1", topic: "سینماتیک", academy: "physics", difficulty: 1,
    question: "جسمی از سکون با شتاب ثابت ۳ m/s² حرکت می‌کند. سرعت آن پس از ۴ ثانیه؟",
    choices: ["7 m/s", "12 m/s", "24 m/s", "9 m/s"],
    answer: 1,
    explanation: "v = v₀ + at = 0 + 3×4 = 12 m/s.",
    explanationTex: "v = v_0 + at = 3 \\times 4 = 12",
  },
  {
    id: "p2", topic: "قوانین نیوتن", academy: "physics", difficulty: 1,
    question: "نیروی خالص ۲۰ N بر جسم ۴ kg اثر می‌کند. شتاب جسم چقدر است؟",
    choices: ["80 m/s²", "0.2 m/s²", "5 m/s²", "4 m/s²"],
    answer: 2,
    explanation: "a = F/m = 20/4 = 5 m/s².",
  },
  {
    id: "p3", topic: "انرژی", academy: "physics", difficulty: 2,
    question: "اگر سرعت جسمی دو برابر شود، انرژی جنبشی آن چند برابر می‌شود؟",
    choices: ["۲ برابر", "۴ برابر", "۸ برابر", "تغییر نمی‌کند"],
    answer: 1,
    explanation: "انرژی جنبشی با مربع سرعت متناسب است: K = ½mv² پس ۲ برابر سرعت → ۴ برابر انرژی.",
  },
  {
    id: "p4", topic: "تکانه", academy: "physics", difficulty: 2,
    question: "در کدام نوع برخورد «انرژی جنبشی» پایسته می‌ماند؟",
    choices: ["همه‌ی برخوردها", "کاملاً ناکشسان", "کشسان (الاستیک)", "هیچ‌کدام"],
    answer: 2,
    explanation: "فقط در برخورد کشسان انرژی جنبشی پایسته است؛ تکانه در همه‌ی برخوردها پایسته است.",
  },
  {
    id: "p5", topic: "مدار", academy: "physics", difficulty: 1,
    question: "دو مقاومت ۶Ω و ۳Ω موازی‌اند. مقاومت معادل؟",
    choices: ["۹ Ω", "۲ Ω", "۴٫۵ Ω", "۰٫۵ Ω"],
    answer: 1,
    explanation: "در موازی: ۱/R = ۱/۶ + ۱/۳ = ۱/۲ پس R = ۲Ω.",
    explanationTex: "\\frac{1}{R} = \\frac{1}{6} + \\frac{1}{3} = \\frac{1}{2} \\Rightarrow R = 2\\,\\Omega",
  },
  {
    id: "p6", topic: "امواج", academy: "physics", difficulty: 1,
    question: "موجی با بسامد ۵ Hz و طول موج ۰٫۴ m چه سرعتی دارد؟",
    choices: ["۲ m/s", "۰٫۰۸ m/s", "۱۲٫۵ m/s", "۵٫۴ m/s"],
    answer: 0,
    explanation: "v = fλ = 5 × 0.4 = 2 m/s.",
  },
  {
    id: "p7", topic: "نوسان", academy: "physics", difficulty: 3,
    question: "اگر طول آونگ ساده ۴ برابر شود، دوره‌ی آن (در تقریب زاویه کوچک) چند برابر می‌شود؟",
    choices: ["۴ برابر", "۲ برابر", "۱۶ برابر", "ثابت می‌ماند"],
    answer: 1,
    explanation: "T ∝ √L پس دوره با ضریب √۴ = ۲ افزایش می‌یابد.",
    explanationTex: "T = 2\\pi\\sqrt{L/g} \\Rightarrow T' = \\sqrt{4}\\,T = 2T",
  },
  {
    id: "p8", topic: "ترمودینامیک", academy: "physics", difficulty: 2,
    question: "در قانون گاز ایده‌آل PV=nRT، دما باید به کدام واحد باشد؟",
    choices: ["درجه سلسیوس", "کلوین", "فارنهایت", "هر واحدی"],
    answer: 1,
    explanation: "T باید دمای مطلق (کلوین) باشد؛ چون P و V متناسب با دمای مطلق‌اند: T(K) = T(°C) + 273.15.",
  },
  /* --- New verified items aligned with expanded curriculum --- */
  {
    id: "m9", topic: "نظریهٔ اعداد", academy: "math", difficulty: 2,
    question: "با الگوریتم اقلیدسی، ب.م.م ۲۵۲ و ۱۰۵ چقدر است؟",
    choices: ["۷", "۱۴", "۲۱", "۴۲"],
    answer: 2,
    explanation: "252 = 2×105+42 ← 105 = 2×42+21 ← 42 = 2×21+0. آخرین باقی‌ماندهٔ ناصفر: ۲۱.",
    explanationTex: "\\gcd(252,105) = 21",
  },
  {
    id: "m10", topic: "چندجمله‌ای", academy: "math", difficulty: 2,
    question: "باقی‌ماندهٔ تقسیم P(x) = x³ − x + 1 بر (x − 2) کدام است؟",
    choices: ["۷", "۵", "۱", "۱۱"],
    answer: 0,
    explanation: "طبق قضیهٔ باقی‌مانده، برابر P(2) = 8 − 2 + 1 = 7.",
    explanationTex: "P(2) = 2^3 - 2 + 1 = 7",
  },
  {
    id: "m11", topic: "نمایی/لگاریتمی", academy: "math", difficulty: 2,
    question: "جواب معادلهٔ ۳^(x+1) = ۱۲:",
    choices: ["x = ln(12)/ln(3) − 1", "x = ln(36) − 1", "x = ln(4)", "x = 2"],
    answer: 0,
    explanation: "لگاریتم طبیعی دو طرف: (x+1)ln3 = ln12 ⇒ x = ln12/ln3 − 1 ≈ ۱٫۲۶.",
    explanationTex: "x = \\frac{\\ln 12}{\\ln 3} - 1 \\approx 1.26",
  },
  {
    id: "m12", topic: "احتمال شرطی", academy: "math", difficulty: 3,
    question: "بیماری با شیوع ۱٪. آزمون با حساسیت ۹۹٪ و ویژگی ۹۵٪ مثبت می‌شود؛ احتمال واقعی بیماری؟",
    choices: ["۹۹٪", "حدود ۵۰٪", "حدود ۱۷٪", "۵٪"],
    answer: 2,
    explanation: "بیز: (۰٫۹۹×۰٫۰۱)/((۰٫۹۹×۰٫۰۱)+(۰٫۰۵×۰٫۹۹)) ≈ ۰٫۱۶۷. شیوع پایه را فراموش نکنید!",
    explanationTex: "P(B|+) = \\frac{0.99 \\times 0.01}{0.99 \\cdot 0.01 + 0.05 \\cdot 0.99} \\approx 0.167",
  },
  {
    id: "m13", topic: "سری‌ها", academy: "math", difficulty: 2,
    question: "مجموع سری هندسی Σ(k=1 تا ∞) (1/2)^k چقدر است؟",
    choices: ["۱/۲", "۱", "۲", "واگرا"],
    answer: 1,
    explanation: "a=1/2, r=1/2: مجموع = a/(1−r) = (1/2)/(1/2) = ۱.",
    explanationTex: "\\sum_{k=1}^{\\infty} (1/2)^k = \\frac{1/2}{1-1/2} = 1",
  },
  {
    id: "m14", topic: "جبر خطی", academy: "math", difficulty: 3,
    question: "چندجمله‌ای مشخصهٔ A = [[4,1],[2,3]] کدام است؟",
    questionTex: "A = \\begin{pmatrix} 4 & 1 \\\\ 2 & 3 \\end{pmatrix}",
    choices: ["λ² − 7λ + 10", "λ² − 7λ + 14", "λ² + 7λ + 10", "λ² − 6λ + 10"],
    answer: 0,
    explanation: "det(A−λI) = (4−λ)(3−λ) − 2 = λ² − 7λ + 10. ریشه‌ها ۲ و ۵.",
    explanationTex: "\\det(A-\\lambda I) = \\lambda^2 - 7\\lambda + 10 = (\\lambda-2)(\\lambda-5)",
  },
  {
    id: "m15", topic: "مختلط", academy: "math", difficulty: 1,
    question: "قدر مطلق عدد مختلط z = 3 + 4i:",
    choices: ["۷", "۵", "۴", "۲۵"],
    answer: 1,
    explanation: "|z| = √(3² + 4²) = √۲۵ = ۵.",
    explanationTex: "|z| = \\sqrt{9 + 16} = 5",
  },
  {
    id: "m16", topic: "حسابان (سری p)", academy: "math", difficulty: 2,
    question: "سری Σ 1/nᵖ همگراست اگر و فقط اگر:",
    choices: ["p > ۰", "p > ۱", "p < ۱", "p ≥ ۱"],
    answer: 1,
    explanation: "آزمون انتگرالی: ∫₁^∞ x^(−p) dx همگراست ⟺ p > ۱.",
  },
  {
    id: "m17", topic: "قضیهٔ بنیادی حسابان", academy: "math", difficulty: 2,
    question: "مشتق ∫₀ˣ t² dt نسبت به x چیست؟",
    questionTex: "\\frac{d}{dx} \\int_0^x t^2\\,dt = \\,?",
    choices: ["x²", "x³/3", "2x", "t²"],
    answer: 0,
    explanation: "FTC-1: مشتق انتگرال = خود تابع در کران بالا: f(x) = x².",
    explanationTex: "= x^2",
  },
  {
    id: "m18", topic: "معادلات دیفرانسیل", academy: "math", difficulty: 3,
    question: "عامل انتگرال برای y′ + 2y = e^(−t):",
    choices: ["e^(2t)", "e^(−2t)", "e^(−t)", "2t"],
    answer: 0,
    explanation: "μ = e^∫2 dt = e^(2t). سپس (e^{2t}y)′ = e^t و جواب y = e^{−t} + Ce^{−2t}.",
    explanationTex: "\\mu(t) = e^{\\int 2\\,dt} = e^{2t}",
  },
  /* --- verified items for new curriculum (A2/B2/C2/D2) --- */
  {
    id: "m19", topic: "هندسه تحلیلی", academy: "math", difficulty: 1,
    question: "فاصلهٔ (1, 3) تا (4, 7) چقدر است؟",
    choices: ["۳", "۴", "۵", "۶"],
    answer: 2,
    explanation: "فیثاغورس: √((4−1)² + (7−3)²) = √(۹+۱۶) = ۲۵√ = ۵.",
    explanationTex: "d = \\sqrt{3^2 + 4^2} = 5",
  },
  {
    id: "m20", topic: "شمارش", academy: "math", difficulty: 1,
    question: "چند راه برای انتخاب ۳ نفر از ۸ (بی‌توجه به ترتیب)؟",
    choices: ["۲۴", "۵۶", "۳۳۶", "۸^۳"],
    answer: 1,
    explanation: "ترکیب: C(8,3) = 8!/(3!5!) = ۵۶.",
    explanationTex: "\\binom{8}{3} = \\frac{8!}{3!\\,5!} = 56",
  },
  {
    id: "m21", topic: "قضیهٔ مقدار میانی", academy: "math", difficulty: 2,
    question: "کدام گزاره نتیجهٔ مستقیم MVT است؟",
    choices: [
      "هر تابع پیوسته مشتق‌پذیر است",
      "اگر f′ = c در همه‌جا آنگاه f خطی است",
      "f′(c)=0 در اکسترمم همیشه اکسترمم نسبی است",
      "اگر f′ > ۰ آنگاه f کاهشی است",
    ],
    answer: 1,
    explanation: "از MVT: f(a+x) − f(a) = c·x ⇒ f خطی با شیب c. (بقیه نادرست‌اند.)",
  },
  {
    id: "m22", topic: "انتگرال نامتعارف", academy: "math", difficulty: 2,
    question: "انتگرال ∫₁^∞ 1/x² dx:",
    choices: ["واگرا", "۱", "۲", "½"],
    answer: 1,
    explanation: "∫₁ᵗ x^(−2) dx = [−1/x]₁ᵗ = 1 − 1/t → ۱.",
    explanationTex: "\\lim_{t\\to\\infty} \\left(1 - \\frac1t\\right) = 1",
  },
  {
    id: "m23", topic: "ODE مرتبهٔ دو", academy: "math", difficulty: 2,
    question: "معادلهٔ مشخصهٔ y″ − 5y′ + 6y = 0:",
    choices: ["r² + 5r + 6", "r² − 5r + 6", "r² − 5r − 6", "(r−5)(r+6)"],
    answer: 1,
    explanation: "با y = e^{rt}: r² − 5r + 6 = 0 → ریشه‌ها ۲ و ۳ پس y = c₁e^{2t} + c₂e^{3t}.",
  },
  {
    id: "m24", topic: "شبیه‌سازی (بوزن پاسکال)", academy: "math", difficulty: 2,
    question: "از ۱۵ نفر ۲ نفر به ترتیب رئیس و منشی برمی‌گزینیم. چند طریق؟",
    choices: ["۱۰۵", "۲۱۰", "۲۲۵", "۳۰"],
    answer: 1,
    explanation: "ترتیب مهم است: P(15, 2) = 15×14 = ۲۱۰.",
  },
  {
    id: "m25", topic: "آنالیز مختلط", academy: "math", difficulty: 3,
    question: "کدام تابع در همه‌جا هولومورفیک است؟",
    choices: ["|z|²", "z̄", "e^z", "Re(z)"],
    answer: 2,
    explanation: "فقط e^z در همه‌جا کوشی–ریمان برقرار (u_x = v_y etc) را برآورده می‌کند.",
  },
  {
    id: "m26", topic: "سری تیلور", academy: "math", difficulty: 2,
    question: "سری ماکلورن ln(1+x) شعاع همگرایی چقدر است؟",
    choices: ["بی‌نهایت", "R = ۱", "R = e", "R = π"],
    answer: 1,
    explanation: "با نسبت lim |x| < 1؛ در x=1 شرطی همگرا (−ln2).",
  },
];

/* --------------------- Generated practice items --------------------- */
/* Questions and answers are computed at runtime — always consistent.   */

function ri(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
const r2 = (x: number) => Math.round(x * 100) / 100;

export const GENERATORS: Generator[] = [
  {
    id: "g-linear", topic: "معادله درجه یک", academy: "math", difficulty: 1,
    label: "حل معادله ax + b = c",
    make: () => {
      const a = ri(2, 9), x = ri(-8, 8), b = ri(-9, 9);
      const c = a * x + b;
      return {
        question: `حل کنید: ${a}x ${b >= 0 ? "+" : "−"} ${Math.abs(b)} = ${c} — مقدار x را به دست آورید.`,
        questionTex: `${a}x ${b >= 0 ? "+" : "-"} ${Math.abs(b)} = ${c}`,
        answer: x, tolerance: 1e-9,
        steps: [
          { text: "جمله‌ی ثابت را به طرف دیگر می‌بریم:", tex: `${a}x = ${c} ${b >= 0 ? "-" : "+"} ${Math.abs(b)} = ${c - b}` },
          { text: "تقسیم بر ضریب x:", tex: `x = \\frac{${c - b}}{${a}} = ${x}` },
        ],
      };
    },
  },
  {
    id: "g-quadratic", topic: "معادله درجه دو", academy: "math", difficulty: 2,
    label: "ریشه‌های معادله درجه دو (ریشه‌ی بزرگ‌تر)",
    make: () => {
      const r1 = ri(-6, 2), r3 = ri(3, 8);
      const b = -(r1 + r3), c = r1 * r3;
      return {
        question: `ریشه‌ی بزرگ‌تر معادله‌ی زیر را بیابید.`,
        questionTex: `x^2 ${b >= 0 ? "+" : "-"} ${Math.abs(b)}x ${c >= 0 ? "+" : "-"} ${Math.abs(c)} = 0`,
        answer: r3, tolerance: 1e-9,
        steps: [
          { text: "دیسکریمینان:", tex: `\\Delta = b^2 - 4ac = ${b * b} - 4(${c}) = ${b * b - 4 * c}` },
          { text: "ریشه‌ها:", tex: `x = \\frac{${-b} \\pm \\sqrt{${b * b - 4 * c}}}{2} = ${r1},\\; ${r3}` },
          { text: `پس ریشه‌ی بزرگ‌تر ${r3} است.` },
        ],
      };
    },
  },
  {
    id: "g-derivative", topic: "مشتق", academy: "math", difficulty: 2,
    label: "مشتق چندجمله‌ای در یک نقطه",
    make: () => {
      const a = ri(1, 5), n = ri(2, 4), x0 = ri(1, 4);
      return {
        question: `اگر f(x) = ${a}x^{${n}} باشد، f′(${x0}) را حساب کنید.`,
        questionTex: `f(x) = ${a}x^{${n}}`,
        answer: a * n * Math.pow(x0, n - 1), tolerance: 1e-9,
        steps: [
          { text: "قاعده‌ی توان:", tex: `f'(x) = ${a}\\cdot${n}\\,x^{${n - 1}} = ${a * n}x^{${n - 1}}` },
          { text: "جایگذاری:", tex: `f'(${x0}) = ${a * n}(${x0})^{${n - 1}} = ${a * n * Math.pow(x0, n - 1)}` },
        ],
      };
    },
  },
  {
    id: "g-kinematics", topic: "سینماتیک", academy: "physics", difficulty: 1,
    label: "جابه‌جایی با شتاب ثابت",
    make: () => {
      const v0 = ri(0, 10), a = ri(1, 5), t = ri(2, 8);
      const d = v0 * t + 0.5 * a * t * t;
      return {
        question: `جسمی با سرعت اولیه ${v0} m/s و شتاب ثابت ${a} m/s² به مدت ${t} ثانیه حرکت می‌کند. جابه‌جایی (m)؟`,
        answer: d, unit: "m", tolerance: 0.01,
        steps: [
          { text: "فرمول حرکت شتاب ثابت:", tex: "\\Delta x = v_0 t + \\tfrac{1}{2}at^2" },
          { text: "جایگذاری:", tex: `\\Delta x = ${v0}(${t}) + \\tfrac12(${a})(${t})^2 = ${r2(d)}` },
        ],
      };
    },
  },
  {
    id: "g-ohm", topic: "مدار", academy: "physics", difficulty: 1,
    label: "قانون اهم",
    make: () => {
      const r = ri(2, 24), i = ri(1, 8) / 2;
      const v = r * i;
      return {
        question: `جریان ${i} A از مقاومت ${r} Ω می‌گذرد. اختلاف پتانسیل دو سر آن (V)؟`,
        answer: v, unit: "V", tolerance: 0.01,
        steps: [
          { text: "قانون اهم:", tex: "V = IR" },
          { text: "جایگذاری:", tex: `V = ${i} \\times ${r} = ${r2(v)} \\; \\mathrm{V}` },
        ],
      };
    },
  },
  {
    id: "g-projectile", topic: "پرتابه", academy: "physics", difficulty: 3,
    label: "برد پرتابه (زاویه ۴۵ درجه)",
    make: () => {
      const v = ri(5, 40);
      const R = (v * v * Math.sin(Math.PI / 2)) / 9.81;
      return {
        question: `پرتابه‌ای با تندایی ${v} m/s و زاویه‌ی ۴۵° پرتاب می‌شود (بدون مقاومت هوا، g=9.81). برد (m)؟`,
        answer: r2(R), unit: "m", tolerance: Math.max(0.05, R * 0.005),
        steps: [
          { text: "فرمول برد:", tex: "R = \\frac{v_0^2 \\sin 2\\theta}{g}" },
          { text: "در ۴۵ درجه sin90°=1:", tex: `R = \\frac{${v}^2}{9.81} = \\frac{${v * v}}{9.81} \\approx ${r2(R)}` },
        ],
      };
    },
  },
  {
    id: "g-mean", topic: "آمار", academy: "math", difficulty: 1,
    label: "میانگین داده‌ها",
    make: () => {
      const n = 5;
      const xs = Array.from({ length: n }, () => ri(2, 20));
      const mean = xs.reduce((a, b) => a + b, 0) / n;
      return {
        question: `میانگین داده‌های ${xs.join("، ")} (به ترتیب: ${xs.join(", ")}) را حساب کنید.`,
        answer: r2(mean), tolerance: 0.01,
        steps: [
          { text: "جمع تقسیم بر تعداد:", tex: `\\bar{x} = \\frac{${xs.join("+")}}{${n}} = \\frac{${xs.reduce((a, b) => a + b, 0)}}{${n}} = ${r2(mean)}` },
        ],
      };
    },
  },
];
