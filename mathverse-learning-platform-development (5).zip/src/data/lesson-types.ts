export type Block =
  | { t: "p"; s: string } // paragraph — supports {{...}} inline math
  | { t: "tex"; s: string } // display math
  | { t: "h"; s: string } // heading
  | { t: "ul"; items: string[] } // bullet list — supports {{...}}
  | { t: "note"; s: string } // boxed note: assumptions / limitations / warnings
  | { t: "example"; title: string; steps: { text: string; tex?: string }[] }
  // ---- backward-compatible extensions for rigorous academic content ----
  | { t: "definition"; s: string } // formal definition box
  | { t: "theorem"; s: string } // theorem / proposition box
  | { t: "proof"; s: string } // proof block (ends with QED marker)
  | { t: "warn"; s: string } // common mistakes / misconceptions
  | { t: "summary"; s: string }; // lesson summary box

export interface Lesson {
  id: string;
  academy: "math" | "physics";
  title: string;
  en: string;
  /** chapter grouping inside its subject (optional, display only) */
  chapter?: string;
  minutes: number;
  level: string;
  subject: string;
  intro: string;
  prerequisites: string[];
  objectives: string[];
  body: Block[];
  applications: string[];
  related: { label: string; href: string }[];
  references: { title: string; url: string }[];
  interactive?: { label: string; href: string };
}
