export interface FormulaVar {
  sym: string;
  fa: string;
  unit?: string;
}

export interface FormulaEntry {
  id: string;
  fa: string;
  en: string;
  cat: string;
  tex: string;
  vars: FormulaVar[];
  note?: string;
  example?: string;
  tags: string[];
}

export const FORMULA_CATS = [
  { id: "algebra", fa: "جبر" },
  { id: "geometry", fa: "هندسه" },
  { id: "trig", fa: "مثلثات" },
  { id: "calculus", fa: "حسابان" },
  { id: "linalg", fa: "جبرخطی" },
  { id: "stats", fa: "آمار و احتمال" },
  { id: "mechanics", fa: "مکانیک" },
  { id: "waves-phys", fa: "امواج" },
  { id: "em", fa: "الکتریسیته و مغناطیس" },
  { id: "thermo", fa: "ترمودینامیک" },
  { id: "optics", fa: "نورشناسی" },
  { id: "modern", fa: "فیزیک مدرن" },
];

export const FORMULAS: FormulaEntry[] = [
  // Algebra
  { id: "quad", fa: "ریشه‌های معادله درجه دو", en: "Quadratic formula", cat: "algebra", tex: "x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}", vars: [
    { sym: "a,b,c", fa: "ضرایب معادله ax²+bx+c=0" }, { sym: "x", fa: "ریشه‌ها" } ],
    note: "اگر Δ=b²−4ac مثبت باشد دو ریشه حقیقی، صفر باشد یک ریشه مضاعف و منفی باشد دو ریشه مختلط مزدوج داریم.",
    example: "برای x²−5x+6=0: Δ=25−24=1 و x=(5±1)/2 یعنی 2 و 3.", tags: ["معادله", "ریشه", "دلتا", "quadratic"] },
  { id: "binomial", fa: "بسط دوجمله‌ای", en: "Binomial theorem", cat: "algebra", tex: "(a+b)^n = \\sum_{k=0}^{n} \\binom{n}{k} a^{n-k} b^k", vars: [
    { sym: "n", fa: "توان (عدد طبیعی)" }, { sym: "\\binom{n}{k}", fa: "ضریب دوجمله‌ای" } ],
    example: "(a+b)² = a²+2ab+b²", tags: ["دوجمله", "binomial", "ترکیبیات"] },
  { id: "arithmetic-series", fa: "مجموع تصاعد حسابی", en: "Arithmetic series", cat: "algebra", tex: "S_n = \\frac{n}{2}\\,(a_1 + a_n) = \\frac{n}{2}\\,[2a_1 + (n-1)d]", vars: [
    { sym: "a_1", fa: "جمله اول" }, { sym: "d", fa: "قدر نسبت (فاصله مشترک)" }, { sym: "n", fa: "تعداد جملات" } ],
    example: "۱+۲+...+۱۰۰ = 100×101/2 = 5050", tags: ["سری", "دنباله", "series"] },
  { id: "geometric-series", fa: "مجموع تصاعد هندسی", en: "Geometric series", cat: "algebra", tex: "S_n = a_1\\,\\frac{1-r^n}{1-r}, \\qquad |r|<1: \\; S_\\infty = \\frac{a_1}{1-r}", vars: [
    { sym: "a_1", fa: "جمله اول" }, { sym: "r", fa: "نسبت مشترک" } ], tags: ["سری هندسی", "geometric"] },
  { id: "log-rule", fa: "قواعد لگاریتم", en: "Logarithm rules", cat: "algebra", tex: "\\log_b(xy)=\\log_b x + \\log_b y, \\qquad \\log_b(x^r) = r\\log_b x, \\qquad \\log_b x = \\frac{\\ln x}{\\ln b}", vars: [
    { sym: "b", fa: "پایه (b>0، b≠1)" } ], tags: ["لگاریتم", "log"] },
  // Geometry
  { id: "pythagoras", fa: "قضیه فیثاغورس", en: "Pythagorean theorem", cat: "geometry", tex: "a^2 + b^2 = c^2", vars: [
    { sym: "a,b", fa: "اضلاع قائمه", unit: "m" }, { sym: "c", fa: "وتر", unit: "m" } ],
    example: "مثلث 3-4-5: ۹+۱۶=۲۵", tags: ["مثلث", "فیثاغورس"] },
  { id: "circle-area", fa: "مساحت و محیط دایره", en: "Circle area & circumference", cat: "geometry", tex: "A = \\pi r^2, \\qquad C = 2\\pi r", vars: [
    { sym: "r", fa: "شعاع", unit: "m" } ], tags: ["دایره", "مساحت"] },
  { id: "sphere", fa: "حجم و سطح کره", en: "Sphere volume & area", cat: "geometry", tex: "V = \\frac{4}{3}\\pi r^3, \\qquad A = 4\\pi r^2", vars: [
    { sym: "r", fa: "شعاع", unit: "m" } ], tags: ["کره", "حجم"] },
  { id: "distance", fa: "فاصله دو نقطه", en: "Distance formula", cat: "geometry", tex: "d = \\sqrt{(x_2-x_1)^2 + (y_2-y_1)^2}", vars: [
    { sym: "(x_1,y_1),(x_2,y_2)", fa: "مختصات دو نقطه" } ], tags: ["فاصله", "مختصات"] },
  // Trig
  { id: "pyth-identity", fa: "اتحاد اساسی مثلثاتی", en: "Pythagorean identity", cat: "trig", tex: "\\sin^2\\theta + \\cos^2\\theta = 1", vars: [
    { sym: "\\theta", fa: "زاویه", unit: "rad" } ], tags: ["سینوس", "کسینوس", "اتحاد"] },
  { id: "sum-angle", fa: "سینوس مجموع دو زاویه", en: "Angle sum identity", cat: "trig", tex: "\\sin(\\alpha+\\beta) = \\sin\\alpha\\cos\\beta + \\cos\\alpha\\sin\\beta", vars: [], tags: ["مثلثات", "اتحاد"] },
  { id: "law-of-sines", fa: "قانون سینوس‌ها", en: "Law of sines", cat: "trig", tex: "\\frac{a}{\\sin A} = \\frac{b}{\\sin B} = \\frac{c}{\\sin C} = 2R", vars: [
    { sym: "a,b,c", fa: "اضلاع مثلث" }, { sym: "R", fa: "شعاع دایره محیطی" } ], tags: ["مثلث", "سینوس"] },
  { id: "law-of-cosines", fa: "قانون کسینوس‌ها", en: "Law of cosines", cat: "trig", tex: "c^2 = a^2 + b^2 - 2ab\\cos C", vars: [], tags: ["مثلث", "کسینوس"] },
  // Calculus
  { id: "derivative-def", fa: "تعریف مشتق", en: "Definition of derivative", cat: "calculus", tex: "f'(x) = \\lim_{h \\to 0} \\frac{f(x+h)-f(x)}{h}", vars: [
    { sym: "f'(x)", fa: "مشتق f در x (شیب خط مماس)" } ],
    note: "مشتق، نرخ لحظه‌ای تغییرات است؛ حدِ نسبتِ تغییرات وقتی گام به صفر میل می‌کند.", tags: ["مشتق", "تعریف", "derivative"] },
  { id: "power-rule", fa: "قاعده توان", en: "Power rule", cat: "calculus", tex: "\\frac{d}{dx}\\, x^n = n\\,x^{n-1}", vars: [], example: "(x³)′ = 3x²", tags: ["مشتق", "توان"] },
  { id: "chain-rule", fa: "قاعده زنجیره‌ای", en: "Chain rule", cat: "calculus", tex: "\\frac{d}{dx}\\, f(g(x)) = f'(g(x))\\,g'(x)", vars: [], tags: ["مشتق", "تابع مرکب"] },
  { id: "product-rule", fa: "قاعده ضرب", en: "Product rule", cat: "calculus", tex: "(fg)' = f'g + fg'", vars: [], tags: ["مشتق"] },
  { id: "lhopital", fa: "قاعده هوپیتال", en: "L'Hôpital's rule", cat: "calculus", tex: "\\lim_{x\\to a}\\frac{f(x)}{g(x)} = \\lim_{x\\to a}\\frac{f'(x)}{g'(x)} \\quad (\\tfrac{0}{0} \\;\\text{یا}\\; \\tfrac{\\infty}{\\infty})", vars: [],
    note: "فقط برای صورت‌های مبهم 0/0 یا ∞/∞ قابل استفاده است.", tags: ["حد", "هوپیتال"] },
  { id: "ftc", fa: "قضیه اساسی حسابان", en: "Fundamental theorem of calculus", cat: "calculus", tex: "\\int_a^b f(x)\\,dx = F(b) - F(a), \\qquad F' = f", vars: [
    { sym: "F", fa: "پادمشتق f" } ], tags: ["انتگرال", "قضیه اساسی"] },
  { id: "int-power", fa: "انتگرال توان", en: "Power integration", cat: "calculus", tex: "\\int x^n\\,dx = \\frac{x^{n+1}}{n+1} + C \\quad (n \\neq -1)", vars: [], tags: ["انتگرال"] },
  { id: "taylor", fa: "بسط تیلور", en: "Taylor series", cat: "calculus", tex: "f(x) = \\sum_{n=0}^{\\infty} \\frac{f^{(n)}(a)}{n!}\\,(x-a)^n", vars: [
    { sym: "a", fa: "نقطه مرکز بسط" } ], example: "e^x = 1 + x + x²/2! + x³/3! + ...", tags: ["تیلور", "سری"] },
  { id: "euler", fa: "اتحاد اویلر", en: "Euler's identity", cat: "calculus", tex: "e^{i\\theta} = \\cos\\theta + i\\sin\\theta", vars: [], example: "e^{iπ}+1=0", tags: ["اویلر", "مختلط"] },
  // Linear algebra
  { id: "det2", fa: "دترمینان ۲×۲", en: "2×2 determinant", cat: "linalg", tex: "\\det \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} = ad - bc", vars: [], tags: ["ماتریس", "دترمینان"] },
  { id: "eigen-def", fa: "معادله مقادیر ویژه", en: "Eigenvalue equation", cat: "linalg", tex: "A\\vec{v} = \\lambda \\vec{v}, \\qquad \\det(A - \\lambda I) = 0", vars: [
    { sym: "\\lambda", fa: "مقدار ویژه" }, { sym: "\\vec{v}", fa: "بردار ویژه" } ], tags: ["ویژه", "eigen"] },
  { id: "dot", fa: "ضرب داخلی", en: "Dot product", cat: "linalg", tex: "\\vec{a}\\cdot\\vec{b} = |\\vec{a}|\\,|\\vec{b}|\\cos\\theta = \\sum_i a_i b_i", vars: [], tags: ["بردار", "ضرب داخلی"] },
  { id: "cross", fa: "اندازه ضرب خارجی", en: "Cross product magnitude", cat: "linalg", tex: "|\\vec{a}\\times\\vec{b}| = |\\vec{a}|\\,|\\vec{b}|\\sin\\theta", vars: [], tags: ["بردار", "ضرب خارجی"] },
  // Stats
  { id: "mean", fa: "میانگین", en: "Mean", cat: "stats", tex: "\\bar{x} = \\frac{1}{n}\\sum_{i=1}^{n} x_i", vars: [
    { sym: "x_i", fa: "داده‌ها" }, { sym: "n", fa: "تعداد داده‌ها" } ], tags: ["میانگین", "آمار"] },
  { id: "variance", fa: "واریانس نمونه", en: "Sample variance", cat: "stats", tex: "s^2 = \\frac{1}{n-1}\\sum_{i=1}^{n}(x_i - \\bar{x})^2", vars: [
    { sym: "s^2", fa: "واریانس نمونه" } ], note: "تقسیم بر n−1 (تصحیح بسل) برآوردگر ناریب واریانس جامعه می‌دهد.", tags: ["واریانس", "پراکندگی"] },
  { id: "binomial-dist", fa: "توزیع دوجمله‌ای", en: "Binomial distribution", cat: "stats", tex: "P(X=k) = \\binom{n}{k} p^k (1-p)^{n-k}", vars: [
    { sym: "n", fa: "تعداد آزمایش‌ها" }, { sym: "p", fa: "احتمال موفقیت" }, { sym: "k", fa: "تعداد موفقیت‌ها" } ],
    example: "احتمال دقیقاً ۳ شیر در ۵ پرتاب سکه: C(5,3)(0.5)⁵ = 0.3125", tags: ["احتمال", "دوجمله‌ای"] },
  { id: "normal-pdf", fa: "چگالی نرمال", en: "Normal distribution", cat: "stats", tex: "f(x) = \\frac{1}{\\sigma\\sqrt{2\\pi}}\\, e^{-\\frac{(x-\\mu)^2}{2\\sigma^2}}", vars: [
    { sym: "\\mu", fa: "میانگین" }, { sym: "\\sigma", fa: "انحراف معیار" } ], tags: ["نرمال", "گاوسی"] },
  { id: "poisson", fa: "توزیع پواسون", en: "Poisson distribution", cat: "stats", tex: "P(X=k) = \\frac{\\lambda^k e^{-\\lambda}}{k!}", vars: [
    { sym: "\\lambda", fa: "نرخ متوسط رخداد" } ], tags: ["پواسون", "احتمال"] },
  { id: "bayes", fa: "قضیه بیز", en: "Bayes' theorem", cat: "stats", tex: "P(A|B) = \\frac{P(B|A)\\,P(A)}{P(B)}", vars: [], tags: ["بیز", "احتمال شرطی"] },
  // Mechanics
  { id: "newton2", fa: "قانون دوم نیوتن", en: "Newton's second law", cat: "mechanics", tex: "\\vec{F}_{\\text{خالص}} = m\\vec{a}", vars: [
    { sym: "F", fa: "نیروی خالص", unit: "N" }, { sym: "m", fa: "جرم", unit: "kg" }, { sym: "a", fa: "شتاب", unit: "m/s²" } ],
    note: "نیرو علت تغییر حرکت است نه علت حرکت.", tags: ["نیوتن", "نیرو", "شتاب"] },
  { id: "kinematic-v", fa: "سرعت در شتاب ثابت", en: "Constant acceleration", cat: "mechanics", tex: "v = v_0 + at, \\qquad \\Delta x = v_0 t + \\tfrac{1}{2}at^2, \\qquad v^2 = v_0^2 + 2a\\,\\Delta x", vars: [
    { sym: "v_0", fa: "سرعت اولیه", unit: "m/s" }, { sym: "a", fa: "شتاب ثابت", unit: "m/s²" }, { sym: "t", fa: "زمان", unit: "s" } ], tags: ["حرکت", "شتاب ثابت"] },
  { id: "ke", fa: "انرژی جنبشی", en: "Kinetic energy", cat: "mechanics", tex: "K = \\tfrac{1}{2}mv^2", vars: [
    { sym: "m", fa: "جرم", unit: "kg" }, { sym: "v", fa: "سرعت", unit: "m/s" }, { sym: "K", fa: "انرژی جنبشی", unit: "J" } ], tags: ["انرژی"] },
  { id: "pe", fa: "انرژی پتانسیل گرانشی", en: "Gravitational PE", cat: "mechanics", tex: "U = mgh", vars: [
    { sym: "g", fa: "شتاب گرانش ≈ 9.81", unit: "m/s²" }, { sym: "h", fa: "ارتفاع", unit: "m" } ],
    note: "نزدیک سطح زمین و با مبدأ دلخواه پتانسیل.", tags: ["انرژی", "گرانش"] },
  { id: "work", fa: "کار نیرو", en: "Work", cat: "mechanics", tex: "W = \\vec{F}\\cdot\\vec{d} = Fd\\cos\\theta", vars: [
    { sym: "W", fa: "کار", unit: "J" }, { sym: "\\theta", fa: "زاویه نیرو و جابه‌جایی" } ], tags: ["کار", "نیرو"] },
  { id: "momentum-f", fa: "تکانه", en: "Momentum", cat: "mechanics", tex: "\\vec{p} = m\\vec{v}, \\qquad \\vec{F}_{\\text{خالص}} = \\frac{d\\vec{p}}{dt}", vars: [
    { sym: "p", fa: "تکانه", unit: "kg·m/s" } ], tags: ["تکانه", "momentum"] },
  { id: "centripetal", fa: "شتاب جانب‌مرکز", en: "Centripetal acceleration", cat: "mechanics", tex: "a_c = \\frac{v^2}{r} = \\omega^2 r", vars: [
    { sym: "v", fa: "سرعت خطی", unit: "m/s" }, { sym: "\\omega", fa: "سرعت زاویه‌ای", unit: "rad/s" }, { sym: "r", fa: "شعاع", unit: "m" } ], tags: ["حرکت دایره‌ای"] },
  { id: "gravity", fa: "گرانش جهانی", en: "Universal gravitation", cat: "mechanics", tex: "F = G\\frac{m_1 m_2}{r^2}, \\qquad G = 6.674\\times 10^{-11}\\, \\mathrm{N\\,m^2/kg^2}", vars: [
    { sym: "r", fa: "فاصله مراکز دو جرم", unit: "m" } ], tags: ["گرانش", "نیوتن"] },
  { id: "hook", fa: "قانون هوک", en: "Hooke's law", cat: "mechanics", tex: "F = -kx", vars: [
    { sym: "k", fa: "ثابت فنر", unit: "N/m" }, { sym: "x", fa: "تغییر طول", unit: "m" } ], tags: ["فنر", "نوسان"] },
  { id: "shm-period", fa: "دوره آونگ ساده", en: "Simple pendulum period", cat: "mechanics", tex: "T \\approx 2\\pi\\sqrt{\\frac{L}{g}} \\quad (\\theta \\ll 1)", vars: [
    { sym: "L", fa: "طول آونگ", unit: "m" } ], note: "تقریب زاویه کوچک؛ برای دامنه بزرگ دوره بیشتر می‌شود.", tags: ["آونگ", "دوره"] },
  // Waves
  { id: "wave-speed", fa: "سرعت موج", en: "Wave speed", cat: "waves-phys", tex: "v = f\\lambda = \\frac{\\lambda}{T}", vars: [
    { sym: "f", fa: "بسامد", unit: "Hz" }, { sym: "\\lambda", fa: "طول موج", unit: "m" } ], tags: ["موج", "بسامد"] },
  { id: "wave-eq", fa: "موج سینوسی پیش‌رونده", en: "Traveling wave", cat: "waves-phys", tex: "y(x,t) = A\\sin(kx - \\omega t + \\varphi), \\quad k=\\tfrac{2\\pi}{\\lambda},\\; \\omega = 2\\pi f", vars: [
    { sym: "A", fa: "دامنه", unit: "m" }, { sym: "k", fa: "عدد موج", unit: "rad/m" }, { sym: "\\omega", fa: "بسامد زاویه‌ای", unit: "rad/s" } ], tags: ["موج", "معادله موج"] },
  { id: "doppler", fa: "اثر دوپلر (صوت)", en: "Doppler effect", cat: "waves-phys", tex: "f' = f\\,\\frac{v \\pm v_o}{v \\mp v_s}", vars: [
    { sym: "v", fa: "سرعت صوت", unit: "m/s" }, { sym: "v_o, v_s", fa: "سرعت ناظر و چشمه" } ], tags: ["دوپلر", "صوت"] },
  // EM
  { id: "coulomb-f", fa: "قانون کولن", en: "Coulomb's law", cat: "em", tex: "F = k\\frac{|q_1 q_2|}{r^2}, \\qquad k = 8.988\\times 10^9\\, \\mathrm{N\\,m^2/C^2}", vars: [
    { sym: "q_1,q_2", fa: "بارها", unit: "C" }, { sym: "r", fa: "فاصله", unit: "m" } ], tags: ["کولن", "بار"] },
  { id: "efield", fa: "میدان الکتریکی بار نقطه‌ای", en: "Point charge field", cat: "em", tex: "\\vec{E} = k\\frac{q}{r^2}\\,\\hat{r}", vars: [
    { sym: "E", fa: "میدان الکتریکی", unit: "N/C" } ], tags: ["میدان", "بار"] },
  { id: "ohm", fa: "قانون اهم", en: "Ohm's law", cat: "em", tex: "V = IR", vars: [
    { sym: "V", fa: "ولتاژ", unit: "V" }, { sym: "I", fa: "جریان", unit: "A" }, { sym: "R", fa: "مقاومت", unit: "Ω" } ], tags: ["اهم", "مدار"] },
  { id: "power-el", fa: "توان الکتریکی", en: "Electric power", cat: "em", tex: "P = VI = I^2R = \\frac{V^2}{R}", vars: [
    { sym: "P", fa: "توان", unit: "W" } ], tags: ["توان", "مدار"] },
  { id: "lorentz", fa: "نیروی لورتس", en: "Lorentz force", cat: "em", tex: "\\vec{F} = q(\\vec{E} + \\vec{v}\\times\\vec{B})", vars: [
    { sym: "B", fa: "میدان مغناطیسی", unit: "T" } ], tags: ["لورتس", "مغناطیس"] },
  // Thermo
  { id: "ideal-gas", fa: "معادله حالت گاز ایده‌آل", en: "Ideal gas law", cat: "thermo", tex: "PV = nRT, \\qquad R = 8.314\\, \\mathrm{J/(mol\\cdot K)}", vars: [
    { sym: "P", fa: "فشار", unit: "Pa" }, { sym: "V", fa: "حجم", unit: "m³" }, { sym: "n", fa: "مقدار ماده", unit: "mol" }, { sym: "T", fa: "دما", unit: "K" } ],
    note: "T باید به کلوین باشد: T(K) = T(°C) + 273.15", tags: ["گاز", "فشار"] },
  { id: "heat-q", fa: "گرمای داده‌شده به جسم", en: "Heat transfer", cat: "thermo", tex: "Q = mc\\Delta T", vars: [
    { sym: "c", fa: "گرمای ویژه", unit: "J/(kg·K)" }, { sym: "\\Delta T", fa: "تغییر دما", unit: "K" } ], tags: ["گرما", "دما"] },
  { id: "first-law", fa: "قانون اول ترمودینامیک", en: "First law", cat: "thermo", tex: "\\Delta U = Q - W", vars: [
    { sym: "Q", fa: "گرمای دریافتی سیستم", unit: "J" }, { sym: "W", fa: "کار انجام‌شده توسط سیستم", unit: "J" } ], tags: ["ترمودینامیک", "انرژی درونی"] },
  // Optics
  { id: "snell", fa: "قانون اسنل", en: "Snell's law", cat: "optics", tex: "n_1\\sin\\theta_1 = n_2\\sin\\theta_2", vars: [
    { sym: "n", fa: "ضریب شکست" } ], tags: ["شکست", "نور"] },
  { id: "lens", fa: "معادله عدسی نازک", en: "Thin lens equation", cat: "optics", tex: "\\frac{1}{f} = \\frac{1}{d_o} + \\frac{1}{d_i}, \\qquad m = -\\frac{d_i}{d_o}", vars: [
    { sym: "f", fa: "فاصله کانونی", unit: "m" }, { sym: "d_o, d_i", fa: "فاصله جسم و تصویر" } ], tags: ["عدسی", "تصویر"] },
  // Modern
  { id: "emc2", fa: "هم‌ارزی جرم و انرژی", en: "Mass-energy equivalence", cat: "modern", tex: "E = mc^2, \\qquad c = 2.998\\times 10^8\\, \\mathrm{m/s}", vars: [
    { sym: "m", fa: "جرم سکون", unit: "kg" } ], tags: ["نسبیت", "انرژی"] },
  { id: "time-dilation", fa: "اتساع زمان", en: "Time dilation", cat: "modern", tex: "\\Delta t = \\gamma\\,\\Delta t_0, \\qquad \\gamma = \\frac{1}{\\sqrt{1 - v^2/c^2}}", vars: [
    { sym: "\\Delta t_0", fa: "زمان خاص (در دستگاه سکون جسم)" } ], tags: ["نسبیت", "زمان"] },
  { id: "photoel", fa: "اثر فوتوالکتریک", en: "Photoelectric effect", cat: "modern", tex: "K_{\\max} = hf - \\phi, \\qquad h = 6.626\\times 10^{-34}\\, \\mathrm{J\\,s}", vars: [
    { sym: "\\phi", fa: "تابع کار فلز", unit: "J" }, { sym: "f", fa: "بسامد نور", unit: "Hz" } ], tags: ["کوانتوم", "فوتون"] },
  { id: "debroglie", fa: "طول موج دوبروی", en: "de Broglie wavelength", cat: "modern", tex: "\\lambda = \\frac{h}{p} = \\frac{h}{mv}", vars: [], tags: ["کوانتوم", "دوگانگی"] },
];
